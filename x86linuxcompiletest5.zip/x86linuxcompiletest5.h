/*
 * x86linuxcompiletest5.h
 *
 * Code generation for model "x86linuxcompiletest5".
 *
 * Model version              : 1.45
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Wed Apr 28 13:25:02 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_x86linuxcompiletest5_h_
#define RTW_HEADER_x86linuxcompiletest5_h_
#include <math.h>
#include <string.h>
#include <float.h>
#include <stddef.h>
#ifndef x86linuxcompiletest5_COMMON_INCLUDES_
#define x86linuxcompiletest5_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                               /* x86linuxcompiletest5_COMMON_INCLUDES_ */

#include "x86linuxcompiletest5_types.h"

/* Shared type includes */
#include "multiword_types.h"

/* Child system includes */
#include "DynamicsController.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
#define rtmGetRTWLogInfo(rtm)          ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                (&(rtm)->Timing.taskTime0)
#endif

/* user code (top of header file) */
/* System '<Root>' */
/*
 * 	File: global.h
 *
 *  Created on: 2020��12��24��
 *  Author: becking
 */
#ifndef COMDEF_H
#define COMDEF_H
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <sys/types.h>
#include <sys/socket.h>                //socket,bind,listen
#include <netinet/in.h>
#include <netinet/tcp.h>               //man 7 ip
#include <arpa/inet.h>                 //inet_addr
#include <sys/ipc.h>                   //ftok
#include <errno.h>                     //perror
#include <sys/shm.h>                   //shmget��shmat
#include <pthread.h>
#include <sys/socket.h>                //recv
#include <strings.h>
#include <sys/ioctl.h>                 //ioctl
#include <string.h>
#include <sys/stat.h>                  //open
#include <fcntl.h>
#include <signal.h>
#include <semaphore.h>                 //sem_post
#include <sys/ioctl.h>
#include <sys/time.h>

/**********************************/
/*�������Ͷ���*/
#define int8                           signed char
#define int16                          short
#define int32                          int
#define uint8                          unsigned char
#define uint16                         unsigned short
#define uint32                         unsigned int

/*�����ڴ�Keyֵ·������ʶ*/
#define SHM_PATH_A                     "/etc"
#define SHM_PATH_B                     "/bin"
#define SHM_FLAG_A                     'a'
#define SHM_FLAG_B                     'b'
#define Q_SIZE                         (128)
#define JOINTS_NUM                     6

/***************************PDO���ò���***************************************/
typedef enum model_type{
  MODEL_PP = 0x1,                      //λ������ģʽ
  MODEL_PV = 0x3,                      //�ٶ�����ģʽ
  MODEL_PT = 0x4,                      //����ģʽ
  MODEL_BZ = 0x6,                      //����ģʽ
  MODEL_INP = 0x7,                     //�岹λ��ģʽ
  MODEL_CSP = 0x8,                     //CSP:ͬ������λ��ģʽ
  MODEL_CSV = 0x9,                     //CSV: ͬ�������ٶ�ģʽ
  MODEL_CST = 0xa                      //CST��ͬ����������ģʽ
} Model_type;

typedef struct {
  unsigned int ctrl_word;              // Contorl word  		   slave_6040_00
  unsigned int status_word;            // status word   		   slave_6041_00
  unsigned int actual_pos;             // Actual motor position   slave_6064_00
  unsigned int target_pos;             // Profile target position slave_607a_00
  unsigned int pos_error;              // Position loop error     slave_60f4_00
  unsigned int actual_vel;             // Actual motor velocity   slave_606c_00
  unsigned int target_vel;             // Target motor velocity   slave_60ff_00
  unsigned int offset_vel;             // Velocity offset         slave_60b1_00
  unsigned int actual_torq;            // Torque actual value     slave_6077_00
  unsigned int target_torq;            // Target torque value     slave_6071_00
  unsigned int offset_torq;            // Torque offset           slave_60b2_00
} Pdo_info;

typedef struct {
  Model_type model_type;               //����ģʽ
  Pdo_info pdo_val;                    //PDO���ò���
  unsigned char error;                 //������
  unsigned char status;                //״̬
} Shm_info;

typedef struct {
  long type;
  Shm_info JointInfo[JOINTS_NUM];      //6���ؽ�
} Shm;

typedef struct shm_queue {
  int index,count;
  Shm shmBuf[Q_SIZE];
} Shm_Queue_t;

//extern uint8_t g_shm_recv_flag;
//extern Shm shm_send; //�����ڴ�ṹ��
//extern Shm shm_recv; //�����ڴ�ṹ��
//extern Shm_Queue_t *shared[2];
//int set_timer(long tv_sec,long tv_usec);
//void* init_shm(int *shmid, const char *pathname, int size);
//int del_shm(void *shm);
//int destory_shm(int shmid);
//int shm_write(Shm shm_send,Shm_Queue_t *shared,sem_t *sem);
//int shm_read(Shm *shm_recv,Shm_Queue_t *shared,sem_t *sem);
#endif

/* System '<Root>' */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <signal.h>
#include <fcntl.h>

/* Block signals (default storage) */
typedef struct {
  real_T in;                           /* '<S2>/Chart' */
  real_T in_j;                         /* '<S2>/Chart' */
  real_T THETA[48];                    /* '<S37>/Round' */
  real_T AllSloverTheta[48];           /* '<S37>/MATLAB Function' */
  real_T Selector1[6];                 /* '<S37>/Selector1' */
  uint16_T TmpSignalConversionAtInport1[9];/* '<S46>/Subsystem' */
  uint16_T _o1[9];                     /* '<S46>/����У��' */
  boolean_T _o2;                       /* '<S46>/����У��' */
  B_GotoPlay_x86linuxcompiletes_T GotoPlay;/* '<S8>/GotoPlay' */
} B_x86linuxcompiletest5_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T GUIcomd;                      /* '<Root>/Data Store Memory19' */
  real_T Send_GUIdata[18];             /* '<Root>/Data Store Memory3' */
  real_T PosJoint[14];                 /* '<Root>/Data Store Memory4' */
  real_T VelocJoint[14];               /* '<Root>/Data Store Memory5' */
  real_T TorqueJoint[14];              /* '<Root>/Data Store Memory6' */
  real_T PosXYZ[14];                   /* '<Root>/Data Store Memory7' */
  real_T Jdata[42];                    /* '<Root>/Data Store Memory8' */
  real_T Gostate;                      /* '<S2>/Chart' */
  uint16_T temporalCounter_i1;         /* '<S2>/Chart' */
  uint8_T Output_DSTATE;               /* '<S66>/Output' */
  uint8_T Output_DSTATE_m;             /* '<S63>/Output' */
  uint8_T Output_DSTATE_e;             /* '<S43>/Output' */
  uint8_T Output_DSTATE_a;             /* '<S44>/Output' */
  boolean_T Delay_DSTATE[2];           /* '<S4>/Delay' */
  uint8_T is_active_c3_x86linuxcompiletes;/* '<S2>/Chart' */
  uint8_T is_c3_x86linuxcompiletest5;  /* '<S2>/Chart' */
  DW_GotoPlay_x86linuxcompilete_T GotoPlay;/* '<S8>/GotoPlay' */
} DW_x86linuxcompiletest5_T;

/* Parameters (default storage) */
struct P_x86linuxcompiletest5_T_ {
  real_T Ts;                           /* Variable: Ts
                                        * Referenced by: '<Root>/Data Store Memory'
                                        */
  int32_T PT_c;                        /* Variable: PT_c
                                        * Referenced by: '<S21>/�켣����'
                                        */
  real32_T PT_t[60006];                /* Variable: PT_t
                                        * Referenced by: '<S21>/�켣����'
                                        */
  boolean_T CompareToConstant_const;  /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S31>/Constant'
                                       */
  boolean_T CompareToConstant_const_b;
                                    /* Mask Parameter: CompareToConstant_const_b
                                     * Referenced by: '<S34>/Constant'
                                     */
  uint8_T _uplimit;                    /* Mask Parameter: _uplimit
                                        * Referenced by: '<S60>/FixPt Switch'
                                        */
  uint8_T u_uplimit;                   /* Mask Parameter: u_uplimit
                                        * Referenced by: '<S62>/FixPt Switch'
                                        */
  uint8_T CounterLimited_uplimit;      /* Mask Parameter: CounterLimited_uplimit
                                        * Referenced by: '<S65>/FixPt Switch'
                                        */
  uint8_T CounterLimited_uplimit_m;  /* Mask Parameter: CounterLimited_uplimit_m
                                      * Referenced by: '<S68>/FixPt Switch'
                                      */
  real_T Gain6_Gain;                   /* Expression: 131072/360
                                        * Referenced by: '<S32>/Gain6'
                                        */
  real_T Choice_Value;                 /* Expression: 2
                                        * Referenced by: '<S37>/Choice'
                                        */
  real_T DH_Value[24];
  /* Expression: [0,0,121.5,0;90,0,0,-90;0,-300,0,0;0,-276,110.5,-90;90,0,90,0;-90,0,82,0]
   * Referenced by: '<S37>/DH����'
   */
  real_T Gain_Gain;                    /* Expression: -1.0
                                        * Referenced by: '<S36>/Gain'
                                        */
  real_T Gain1_Gain;                   /* Expression: 1.0
                                        * Referenced by: '<S36>/Gain1'
                                        */
  real_T Gain6_Gain_k;                 /* Expression: 131072/360
                                        * Referenced by: '<S36>/Gain6'
                                        */
  real_T Gain2_Gain;                   /* Expression: 10
                                        * Referenced by: '<S40>/Gain2'
                                        */
  real_T Gain1_Gain_g;                 /* Expression: 10
                                        * Referenced by: '<S40>/Gain1'
                                        */
  real_T Gain3_Gain;                   /* Expression: 10
                                        * Referenced by: '<S40>/Gain3'
                                        */
  real_T Gain_Gain_d;                  /* Expression: 0.1
                                        * Referenced by: '<S50>/Gain'
                                        */
  real_T Gain1_Gain_b;                 /* Expression: 0.1
                                        * Referenced by: '<S49>/Gain1'
                                        */
  real_T Gain2_Gain_o;                 /* Expression: 0.1
                                        * Referenced by: '<S49>/Gain2'
                                        */
  real_T Gain3_Gain_i;                 /* Expression: 0.1
                                        * Referenced by: '<S49>/Gain3'
                                        */
  real_T Gain4_Gain;                   /* Expression: 0.1
                                        * Referenced by: '<S49>/Gain4'
                                        */
  real_T Gain5_Gain;                   /* Expression: 0.1
                                        * Referenced by: '<S49>/Gain5'
                                        */
  real_T Gain6_Gain_i;                 /* Expression: 0.1
                                        * Referenced by: '<S49>/Gain6'
                                        */
  real_T DataStoreMemory19_InitialValue;/* Expression: 0
                                         * Referenced by: '<Root>/Data Store Memory19'
                                         */
  real_T DataStoreMemory3_InitialValue[18];/* Expression: zeros(1,18)
                                            * Referenced by: '<Root>/Data Store Memory3'
                                            */
  real_T DataStoreMemory4_InitialValue[14];/* Expression: zeros(2,7)
                                            * Referenced by: '<Root>/Data Store Memory4'
                                            */
  real_T DataStoreMemory5_InitialValue[14];/* Expression: zeros(2,7)
                                            * Referenced by: '<Root>/Data Store Memory5'
                                            */
  real_T DataStoreMemory6_InitialValue[14];/* Expression: zeros(2,7)
                                            * Referenced by: '<Root>/Data Store Memory6'
                                            */
  real_T DataStoreMemory7_InitialValue[14];/* Expression: zeros(2,7)
                                            * Referenced by: '<Root>/Data Store Memory7'
                                            */
  real_T DataStoreMemory8_InitialValue[42];/* Expression: zeros(6,7)
                                            * Referenced by: '<Root>/Data Store Memory8'
                                            */
  int32_T Gain_Gain_j;                 /* Computed Parameter: Gain_Gain_j
                                        * Referenced by: '<S3>/Gain'
                                        */
  int32_T Gain1_Gain_o;                /* Computed Parameter: Gain1_Gain_o
                                        * Referenced by: '<S3>/Gain1'
                                        */
  int32_T Gain3_Gain_d;                /* Computed Parameter: Gain3_Gain_d
                                        * Referenced by: '<S3>/Gain3'
                                        */
  int32_T Gain4_Gain_c;                /* Computed Parameter: Gain4_Gain_c
                                        * Referenced by: '<S3>/Gain4'
                                        */
  uint32_T Constant_Value[7];          /* Computed Parameter: Constant_Value
                                        * Referenced by: '<S32>/Constant'
                                        */
  uint32_T Constant_Value_n[7];        /* Computed Parameter: Constant_Value_n
                                        * Referenced by: '<S35>/Constant'
                                        */
  uint32_T Constant2_Value[7];         /* Computed Parameter: Constant2_Value
                                        * Referenced by: '<S36>/Constant2'
                                        */
  uint32_T DataStoreMemory20_InitialValue[49];
                           /* Computed Parameter: DataStoreMemory20_InitialValue
                            * Referenced by: '<Root>/Data Store Memory20'
                            */
  uint32_T DataStoreMemory21_InitialValue[42];
                           /* Computed Parameter: DataStoreMemory21_InitialValue
                            * Referenced by: '<Root>/Data Store Memory21'
                            */
  int16_T Gain2_Gain_on;               /* Computed Parameter: Gain2_Gain_on
                                        * Referenced by: '<S3>/Gain2'
                                        */
  int16_T Gain1_Gain_k;                /* Computed Parameter: Gain1_Gain_k
                                        * Referenced by: '<S50>/Gain1'
                                        */
  int16_T Gain5_Gain_n;                /* Computed Parameter: Gain5_Gain_n
                                        * Referenced by: '<S3>/Gain5'
                                        */
  uint16_T Constant2_Value_o;          /* Computed Parameter: Constant2_Value_o
                                        * Referenced by: '<S40>/Constant2'
                                        */
  uint16_T Value;                      /* Computed Parameter: Value
                                        * Referenced by: '<S46>/��־λ'
                                        */
  uint16_T DataStoreMemory10_InitialValue[20];
                           /* Computed Parameter: DataStoreMemory10_InitialValue
                            * Referenced by: '<Root>/Data Store Memory10'
                            */
  boolean_T Constant1_Value;           /* Computed Parameter: Constant1_Value
                                        * Referenced by: '<S32>/Constant1'
                                        */
  boolean_T Constant1_Value_k;         /* Computed Parameter: Constant1_Value_k
                                        * Referenced by: '<S36>/Constant1'
                                        */
  boolean_T Constant_Value_g;          /* Computed Parameter: Constant_Value_g
                                        * Referenced by: '<S40>/Constant'
                                        */
  boolean_T Constant_Value_p;          /* Computed Parameter: Constant_Value_p
                                        * Referenced by: '<S41>/Constant'
                                        */
  boolean_T Constant_Value_h;          /* Computed Parameter: Constant_Value_h
                                        * Referenced by: '<S42>/Constant'
                                        */
  boolean_T Constant3_Value;           /* Expression: false
                                        * Referenced by: '<S4>/Constant3'
                                        */
  boolean_T Constant2_Value_c;         /* Expression: true
                                        * Referenced by: '<S4>/Constant2'
                                        */
  boolean_T Constant1_Value_m;         /* Expression: false
                                        * Referenced by: '<S4>/Constant1'
                                        */
  boolean_T Constant_Value_f;          /* Expression: true
                                        * Referenced by: '<S4>/Constant'
                                        */
  boolean_T Delay_InitialCondition;/* Computed Parameter: Delay_InitialCondition
                                    * Referenced by: '<S4>/Delay'
                                    */
  boolean_T UDPInitialValue;           /* Computed Parameter: UDPInitialValue
                                        * Referenced by: '<Root>/UDPд��־'
                                        */
  boolean_T UDPInitialValue_j;         /* Computed Parameter: UDPInitialValue_j
                                        * Referenced by: '<Root>/UDPʹ��д��־'
                                        */
  boolean_T UDP_InitialValue;          /* Computed Parameter: UDP_InitialValue
                                        * Referenced by: '<Root>/UDPʹ�ܶ�ȡ��־'
                                        */
  boolean_T UDP_InitialValue_e;        /* Computed Parameter: UDP_InitialValue_e
                                        * Referenced by: '<Root>/UDP��ȡ��־'
                                        */
  boolean_T _InitialValue;             /* Computed Parameter: _InitialValue
                                        * Referenced by: '<Root>/��Ϣʹ��'
                                        */
  uint8_T Constant_Value_b;            /* Computed Parameter: Constant_Value_b
                                        * Referenced by: '<S60>/Constant'
                                        */
  uint8_T Constant_Value_m;            /* Computed Parameter: Constant_Value_m
                                        * Referenced by: '<S62>/Constant'
                                        */
  uint8_T Output_InitialCondition;/* Computed Parameter: Output_InitialCondition
                                   * Referenced by: '<S43>/Output'
                                   */
  uint8_T Switch_Threshold;            /* Computed Parameter: Switch_Threshold
                                        * Referenced by: '<S4>/Switch'
                                        */
  uint8_T FixPtConstant_Value;        /* Computed Parameter: FixPtConstant_Value
                                       * Referenced by: '<S59>/FixPt Constant'
                                       */
  uint8_T Output_InitialCondition_p;
                                /* Computed Parameter: Output_InitialCondition_p
                                 * Referenced by: '<S44>/Output'
                                 */
  uint8_T Switch1_Threshold;           /* Computed Parameter: Switch1_Threshold
                                        * Referenced by: '<S4>/Switch1'
                                        */
  uint8_T FixPtConstant_Value_j;    /* Computed Parameter: FixPtConstant_Value_j
                                     * Referenced by: '<S61>/FixPt Constant'
                                     */
  uint8_T Constant_Value_g0;           /* Computed Parameter: Constant_Value_g0
                                        * Referenced by: '<S65>/Constant'
                                        */
  uint8_T Output_InitialCondition_j;
                                /* Computed Parameter: Output_InitialCondition_j
                                 * Referenced by: '<S63>/Output'
                                 */
  uint8_T FixPtConstant_Value_l;    /* Computed Parameter: FixPtConstant_Value_l
                                     * Referenced by: '<S64>/FixPt Constant'
                                     */
  uint8_T Constant_Value_gs;           /* Computed Parameter: Constant_Value_gs
                                        * Referenced by: '<S68>/Constant'
                                        */
  uint8_T Output_InitialCondition_l;
                                /* Computed Parameter: Output_InitialCondition_l
                                 * Referenced by: '<S66>/Output'
                                 */
  uint8_T FixPtConstant_Value_i;    /* Computed Parameter: FixPtConstant_Value_i
                                     * Referenced by: '<S67>/FixPt Constant'
                                     */
  uint8_T DataStoreMemory1_InitialValue;
                            /* Computed Parameter: DataStoreMemory1_InitialValue
                             * Referenced by: '<Root>/Data Store Memory1'
                             */
  uint8_T DataStoreMemory2_InitialValue;
                            /* Computed Parameter: DataStoreMemory2_InitialValue
                             * Referenced by: '<Root>/Data Store Memory2'
                             */
  uint8_T DataStoreMemory9_InitialValue[18];
                            /* Computed Parameter: DataStoreMemory9_InitialValue
                             * Referenced by: '<Root>/Data Store Memory9'
                             */
  P_GotoPlay_x86linuxcompiletes_T GotoPlay;/* '<S8>/GotoPlay' */
  P_StopProces_x86linuxcompilet_T StopProces;/* '<S8>/StopProces' */
  P_EnabledSubsystem13_x86linux_T EnabledSubsystem13;/* '<S12>/Enabled Subsystem13' */
  P_Cmdclear_x86linuxcompiletes_T Cmdclear;/* '<S8>/Cmdclear' */
  P_StartProces_x86linuxcompile_T StartProces;/* '<S8>/StartProces' */
  P_ModeSet_x86linuxcompiletest_T ModeSet;/* '<S8>/ModeSet' */
};

/* Real-time Model Data Structure */
struct tag_RTM_x86linuxcompiletest5_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    struct {
      uint8_T TID[2];
    } TaskCounters;

    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_x86linuxcompiletest5_T x86linuxcompiletest5_P;

/* Block signals (default storage) */
extern B_x86linuxcompiletest5_T x86linuxcompiletest5_B;

/* Block states (default storage) */
extern DW_x86linuxcompiletest5_T x86linuxcompiletest5_DW;

/*
 * Exported States
 *
 * Note: Exported states are block states with an exported global
 * storage class designation.  Code generation will declare the memory for these
 * states and exports their symbols.
 *
 */
extern uint32_T Ethercomd[49];         /* '<Root>/Data Store Memory20' */
extern uint32_T Etherfeed[42];         /* '<Root>/Data Store Memory21' */
extern uint16_T UDPsnddata[20];        /* '<Root>/Data Store Memory10' */
extern uint8_T Datachange1;            /* '<Root>/Data Store Memory1' */
extern uint8_T Datachange2;            /* '<Root>/Data Store Memory2' */
extern uint8_T UDPrecvdata[18];        /* '<Root>/Data Store Memory9' */
extern boolean_T UDPsndFlag;           /* '<Root>/UDPд��־' */
extern boolean_T UDPensndFlag;         /* '<Root>/UDPʹ��д��־' */
extern boolean_T UDPenrecvFlag;        /* '<Root>/UDPʹ�ܶ�ȡ��־' */
extern boolean_T UDPrecvFlag;          /* '<Root>/UDP��ȡ��־' */
extern boolean_T PTX;                  /* '<Root>/��Ϣʹ��' */

/* Model entry point functions */
extern void x86linuxcompiletest5_initialize(void);
extern void x86linuxcompiletest5_step(void);
extern void x86linuxcompiletest5_terminate(void);

/* Real-time Model object */
extern RT_MODEL_x86linuxcompiletest5_T *const x86linuxcompiletest5_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'x86linuxcompiletest5'
 * '<S1>'   : 'x86linuxcompiletest5/DynamicCalculation1'
 * '<S2>'   : 'x86linuxcompiletest5/DynamicCalculation2'
 * '<S3>'   : 'x86linuxcompiletest5/DynamicCalculation3'
 * '<S4>'   : 'x86linuxcompiletest5/SendDataToGUI1'
 * '<S5>'   : 'x86linuxcompiletest5/Subsystem'
 * '<S6>'   : 'x86linuxcompiletest5/Subsystem1'
 * '<S7>'   : 'x86linuxcompiletest5/Subsystem2'
 * '<S8>'   : 'x86linuxcompiletest5/DynamicCalculation2/Chart'
 * '<S9>'   : 'x86linuxcompiletest5/DynamicCalculation2/Chart/Cmdclear'
 * '<S10>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/GotoPlay'
 * '<S11>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/ModeSet'
 * '<S12>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/RunForwardProces'
 * '<S13>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/RunInverseProces'
 * '<S14>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/StartProces'
 * '<S15>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/StopProces'
 * '<S16>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/GotoPlay/GotoPos1'
 * '<S17>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/GotoPlay/Playing'
 * '<S18>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/GotoPlay/GotoPos1/Compare To Constant'
 * '<S19>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/GotoPlay/GotoPos1/Enabled Subsystem12'
 * '<S20>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/GotoPlay/GotoPos1/Enabled Subsystem13'
 * '<S21>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/GotoPlay/Playing/�켣���ٵ㷢��'
 * '<S22>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/GotoPlay/Playing/�켣���ٵ㷢��/Compare To Constant'
 * '<S23>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/GotoPlay/Playing/�켣���ٵ㷢��/Enabled Subsystem'
 * '<S24>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/GotoPlay/Playing/�켣���ٵ㷢��/MATLAB Function'
 * '<S25>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/ModeSet/CSPmode'
 * '<S26>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/ModeSet/CSTmode'
 * '<S27>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/ModeSet/CSVmode'
 * '<S28>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/ModeSet/PPmode'
 * '<S29>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/ModeSet/PTmode'
 * '<S30>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/ModeSet/PVmode'
 * '<S31>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/RunForwardProces/Compare To Constant'
 * '<S32>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/RunForwardProces/Enabled Subsystem12'
 * '<S33>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/RunForwardProces/Enabled Subsystem13'
 * '<S34>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/RunInverseProces/Compare To Constant'
 * '<S35>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/RunInverseProces/Enabled Subsystem1'
 * '<S36>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/RunInverseProces/Subsystem'
 * '<S37>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/RunInverseProces/Subsystem/�����ɶ���⣨�����⣩'
 * '<S38>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/RunInverseProces/Subsystem/�����ɶ���⣨�����⣩/MATLAB Function'
 * '<S39>'  : 'x86linuxcompiletest5/DynamicCalculation2/Chart/RunInverseProces/Subsystem/�����ɶ���⣨�����⣩/Round'
 * '<S40>'  : 'x86linuxcompiletest5/SendDataToGUI1/  '
 * '<S41>'  : 'x86linuxcompiletest5/SendDataToGUI1/Subsystem1'
 * '<S42>'  : 'x86linuxcompiletest5/SendDataToGUI1/Subsystem2'
 * '<S43>'  : 'x86linuxcompiletest5/SendDataToGUI1/�㲥����'
 * '<S44>'  : 'x86linuxcompiletest5/SendDataToGUI1/�㲥����1'
 * '<S45>'  : 'x86linuxcompiletest5/SendDataToGUI1/Subsystem2/Compare To Constant'
 * '<S46>'  : 'x86linuxcompiletest5/SendDataToGUI1/Subsystem2/Enabled Subsystem'
 * '<S47>'  : 'x86linuxcompiletest5/SendDataToGUI1/Subsystem2/GUIcmdProces'
 * '<S48>'  : 'x86linuxcompiletest5/SendDataToGUI1/Subsystem2/Jdata'
 * '<S49>'  : 'x86linuxcompiletest5/SendDataToGUI1/Subsystem2/Nijie'
 * '<S50>'  : 'x86linuxcompiletest5/SendDataToGUI1/Subsystem2/Zhengjie'
 * '<S51>'  : 'x86linuxcompiletest5/SendDataToGUI1/Subsystem2/Enabled Subsystem/Subsystem'
 * '<S52>'  : 'x86linuxcompiletest5/SendDataToGUI1/Subsystem2/Jdata/Joint1'
 * '<S53>'  : 'x86linuxcompiletest5/SendDataToGUI1/Subsystem2/Jdata/Joint2'
 * '<S54>'  : 'x86linuxcompiletest5/SendDataToGUI1/Subsystem2/Jdata/Joint3'
 * '<S55>'  : 'x86linuxcompiletest5/SendDataToGUI1/Subsystem2/Jdata/Joint4'
 * '<S56>'  : 'x86linuxcompiletest5/SendDataToGUI1/Subsystem2/Jdata/Joint5'
 * '<S57>'  : 'x86linuxcompiletest5/SendDataToGUI1/Subsystem2/Jdata/Joint6'
 * '<S58>'  : 'x86linuxcompiletest5/SendDataToGUI1/Subsystem2/Jdata/Joint7'
 * '<S59>'  : 'x86linuxcompiletest5/SendDataToGUI1/�㲥����/Increment Real World'
 * '<S60>'  : 'x86linuxcompiletest5/SendDataToGUI1/�㲥����/Wrap To Zero'
 * '<S61>'  : 'x86linuxcompiletest5/SendDataToGUI1/�㲥����1/Increment Real World'
 * '<S62>'  : 'x86linuxcompiletest5/SendDataToGUI1/�㲥����1/Wrap To Zero'
 * '<S63>'  : 'x86linuxcompiletest5/Subsystem/Counter Limited'
 * '<S64>'  : 'x86linuxcompiletest5/Subsystem/Counter Limited/Increment Real World'
 * '<S65>'  : 'x86linuxcompiletest5/Subsystem/Counter Limited/Wrap To Zero'
 * '<S66>'  : 'x86linuxcompiletest5/Subsystem1/Counter Limited'
 * '<S67>'  : 'x86linuxcompiletest5/Subsystem1/Counter Limited/Increment Real World'
 * '<S68>'  : 'x86linuxcompiletest5/Subsystem1/Counter Limited/Wrap To Zero'
 */
#endif                                 /* RTW_HEADER_x86linuxcompiletest5_h_ */
