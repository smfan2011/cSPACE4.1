/*
 * Code generation for system system '<Root>/DynamicCalculation2'
 *
 * Model                      : x86linuxcompiletest5
 * Model version              : 1.45
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Wed Apr 28 13:25:02 2021
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "DynamicsController.h"

/* Include model header file for global data */
#include "x86linuxcompiletest5.h"
#include "x86linuxcompiletest5_private.h"

/* Named constants for Chart: '<S2>/Chart' */
#define x86linuxcomp_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define x86linuxcompilete_IN_RunForward ((uint8_T)5U)
#define x86linuxcompilete_IN_RunInverse ((uint8_T)6U)
#define x86linuxcompiletes_IN_PlayDoing ((uint8_T)4U)
#define x86linuxcompiletest5_IN_GoToPos ((uint8_T)1U)
#define x86linuxcompiletest5_IN_Idle   ((uint8_T)2U)
#define x86linuxcompiletest5_IN_Init   ((uint8_T)3U)
#define x86linuxcompiletest5_IN_Start  ((uint8_T)7U)
#define x86linuxcompiletest5_IN_Stop   ((uint8_T)8U)

/*
 * Output and update for action system:
 *    '<S11>/PPmode'
 *    '<S11>/PVmode'
 *    '<S11>/PTmode'
 *    '<S11>/CSPmode'
 *    '<S11>/CSVmode'
 *    '<S11>/CSTmode'
 */
void x86linuxcompiletest5_PPmode(P_PPmode_x86linuxcompiletest5_T *localP)
{
  int32_T i;

  /* DataStoreWrite: '<S28>/Data Store Write' incorporates:
   *  Constant: '<S28>/PP'
   */
  for (i = 0; i < 7; i++) {
    Ethercomd[7 * i + 6] = localP->PP_Value[i];
  }

  /* End of DataStoreWrite: '<S28>/Data Store Write' */
}

/* Output and update for function-call system: '<S8>/ModeSet' */
void x86linuxcompiletest5_ModeSet(real_T rtu_in, P_ModeSet_x86linuxcompiletest_T
  *localP)
{
  real_T tmp;

  /* SwitchCase: '<S11>/Switch Case' */
  tmp = trunc(rtu_in);
  if (rtIsNaN(tmp) || rtIsInf(tmp)) {
    tmp = 0.0;
  } else {
    tmp = fmod(tmp, 4.294967296E+9);
  }

  switch (tmp < 0.0 ? -(int32_T)(uint32_T)-tmp : (int32_T)(uint32_T)tmp) {
   case 1:
    /* Outputs for IfAction SubSystem: '<S11>/PPmode' incorporates:
     *  ActionPort: '<S28>/Action Port'
     */
    x86linuxcompiletest5_PPmode(&localP->PPmode);

    /* End of Outputs for SubSystem: '<S11>/PPmode' */
    break;

   case 3:
    /* Outputs for IfAction SubSystem: '<S11>/PVmode' incorporates:
     *  ActionPort: '<S30>/Action Port'
     */
    x86linuxcompiletest5_PPmode(&localP->PVmode);

    /* End of Outputs for SubSystem: '<S11>/PVmode' */
    break;

   case 4:
    /* Outputs for IfAction SubSystem: '<S11>/PTmode' incorporates:
     *  ActionPort: '<S29>/Action Port'
     */
    x86linuxcompiletest5_PPmode(&localP->PTmode);

    /* End of Outputs for SubSystem: '<S11>/PTmode' */
    break;

   case 8:
    /* Outputs for IfAction SubSystem: '<S11>/CSPmode' incorporates:
     *  ActionPort: '<S25>/Action Port'
     */
    x86linuxcompiletest5_PPmode(&localP->CSPmode);

    /* End of Outputs for SubSystem: '<S11>/CSPmode' */
    break;

   case 9:
    /* Outputs for IfAction SubSystem: '<S11>/CSVmode' incorporates:
     *  ActionPort: '<S27>/Action Port'
     */
    x86linuxcompiletest5_PPmode(&localP->CSVmode);

    /* End of Outputs for SubSystem: '<S11>/CSVmode' */
    break;

   case 10:
    /* Outputs for IfAction SubSystem: '<S11>/CSTmode' incorporates:
     *  ActionPort: '<S26>/Action Port'
     */
    x86linuxcompiletest5_PPmode(&localP->CSTmode);

    /* End of Outputs for SubSystem: '<S11>/CSTmode' */
    break;
  }

  /* End of SwitchCase: '<S11>/Switch Case' */
}

/* Output and update for function-call system: '<S8>/StartProces' */
void x86linuxcompiletest_StartProces(P_StartProces_x86linuxcompile_T *localP)
{
  int32_T i;

  /* DataStoreWrite: '<S14>/Data Store Write' incorporates:
   *  Constant: '<S14>/Constant'
   */
  for (i = 0; i < 7; i++) {
    Ethercomd[7 * i] = localP->Constant_Value[i];
  }

  /* End of DataStoreWrite: '<S14>/Data Store Write' */
}

/* Output and update for function-call system: '<S8>/Cmdclear' */
void x86linuxcompiletest5_Cmdclear(P_Cmdclear_x86linuxcompiletes_T *localP)
{
  int32_T i;

  /* DataStoreWrite: '<S9>/Data Store Write8' incorporates:
   *  Constant: '<S9>/Constant'
   */
  for (i = 0; i < 7; i++) {
    Ethercomd[7 * i] = localP->Constant_Value[i];
  }

  /* End of DataStoreWrite: '<S9>/Data Store Write8' */
}

/*
 * Output and update for enable system:
 *    '<S12>/Enabled Subsystem13'
 *    '<S16>/Enabled Subsystem13'
 */
void x86linuxcomp_EnabledSubsystem13(boolean_T rtu_Enable,
  P_EnabledSubsystem13_x86linux_T *localP)
{
  int32_T i;

  /* Outputs for Enabled SubSystem: '<S12>/Enabled Subsystem13' incorporates:
   *  EnablePort: '<S33>/Enable'
   */
  if (rtu_Enable) {
    /* DataStoreWrite: '<S33>/Data Store Write7' incorporates:
     *  Constant: '<S33>/Constant2'
     */
    for (i = 0; i < 7; i++) {
      Ethercomd[7 * i] = localP->Constant2_Value[i];
    }

    /* End of DataStoreWrite: '<S33>/Data Store Write7' */
  }

  /* End of Outputs for SubSystem: '<S12>/Enabled Subsystem13' */
}

/* Output and update for function-call system: '<S8>/StopProces' */
void x86linuxcompiletest5_StopProces(P_StopProces_x86linuxcompilet_T *localP)
{
  int32_T i;

  /* DataStoreWrite: '<S15>/Data Store Write6' incorporates:
   *  Constant: '<S15>/Constant6'
   */
  for (i = 0; i < 7; i++) {
    Ethercomd[7 * i] = localP->Constant6_Value[i];
  }

  /* End of DataStoreWrite: '<S15>/Data Store Write6' */
}

/* System initialize for function-call system: '<S8>/GotoPlay' */
void x86linuxcompilete_GotoPlay_Init(B_GotoPlay_x86linuxcompiletes_T *localB,
  DW_GotoPlay_x86linuxcompilete_T *localDW, P_GotoPlay_x86linuxcompiletes_T
  *localP)
{
  /* Start for DataStoreMemory: '<S10>/Data Store Memory2' */
  localDW->enTRAJpoints = localP->DataStoreMemory2_InitialValue;

  /* Start for DataStoreMemory: '<S10>/Data Store Memory3' */
  localDW->Reset = localP->DataStoreMemory3_InitialValue;

  /* SystemInitialize for IfAction SubSystem: '<S10>/Playing' */
  /* SystemInitialize for Enabled SubSystem: '<S17>/�켣���ٵ㷢��' */
  /* SystemInitialize for MATLAB Function: '<S21>/MATLAB Function' */
  localDW->data_temp = 0U;

  /* SystemInitialize for Enabled SubSystem: '<S21>/Enabled Subsystem' */
  /* SystemInitialize for SignalConversion generated from: '<S23>/Out1' incorporates:
   *  Constant: '<S23>/Constant1'
   */
  localB->OutportBufferForOut1 = localP->Constant1_Value;

  /* End of SystemInitialize for SubSystem: '<S21>/Enabled Subsystem' */
  /* End of SystemInitialize for SubSystem: '<S17>/�켣���ٵ㷢��' */
  /* End of SystemInitialize for SubSystem: '<S10>/Playing' */

  /* SystemInitialize for Merge: '<S10>/Merge' */
  localB->Merge = localP->Merge_InitialOutput;
}

/* Output and update for function-call system: '<S8>/GotoPlay' */
void x86linuxcompiletest5_GotoPlay(real_T rtu_in,
  B_GotoPlay_x86linuxcompiletes_T *localB, DW_GotoPlay_x86linuxcompilete_T
  *localDW, P_GotoPlay_x86linuxcompiletes_T *localP)
{
  real_T rtb_p[6];
  real_T tmp_0;
  uint64_T tmp;
  uint64_T tmp_1;
  int32_T i;
  int32_T rtb_stepFlag;
  uint32_T qY;
  boolean_T rtb_Compare_l;

  /* SwitchCase: '<S10>/Switch Case' incorporates:
   *  Constant: '<S22>/Constant'
   *  DataStoreRead: '<S17>/Data Store Read1'
   *  DataTypeConversion: '<S21>/Data Type Conversion'
   *  Logic: '<S16>/NOT6'
   *  RelationalOperator: '<S22>/Compare'
   */
  tmp_0 = trunc(rtu_in);
  if (rtIsNaN(tmp_0) || rtIsInf(tmp_0)) {
    tmp_0 = 0.0;
  } else {
    tmp_0 = fmod(tmp_0, 4.294967296E+9);
  }

  switch (tmp_0 < 0.0 ? -(int32_T)(uint32_T)-tmp_0 : (int32_T)(uint32_T)tmp_0) {
   case 1:
    /* Outputs for IfAction SubSystem: '<S10>/GotoPos1' incorporates:
     *  ActionPort: '<S16>/Action Port'
     */
    /* DataStoreWrite: '<S16>/Data Store Write1' incorporates:
     *  Constant: '<S16>/Constant'
     */
    localDW->enTRAJpoints = localP->Constant_Value_m;

    /* DataStoreWrite: '<S16>/Data Store Write6' incorporates:
     *  Constant: '<S16>/Constant1'
     */
    localDW->Reset = localP->Constant1_Value_jl;

    /* Merge: '<S10>/Merge' incorporates:
     *  Constant: '<S16>/Constant2'
     *  SignalConversion generated from: '<S16>/Out1'
     */
    localB->Merge = localP->Constant2_Value;

    /* RelationalOperator: '<S18>/Compare' incorporates:
     *  Constant: '<S18>/Constant'
     *  DataStoreRead: '<S16>/Data Store Read'
     */
    rtb_Compare_l = (PTX == localP->CompareToConstant_const);

    /* Outputs for Enabled SubSystem: '<S16>/Enabled Subsystem12' incorporates:
     *  EnablePort: '<S19>/Enable'
     */
    if (rtb_Compare_l) {
      /* DataStoreWrite: '<S19>/Data Store Write8' incorporates:
       *  Constant: '<S19>/Constant'
       */
      for (i = 0; i < 7; i++) {
        Ethercomd[7 * i] = localP->Constant_Value[i];
      }

      /* End of DataStoreWrite: '<S19>/Data Store Write8' */

      /* DataStoreWrite: '<S19>/��Ϣ״̬' incorporates:
       *  Constant: '<S19>/Constant1'
       */
      PTX = localP->Constant1_Value_j;

      /* DataStoreWrite: '<S19>/Data Store Write5' incorporates:
       *  DataTypeConversion: '<S19>/Data Type Conversion13'
       *  DataTypeConversion: '<S19>/Data Type Conversion14'
       */
      for (i = 0; i < 6; i++) {
        /* DataTypeConversion: '<S19>/Data Type Conversion13' incorporates:
         *  Constant: '<S19>/�켣����'
         *  Gain: '<S19>/Gain6'
         */
        tmp_0 = floor((real_T)localP->Gain6_Gain_m * localP->_Value[i]);
        if (rtIsNaN(tmp_0) || rtIsInf(tmp_0)) {
          tmp_0 = 0.0;
        } else {
          tmp_0 = fmod(tmp_0, 4.294967296E+9);
        }

        Ethercomd[7 * i + 1] = (uint32_T)(tmp_0 < 0.0 ? -(int32_T)(uint32_T)
          -tmp_0 : (int32_T)(uint32_T)tmp_0);
      }

      /* End of DataStoreWrite: '<S19>/Data Store Write5' */
    }

    /* End of Outputs for SubSystem: '<S16>/Enabled Subsystem12' */

    /* Outputs for Enabled SubSystem: '<S16>/Enabled Subsystem13' */
    x86linuxcomp_EnabledSubsystem13(!rtb_Compare_l, &localP->EnabledSubsystem13);

    /* End of Outputs for SubSystem: '<S16>/Enabled Subsystem13' */
    /* End of Outputs for SubSystem: '<S10>/GotoPos1' */
    break;

   case 2:
    /* Outputs for IfAction SubSystem: '<S10>/Playing' incorporates:
     *  ActionPort: '<S17>/Action Port'
     */
    /* Outputs for Enabled SubSystem: '<S17>/�켣���ٵ㷢��' incorporates:
     *  EnablePort: '<S21>/Enable'
     */
    if (localDW->enTRAJpoints > 0) {
      /* MATLAB Function: '<S21>/MATLAB Function' incorporates:
       *  Constant: '<S21>/�켣����'
       *  Constant: '<S21>/�켣����'
       *  DataStoreRead: '<S21>/Data Store Read2'
       *  DataTypeConversion: '<S21>/Data Type Conversion2'
       */
      rtb_stepFlag = 0;
      if (localDW->Reset == 1) {
        localDW->data_temp = 0U;
      }

      tmp_1 = localDW->data_temp * 6UL;
      tmp = tmp_1;
      if (tmp_1 > 4294967295UL) {
        tmp = 4294967295UL;
      }

      qY = (uint32_T)tmp + 1U;
      if ((uint32_T)tmp + 1U < (uint32_T)tmp) {
        qY = MAX_uint32_T;
      }

      rtb_p[0] = x86linuxcompiletest5_P.PT_t[(int32_T)qY - 1];
      tmp = tmp_1;
      if (tmp_1 > 4294967295UL) {
        tmp = 4294967295UL;
      }

      qY = (uint32_T)tmp + 2U;
      if ((uint32_T)tmp + 2U < (uint32_T)tmp) {
        qY = MAX_uint32_T;
      }

      rtb_p[1] = x86linuxcompiletest5_P.PT_t[(int32_T)qY - 1];
      tmp = tmp_1;
      if (tmp_1 > 4294967295UL) {
        tmp = 4294967295UL;
      }

      qY = (uint32_T)tmp + 3U;
      if ((uint32_T)tmp + 3U < (uint32_T)tmp) {
        qY = MAX_uint32_T;
      }

      rtb_p[2] = x86linuxcompiletest5_P.PT_t[(int32_T)qY - 1];
      tmp = tmp_1;
      if (tmp_1 > 4294967295UL) {
        tmp = 4294967295UL;
      }

      qY = (uint32_T)tmp + 4U;
      if ((uint32_T)tmp + 4U < (uint32_T)tmp) {
        qY = MAX_uint32_T;
      }

      rtb_p[3] = x86linuxcompiletest5_P.PT_t[(int32_T)qY - 1];
      tmp = tmp_1;
      if (tmp_1 > 4294967295UL) {
        tmp = 4294967295UL;
      }

      qY = (uint32_T)tmp + 5U;
      if ((uint32_T)tmp + 5U < (uint32_T)tmp) {
        qY = MAX_uint32_T;
      }

      rtb_p[4] = x86linuxcompiletest5_P.PT_t[(int32_T)qY - 1];
      if (tmp_1 > 4294967295UL) {
        tmp_1 = 4294967295UL;
      }

      qY = (uint32_T)tmp_1 + 6U;
      if ((uint32_T)tmp_1 + 6U < (uint32_T)tmp_1) {
        qY = MAX_uint32_T;
      }

      rtb_p[5] = x86linuxcompiletest5_P.PT_t[(int32_T)qY - 1];
      qY = localDW->data_temp + 1U;
      if (localDW->data_temp + 1U < localDW->data_temp) {
        qY = MAX_uint32_T;
      }

      localDW->data_temp = qY;
      if (localDW->data_temp == (uint32_T)x86linuxcompiletest5_P.PT_c) {
        localDW->data_temp = 0U;
        rtb_stepFlag = 1;
      }

      /* End of MATLAB Function: '<S21>/MATLAB Function' */

      /* DataStoreWrite: '<S21>/Data Store Write5' incorporates:
       *  DataTypeConversion: '<S21>/Data Type Conversion13'
       *  DataTypeConversion: '<S21>/Data Type Conversion14'
       *  Gain: '<S21>/Gain6'
       */
      for (i = 0; i < 6; i++) {
        /* DataTypeConversion: '<S21>/Data Type Conversion13' incorporates:
         *  Gain: '<S21>/Gain6'
         */
        tmp_0 = floor(localP->Gain6_Gain * rtb_p[i]);
        if (rtIsNaN(tmp_0) || rtIsInf(tmp_0)) {
          tmp_0 = 0.0;
        } else {
          tmp_0 = fmod(tmp_0, 4.294967296E+9);
        }

        Ethercomd[7 * i + 1] = (uint32_T)(tmp_0 < 0.0 ? -(int32_T)(uint32_T)
          -tmp_0 : (int32_T)(uint32_T)tmp_0);
      }

      /* End of DataStoreWrite: '<S21>/Data Store Write5' */

      /* DataStoreWrite: '<S21>/Data Store Write8' incorporates:
       *  Constant: '<S21>/Constant'
       */
      for (i = 0; i < 7; i++) {
        Ethercomd[7 * i] = localP->Constant_Value_h[i];
      }

      /* End of DataStoreWrite: '<S21>/Data Store Write8' */

      /* DataStoreWrite: '<S21>/Data Store Write6' incorporates:
       *  Constant: '<S21>/Constant1'
       */
      localDW->Reset = localP->Constant1_Value_h;

      /* Outputs for Enabled SubSystem: '<S21>/Enabled Subsystem' incorporates:
       *  EnablePort: '<S23>/Enable'
       */
      if (rtb_stepFlag == localP->CompareToConstant_const_c) {
        /* DataStoreWrite: '<S23>/Data Store Write1' incorporates:
         *  Constant: '<S23>/Constant'
         */
        localDW->enTRAJpoints = localP->Constant_Value_p;

        /* SignalConversion generated from: '<S23>/Out1' incorporates:
         *  Constant: '<S23>/Constant1'
         */
        localB->OutportBufferForOut1 = localP->Constant1_Value;
      }

      /* End of Outputs for SubSystem: '<S21>/Enabled Subsystem' */
    }

    /* End of Outputs for SubSystem: '<S17>/�켣���ٵ㷢��' */

    /* Merge: '<S10>/Merge' incorporates:
     *  Constant: '<S22>/Constant'
     *  DataStoreRead: '<S17>/Data Store Read1'
     *  DataTypeConversion: '<S21>/Data Type Conversion'
     *  RelationalOperator: '<S22>/Compare'
     *  SignalConversion generated from: '<S17>/Out1'
     */
    localB->Merge = localB->OutportBufferForOut1;

    /* End of Outputs for SubSystem: '<S10>/Playing' */
    break;
  }

  /* End of SwitchCase: '<S10>/Switch Case' */
}

/* System initialize for atomic system: '<Root>/DynamicCalculation2' */
void DynamicsController_Init(void)
{
  x86linuxcompiletest5_DW.temporalCounter_i1 = 0U;
  x86linuxcompiletest5_DW.is_active_c3_x86linuxcompiletes = 0U;
  x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5 =
    x86linuxcomp_IN_NO_ACTIVE_CHILD;

  /* SystemInitialize for Chart: '<S2>/Chart' incorporates:
   *  SubSystem: '<S8>/GotoPlay'
   */
  x86linuxcompilete_GotoPlay_Init(&x86linuxcompiletest5_B.GotoPlay,
    &x86linuxcompiletest5_DW.GotoPlay, &x86linuxcompiletest5_P.GotoPlay);
}

/* Output and update for atomic system: '<Root>/DynamicCalculation2' */
void DynamicsController(void)
{
  real_T tmp;
  int32_T i;
  boolean_T rtb_Compare_o;

  /* Chart: '<S2>/Chart' incorporates:
   *  DataStoreRead: '<S2>/Data Store Read1'
   *  Logic: '<S12>/NOT6'
   *  Logic: '<S13>/NOT1'
   */
  if (x86linuxcompiletest5_DW.temporalCounter_i1 < 1023U) {
    x86linuxcompiletest5_DW.temporalCounter_i1++;
  }

  if (x86linuxcompiletest5_DW.is_active_c3_x86linuxcompiletes == 0U) {
    x86linuxcompiletest5_DW.is_active_c3_x86linuxcompiletes = 1U;
    x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5 =
      x86linuxcompiletest5_IN_Init;
    x86linuxcompiletest5_DW.temporalCounter_i1 = 0U;
  } else {
    switch (x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5) {
     case x86linuxcompiletest5_IN_GoToPos:
      if (x86linuxcompiletest5_DW.GUIcomd == 2.0) {
        x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5 =
          x86linuxcompiletest5_IN_Stop;

        /* Outputs for Function Call SubSystem: '<S8>/StopProces' */
        x86linuxcompiletest5_StopProces(&x86linuxcompiletest5_P.StopProces);

        /* End of Outputs for SubSystem: '<S8>/StopProces' */
      } else if ((x86linuxcompiletest5_DW.GUIcomd == 6.0) &&
                 (x86linuxcompiletest5_DW.Gostate == 1.0)) {
        x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5 =
          x86linuxcompiletes_IN_PlayDoing;

        /* Outputs for Function Call SubSystem: '<S8>/Cmdclear' */
        x86linuxcompiletest5_Cmdclear(&x86linuxcompiletest5_P.Cmdclear);

        /* End of Outputs for SubSystem: '<S8>/Cmdclear' */
        x86linuxcompiletest5_B.in = 8.0;

        /* Outputs for Function Call SubSystem: '<S8>/ModeSet' */
        x86linuxcompiletest5_ModeSet(x86linuxcompiletest5_B.in,
          &x86linuxcompiletest5_P.ModeSet);

        /* End of Outputs for SubSystem: '<S8>/ModeSet' */
        x86linuxcompiletest5_DW.Gostate = 0.0;
      } else {
        x86linuxcompiletest5_B.in_j = 1.0;

        /* Outputs for Function Call SubSystem: '<S8>/GotoPlay' */
        x86linuxcompiletest5_GotoPlay(x86linuxcompiletest5_B.in_j,
          &x86linuxcompiletest5_B.GotoPlay, &x86linuxcompiletest5_DW.GotoPlay,
          &x86linuxcompiletest5_P.GotoPlay);

        /* End of Outputs for SubSystem: '<S8>/GotoPlay' */
        x86linuxcompiletest5_DW.Gostate = x86linuxcompiletest5_B.GotoPlay.Merge;
      }
      break;

     case x86linuxcompiletest5_IN_Idle:
      if (x86linuxcompiletest5_DW.GUIcomd == 1.0) {
        x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5 =
          x86linuxcompiletest5_IN_Start;

        /* Outputs for Function Call SubSystem: '<S8>/StartProces' */
        x86linuxcompiletest_StartProces(&x86linuxcompiletest5_P.StartProces);

        /* End of Outputs for SubSystem: '<S8>/StartProces' */
      }
      break;

     case x86linuxcompiletest5_IN_Init:
      if (x86linuxcompiletest5_DW.temporalCounter_i1 >= 1000U) {
        x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5 =
          x86linuxcompiletest5_IN_Idle;
        x86linuxcompiletest5_B.in = 1.0;

        /* Outputs for Function Call SubSystem: '<S8>/ModeSet' */
        x86linuxcompiletest5_ModeSet(x86linuxcompiletest5_B.in,
          &x86linuxcompiletest5_P.ModeSet);

        /* End of Outputs for SubSystem: '<S8>/ModeSet' */
      }
      break;

     case x86linuxcompiletes_IN_PlayDoing:
      if (x86linuxcompiletest5_DW.GUIcomd == 2.0) {
        x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5 =
          x86linuxcompiletest5_IN_Stop;

        /* Outputs for Function Call SubSystem: '<S8>/StopProces' */
        x86linuxcompiletest5_StopProces(&x86linuxcompiletest5_P.StopProces);

        /* End of Outputs for SubSystem: '<S8>/StopProces' */
      } else if ((x86linuxcompiletest5_DW.GUIcomd == 5.0) &&
                 (x86linuxcompiletest5_DW.Gostate == 2.0)) {
        x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5 =
          x86linuxcompiletest5_IN_GoToPos;

        /* Outputs for Function Call SubSystem: '<S8>/Cmdclear' */
        x86linuxcompiletest5_Cmdclear(&x86linuxcompiletest5_P.Cmdclear);

        /* End of Outputs for SubSystem: '<S8>/Cmdclear' */
        x86linuxcompiletest5_B.in = 1.0;

        /* Outputs for Function Call SubSystem: '<S8>/ModeSet' */
        x86linuxcompiletest5_ModeSet(x86linuxcompiletest5_B.in,
          &x86linuxcompiletest5_P.ModeSet);

        /* End of Outputs for SubSystem: '<S8>/ModeSet' */
        x86linuxcompiletest5_DW.Gostate = 0.0;
      } else {
        x86linuxcompiletest5_B.in_j = 2.0;

        /* Outputs for Function Call SubSystem: '<S8>/GotoPlay' */
        x86linuxcompiletest5_GotoPlay(x86linuxcompiletest5_B.in_j,
          &x86linuxcompiletest5_B.GotoPlay, &x86linuxcompiletest5_DW.GotoPlay,
          &x86linuxcompiletest5_P.GotoPlay);

        /* End of Outputs for SubSystem: '<S8>/GotoPlay' */
        x86linuxcompiletest5_DW.Gostate = x86linuxcompiletest5_B.GotoPlay.Merge;
      }
      break;

     case x86linuxcompilete_IN_RunForward:
      if (x86linuxcompiletest5_DW.GUIcomd == 2.0) {
        x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5 =
          x86linuxcompiletest5_IN_Stop;

        /* Outputs for Function Call SubSystem: '<S8>/StopProces' */
        x86linuxcompiletest5_StopProces(&x86linuxcompiletest5_P.StopProces);

        /* End of Outputs for SubSystem: '<S8>/StopProces' */
      } else if (x86linuxcompiletest5_DW.GUIcomd == 4.0) {
        x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5 =
          x86linuxcompilete_IN_RunInverse;

        /* Outputs for Function Call SubSystem: '<S8>/Cmdclear' */
        x86linuxcompiletest5_Cmdclear(&x86linuxcompiletest5_P.Cmdclear);

        /* End of Outputs for SubSystem: '<S8>/Cmdclear' */
      } else {
        /* Outputs for Function Call SubSystem: '<S8>/RunForwardProces' */
        /* RelationalOperator: '<S31>/Compare' incorporates:
         *  Constant: '<S31>/Constant'
         *  DataStoreRead: '<S12>/Data Store Read'
         */
        rtb_Compare_o = (PTX == x86linuxcompiletest5_P.CompareToConstant_const);

        /* Outputs for Enabled SubSystem: '<S12>/Enabled Subsystem12' incorporates:
         *  EnablePort: '<S32>/Enable'
         */
        if (rtb_Compare_o) {
          /* DataStoreWrite: '<S32>/��Ϣ״̬' incorporates:
           *  Constant: '<S32>/Constant1'
           */
          PTX = x86linuxcompiletest5_P.Constant1_Value;
          for (i = 0; i < 7; i++) {
            /* DataStoreWrite: '<S32>/Data Store Write8' incorporates:
             *  Constant: '<S32>/Constant'
             */
            Ethercomd[7 * i] = x86linuxcompiletest5_P.Constant_Value[i];

            /* DataTypeConversion: '<S32>/Data Type Conversion13' incorporates:
             *  DataStoreRead: '<S32>/Data Store Read6'
             *  Gain: '<S32>/Gain6'
             */
            tmp = floor(x86linuxcompiletest5_DW.PosJoint[i << 1] *
                        x86linuxcompiletest5_P.Gain6_Gain);
            if (rtIsNaN(tmp) || rtIsInf(tmp)) {
              tmp = 0.0;
            } else {
              tmp = fmod(tmp, 4.294967296E+9);
            }

            /* DataStoreWrite: '<S32>/Data Store Write5' incorporates:
             *  DataStoreRead: '<S32>/Data Store Read6'
             *  DataTypeConversion: '<S32>/Data Type Conversion13'
             *  DataTypeConversion: '<S32>/Data Type Conversion14'
             */
            Ethercomd[7 * i + 1] = (uint32_T)(tmp < 0.0 ? -(int32_T)(uint32_T)
              -tmp : (int32_T)(uint32_T)tmp);
          }
        }

        /* End of Outputs for SubSystem: '<S12>/Enabled Subsystem12' */

        /* Outputs for Enabled SubSystem: '<S12>/Enabled Subsystem13' */
        x86linuxcomp_EnabledSubsystem13(!rtb_Compare_o,
          &x86linuxcompiletest5_P.EnabledSubsystem13);

        /* End of Outputs for SubSystem: '<S12>/Enabled Subsystem13' */
        /* End of Outputs for SubSystem: '<S8>/RunForwardProces' */
      }
      break;

     case x86linuxcompilete_IN_RunInverse:
      if (x86linuxcompiletest5_DW.GUIcomd == 2.0) {
        x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5 =
          x86linuxcompiletest5_IN_Stop;

        /* Outputs for Function Call SubSystem: '<S8>/StopProces' */
        x86linuxcompiletest5_StopProces(&x86linuxcompiletest5_P.StopProces);

        /* End of Outputs for SubSystem: '<S8>/StopProces' */
      } else if (x86linuxcompiletest5_DW.GUIcomd == 3.0) {
        x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5 =
          x86linuxcompilete_IN_RunForward;

        /* Outputs for Function Call SubSystem: '<S8>/Cmdclear' */
        x86linuxcompiletest5_Cmdclear(&x86linuxcompiletest5_P.Cmdclear);

        /* End of Outputs for SubSystem: '<S8>/Cmdclear' */
      } else {
        /* Outputs for Function Call SubSystem: '<S8>/RunInverseProces' */
        /* RelationalOperator: '<S34>/Compare' incorporates:
         *  Constant: '<S34>/Constant'
         *  DataStoreRead: '<S13>/Data Store Read'
         */
        rtb_Compare_o = (PTX == x86linuxcompiletest5_P.CompareToConstant_const_b);

        /* Outputs for Enabled SubSystem: '<S13>/Enabled Subsystem1' incorporates:
         *  EnablePort: '<S35>/Enable'
         */
        if (!rtb_Compare_o) {
          /* DataStoreWrite: '<S35>/Data Store Write7' incorporates:
           *  Constant: '<S35>/Constant'
           */
          for (i = 0; i < 7; i++) {
            Ethercomd[7 * i] = x86linuxcompiletest5_P.Constant_Value_n[i];
          }

          /* End of DataStoreWrite: '<S35>/Data Store Write7' */
        }

        /* End of Outputs for SubSystem: '<S13>/Enabled Subsystem1' */

        /* Outputs for Enabled SubSystem: '<S13>/Subsystem' incorporates:
         *  EnablePort: '<S36>/Enable'
         */
        if (rtb_Compare_o) {
          /* DataStoreWrite: '<S36>/��Ϣ״̬' incorporates:
           *  Constant: '<S36>/Constant1'
           */
          PTX = x86linuxcompiletest5_P.Constant1_Value_k;

          /* DataStoreWrite: '<S36>/Data Store Write8' incorporates:
           *  Constant: '<S36>/Constant2'
           */
          for (i = 0; i < 7; i++) {
            Ethercomd[7 * i] = x86linuxcompiletest5_P.Constant2_Value[i];
          }

          /* End of DataStoreWrite: '<S36>/Data Store Write8' */

          /* DataStoreRead: '<S36>/Data Store Read1' incorporates:
           *  Selector: '<S37>/Selector1'
           */
          for (i = 0; i < 6; i++) {
            x86linuxcompiletest5_B.Selector1[i] =
              x86linuxcompiletest5_DW.PosXYZ[i << 1];
          }

          /* End of DataStoreRead: '<S36>/Data Store Read1' */

          /* Outputs for Atomic SubSystem: '<S36>/�����ɶ���⣨�����⣩' */
          InverseSolverMDH();

          /* End of Outputs for SubSystem: '<S36>/�����ɶ���⣨�����⣩' */

          /* DataStoreWrite: '<S36>/Data Store Write' incorporates:
           *  Gain: '<S36>/Gain'
           *  Gain: '<S36>/Gain1'
           */
          x86linuxcompiletest5_DW.PosJoint[0] =
            x86linuxcompiletest5_P.Gain1_Gain *
            x86linuxcompiletest5_B.Selector1[0];
          x86linuxcompiletest5_DW.PosJoint[2] =
            x86linuxcompiletest5_P.Gain1_Gain *
            x86linuxcompiletest5_B.Selector1[1];
          x86linuxcompiletest5_DW.PosJoint[4] = x86linuxcompiletest5_P.Gain_Gain
            * x86linuxcompiletest5_B.Selector1[2] *
            x86linuxcompiletest5_P.Gain1_Gain;
          x86linuxcompiletest5_DW.PosJoint[6] =
            x86linuxcompiletest5_P.Gain1_Gain *
            x86linuxcompiletest5_B.Selector1[3];
          x86linuxcompiletest5_DW.PosJoint[8] =
            x86linuxcompiletest5_P.Gain1_Gain *
            x86linuxcompiletest5_B.Selector1[4];
          x86linuxcompiletest5_DW.PosJoint[10] =
            x86linuxcompiletest5_P.Gain1_Gain *
            x86linuxcompiletest5_B.Selector1[5];

          /* DataStoreWrite: '<S36>/Data Store Write5' incorporates:
           *  DataStoreRead: '<S36>/Data Store Read6'
           *  DataTypeConversion: '<S36>/Data Type Conversion13'
           *  DataTypeConversion: '<S36>/Data Type Conversion14'
           */
          for (i = 0; i < 7; i++) {
            /* DataTypeConversion: '<S36>/Data Type Conversion13' incorporates:
             *  DataStoreRead: '<S36>/Data Store Read6'
             *  Gain: '<S36>/Gain6'
             */
            tmp = floor(x86linuxcompiletest5_DW.PosJoint[i << 1] *
                        x86linuxcompiletest5_P.Gain6_Gain_k);
            if (rtIsNaN(tmp) || rtIsInf(tmp)) {
              tmp = 0.0;
            } else {
              tmp = fmod(tmp, 4.294967296E+9);
            }

            Ethercomd[7 * i + 1] = (uint32_T)(tmp < 0.0 ? -(int32_T)(uint32_T)
              -tmp : (int32_T)(uint32_T)tmp);
          }

          /* End of DataStoreWrite: '<S36>/Data Store Write5' */
        }

        /* End of Outputs for SubSystem: '<S13>/Subsystem' */
        /* End of Outputs for SubSystem: '<S8>/RunInverseProces' */
      }
      break;

     case x86linuxcompiletest5_IN_Start:
      if (x86linuxcompiletest5_DW.GUIcomd == 2.0) {
        x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5 =
          x86linuxcompiletest5_IN_Stop;

        /* Outputs for Function Call SubSystem: '<S8>/StopProces' */
        x86linuxcompiletest5_StopProces(&x86linuxcompiletest5_P.StopProces);

        /* End of Outputs for SubSystem: '<S8>/StopProces' */
      } else if (x86linuxcompiletest5_DW.GUIcomd == 3.0) {
        x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5 =
          x86linuxcompilete_IN_RunForward;

        /* Outputs for Function Call SubSystem: '<S8>/Cmdclear' */
        x86linuxcompiletest5_Cmdclear(&x86linuxcompiletest5_P.Cmdclear);

        /* End of Outputs for SubSystem: '<S8>/Cmdclear' */
      } else if (x86linuxcompiletest5_DW.GUIcomd == 4.0) {
        x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5 =
          x86linuxcompilete_IN_RunInverse;

        /* Outputs for Function Call SubSystem: '<S8>/Cmdclear' */
        x86linuxcompiletest5_Cmdclear(&x86linuxcompiletest5_P.Cmdclear);

        /* End of Outputs for SubSystem: '<S8>/Cmdclear' */
      } else {
        if (x86linuxcompiletest5_DW.GUIcomd == 5.0) {
          x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5 =
            x86linuxcompiletest5_IN_GoToPos;

          /* Outputs for Function Call SubSystem: '<S8>/Cmdclear' */
          x86linuxcompiletest5_Cmdclear(&x86linuxcompiletest5_P.Cmdclear);

          /* End of Outputs for SubSystem: '<S8>/Cmdclear' */
          x86linuxcompiletest5_B.in = 1.0;

          /* Outputs for Function Call SubSystem: '<S8>/ModeSet' */
          x86linuxcompiletest5_ModeSet(x86linuxcompiletest5_B.in,
            &x86linuxcompiletest5_P.ModeSet);

          /* End of Outputs for SubSystem: '<S8>/ModeSet' */
          x86linuxcompiletest5_DW.Gostate = 0.0;
        }
      }
      break;

     default:
      /* case IN_Stop: */
      if (x86linuxcompiletest5_DW.GUIcomd == 1.0) {
        x86linuxcompiletest5_DW.is_c3_x86linuxcompiletest5 =
          x86linuxcompiletest5_IN_Start;

        /* Outputs for Function Call SubSystem: '<S8>/StartProces' */
        x86linuxcompiletest_StartProces(&x86linuxcompiletest5_P.StartProces);

        /* End of Outputs for SubSystem: '<S8>/StartProces' */
      } else {
        x86linuxcompiletest5_B.in = 1.0;

        /* Outputs for Function Call SubSystem: '<S8>/ModeSet' */
        x86linuxcompiletest5_ModeSet(x86linuxcompiletest5_B.in,
          &x86linuxcompiletest5_P.ModeSet);

        /* End of Outputs for SubSystem: '<S8>/ModeSet' */
      }
      break;
    }
  }

  /* End of Chart: '<S2>/Chart' */
}
