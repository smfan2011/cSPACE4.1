/*
 * Code generation for system system '<S36>/�����ɶ���⣨�����⣩'
 * For more details, see corresponding source file InverseSolverMDH.c
 *
 */

#ifndef RTW_HEADER_InverseSolverMDH_h_
#define RTW_HEADER_InverseSolverMDH_h_
#include <math.h>
#include <string.h>
#ifndef x86linuxcompiletest5_COMMON_INCLUDES_
#define x86linuxcompiletest5_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                               /* x86linuxcompiletest5_COMMON_INCLUDES_ */

#include "x86linuxcompiletest5_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"

extern void InverseSolverFunction(void);
extern void RoundTheta(void);
extern void InverseSolverMDH(void);

#endif                                 /* RTW_HEADER_InverseSolverMDH_h_ */
