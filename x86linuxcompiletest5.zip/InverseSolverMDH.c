/*
 * Code generation for system system '<S36>/�����ɶ���⣨�����⣩'
 *
 * Model                      : x86linuxcompiletest5
 * Model version              : 1.45
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Wed Apr 28 13:25:02 2021
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "InverseSolverMDH.h"

/* Include model header file for global data */
#include "x86linuxcompiletest5.h"
#include "x86linuxcompiletest5_private.h"

/* Forward declaration for local functions */
static void x86linuxcompiletest5_mrdiv(const real_T A[16], const real_T B[16],
  real_T Y[16]);

/* Function for MATLAB Function: '<S37>/MATLAB Function' */
static void x86linuxcompiletest5_mrdiv(const real_T A[16], const real_T B[16],
  real_T Y[16])
{
  real_T b_A[16];
  real_T smax;
  real_T y;
  int32_T c_ix;
  int32_T d;
  int32_T d_j;
  int32_T ijA;
  int32_T ix;
  int32_T iy;
  int32_T jBcol;
  int32_T kBcol;
  int8_T ipiv[4];
  int8_T ipiv_0;
  memcpy(&b_A[0], &B[0], sizeof(real_T) << 4U);
  ipiv[0] = 1;
  ipiv[1] = 2;
  ipiv[2] = 3;
  ipiv[3] = 4;
  for (d_j = 0; d_j < 3; d_j++) {
    jBcol = d_j * 5;
    iy = 0;
    ix = jBcol;
    smax = fabs(b_A[jBcol]);
    for (kBcol = 2; kBcol <= 4 - d_j; kBcol++) {
      ix++;
      y = fabs(b_A[ix]);
      if (y > smax) {
        iy = kBcol - 1;
        smax = y;
      }
    }

    if (b_A[jBcol + iy] != 0.0) {
      if (iy != 0) {
        ix = d_j + iy;
        ipiv[d_j] = (int8_T)(ix + 1);
        smax = b_A[d_j];
        b_A[d_j] = b_A[ix];
        b_A[ix] = smax;
        smax = b_A[d_j + 4];
        b_A[d_j + 4] = b_A[ix + 4];
        b_A[ix + 4] = smax;
        smax = b_A[d_j + 8];
        b_A[d_j + 8] = b_A[ix + 8];
        b_A[ix + 8] = smax;
        smax = b_A[d_j + 12];
        b_A[d_j + 12] = b_A[ix + 12];
        b_A[ix + 12] = smax;
      }

      iy = (jBcol - d_j) + 4;
      for (ix = jBcol + 1; ix < iy; ix++) {
        b_A[ix] /= b_A[jBcol];
      }
    }

    iy = jBcol;
    ix = jBcol + 4;
    for (kBcol = 0; kBcol <= 2 - d_j; kBcol++) {
      if (b_A[ix] != 0.0) {
        smax = -b_A[ix];
        c_ix = jBcol + 1;
        d = (iy - d_j) + 8;
        for (ijA = iy + 5; ijA < d; ijA++) {
          b_A[ijA] += b_A[c_ix] * smax;
          c_ix++;
        }
      }

      ix += 4;
      iy += 4;
    }
  }

  memcpy(&Y[0], &A[0], sizeof(real_T) << 4U);
  for (d_j = 0; d_j < 4; d_j++) {
    jBcol = d_j << 2;
    for (ix = 0; ix < d_j; ix++) {
      kBcol = ix << 2;
      smax = b_A[ix + jBcol];
      if (smax != 0.0) {
        Y[jBcol] -= smax * Y[kBcol];
        Y[jBcol + 1] -= smax * Y[kBcol + 1];
        Y[jBcol + 2] -= smax * Y[kBcol + 2];
        Y[jBcol + 3] -= b_A[ix + jBcol] * Y[kBcol + 3];
      }
    }

    smax = 1.0 / b_A[d_j + jBcol];
    Y[jBcol] *= smax;
    Y[jBcol + 1] *= smax;
    Y[jBcol + 2] *= smax;
    Y[jBcol + 3] *= smax;
  }

  for (d_j = 3; d_j >= 0; d_j--) {
    jBcol = d_j << 2;
    for (ix = d_j + 2; ix < 5; ix++) {
      kBcol = (ix - 1) << 2;
      smax = b_A[(ix + jBcol) - 1];
      if (smax != 0.0) {
        Y[jBcol] -= smax * Y[kBcol];
        smax = b_A[(ix + jBcol) - 1];
        Y[jBcol + 1] -= smax * Y[kBcol + 1];
        Y[jBcol + 2] -= smax * Y[kBcol + 2];
        Y[jBcol + 3] -= smax * Y[kBcol + 3];
      }
    }
  }

  for (d_j = 2; d_j >= 0; d_j--) {
    ipiv_0 = ipiv[d_j];
    if (d_j + 1 != ipiv_0) {
      jBcol = d_j << 2;
      smax = Y[jBcol];
      ix = (ipiv_0 - 1) << 2;
      Y[jBcol] = Y[ix];
      Y[ix] = smax;
      smax = Y[jBcol + 1];
      Y[jBcol + 1] = Y[ix + 1];
      Y[ix + 1] = smax;
      smax = Y[jBcol + 2];
      Y[jBcol + 2] = Y[ix + 2];
      Y[ix + 2] = smax;
      smax = Y[jBcol + 3];
      Y[jBcol + 3] = Y[ix + 3];
      Y[ix + 3] = smax;
    }
  }
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  int32_T u0_0;
  int32_T u1_0;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else if (rtIsInf(u0) && rtIsInf(u1)) {
    if (u0 > 0.0) {
      u0_0 = 1;
    } else {
      u0_0 = -1;
    }

    if (u1 > 0.0) {
      u1_0 = 1;
    } else {
      u1_0 = -1;
    }

    y = atan2(u0_0, u1_0);
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = atan2(u0, u1);
  }

  return y;
}

/* Output and update for atomic system: '<S37>/MATLAB Function' */
void InverseSolverFunction(void)
{
  real_T T06[16];
  real_T c[16];
  real_T theta1_2_0[16];
  real_T A_idx_0;
  real_T B1_idx_1;
  real_T B1_idx_2;
  real_T B2_idx_2;
  real_T B_idx_0;
  real_T C234_idx_0;
  real_T C234_idx_3;
  real_T C_idx_0;
  real_T S234_idx_0;
  real_T S5_1;
  real_T S5_3;
  real_T alpha;
  real_T beta;
  real_T gama;
  real_T theta1_2;
  real_T theta234_idx_1;
  real_T theta234_idx_3;
  real_T theta23_idx_0;
  real_T theta5_2;
  real_T theta5_3;
  real_T theta5_4;
  real_T theta6_1;
  int32_T i;
  int32_T i_0;
  int32_T j;
  int32_T k;
  memset(&x86linuxcompiletest5_B.AllSloverTheta[0], 0, 48U * sizeof(real_T));

  /* Selector: '<S37>/Selector1' */
  gama = x86linuxcompiletest5_B.Selector1[3] * 3.1415926535897931 / 180.0;
  beta = x86linuxcompiletest5_B.Selector1[4] * 3.1415926535897931 / 180.0;
  alpha = x86linuxcompiletest5_B.Selector1[5] * 3.1415926535897931 / 180.0;
  theta1_2 = cos(beta);
  beta = sin(beta);
  A_idx_0 = cos(gama);
  gama = sin(gama);
  B1_idx_2 = sin(alpha);
  B2_idx_2 = cos(alpha);
  theta1_2_0[0] = theta1_2 * A_idx_0;
  theta1_2_0[4] = -theta1_2 * gama;
  theta1_2_0[8] = beta;

  /* Selector: '<S37>/Selector1' */
  theta1_2_0[12] = x86linuxcompiletest5_B.Selector1[0];
  theta1_2_0[1] = B1_idx_2 * beta * A_idx_0 + B2_idx_2 * gama;
  theta1_2_0[5] = -B1_idx_2 * beta * gama + B2_idx_2 * A_idx_0;
  theta1_2_0[9] = -sin(alpha) * theta1_2;

  /* Selector: '<S37>/Selector1' */
  theta1_2_0[13] = x86linuxcompiletest5_B.Selector1[1];
  theta1_2_0[2] = -B2_idx_2 * beta * A_idx_0 + B1_idx_2 * gama;
  theta1_2_0[6] = B2_idx_2 * beta * gama + B1_idx_2 * A_idx_0;
  theta1_2_0[10] = B2_idx_2 * theta1_2;

  /* Selector: '<S37>/Selector1' */
  theta1_2_0[14] = x86linuxcompiletest5_B.Selector1[2];
  c[1] = 0.0;
  c[5] = 1.0;
  c[9] = -0.0;

  /* Constant: '<S37>/DH����' */
  c[13] = -0.0 * x86linuxcompiletest5_P.DH_Value[17];
  c[2] = 0.0;
  c[6] = 0.0;
  c[10] = 1.0;

  /* Constant: '<S37>/DH����' */
  c[14] = x86linuxcompiletest5_P.DH_Value[17];
  theta1_2_0[3] = 0.0;
  c[0] = 1.0;
  c[3] = 0.0;
  theta1_2_0[7] = 0.0;
  c[4] = 0.0;
  c[7] = 0.0;
  theta1_2_0[11] = 0.0;
  c[8] = 0.0;
  c[11] = 0.0;
  theta1_2_0[15] = 1.0;
  c[12] = 0.0;
  c[15] = 1.0;
  x86linuxcompiletest5_mrdiv(theta1_2_0, c, T06);
  k = 0;

  /* Constant: '<S37>/DH����' */
  alpha = (T06[12] * T06[12] + T06[13] * T06[13]) -
    x86linuxcompiletest5_P.DH_Value[15] * x86linuxcompiletest5_P.DH_Value[15];
  if (!(alpha < -1.0E-6)) {
    if ((alpha >= -1.0E-6) && (alpha < 0.0)) {
      alpha = 0.0;
    }

    theta1_2 = sqrt(alpha);
    beta = rt_atan2d_snf(T06[13], T06[12]);

    /* Constant: '<S37>/DH����' */
    alpha = beta - rt_atan2d_snf(-x86linuxcompiletest5_P.DH_Value[15], theta1_2);
    theta1_2 = beta - rt_atan2d_snf(-x86linuxcompiletest5_P.DH_Value[15],
      -theta1_2);
    beta = cos(alpha);
    A_idx_0 = sin(alpha);
    gama = -A_idx_0 * T06[0] + beta * T06[1];
    B1_idx_2 = -sin(alpha) * T06[4] + beta * T06[5];
    S5_1 = sqrt(gama * gama + B1_idx_2 * B1_idx_2);
    gama = rt_atan2d_snf(S5_1, A_idx_0 * T06[8] - beta * T06[9]);
    B1_idx_2 = -sin(alpha) * T06[0] + cos(alpha) * T06[1];
    B2_idx_2 = -sin(alpha) * T06[4] + cos(alpha) * T06[5];
    B1_idx_1 = B1_idx_2 * B1_idx_2 + B2_idx_2 * B2_idx_2;
    theta234_idx_1 = sqrt(B1_idx_1);
    theta5_2 = rt_atan2d_snf(-theta234_idx_1, sin(alpha) * T06[8] - cos(alpha) *
      T06[9]);
    B1_idx_2 = cos(theta1_2);
    B2_idx_2 = sin(theta1_2);
    S5_3 = -B2_idx_2 * T06[0] + B1_idx_2 * T06[1];
    theta5_3 = -sin(theta1_2) * T06[4] + B1_idx_2 * T06[5];
    S5_3 = sqrt(S5_3 * S5_3 + theta5_3 * theta5_3);
    theta5_3 = rt_atan2d_snf(S5_3, B2_idx_2 * T06[8] - B1_idx_2 * T06[9]);
    theta234_idx_3 = -sin(theta1_2) * T06[0] + cos(theta1_2) * T06[1];
    theta5_4 = -sin(theta1_2) * T06[4] + cos(theta1_2) * T06[5];
    C234_idx_3 = theta234_idx_3 * theta234_idx_3 + theta5_4 * theta5_4;
    theta234_idx_3 = sqrt(C234_idx_3);
    theta5_4 = rt_atan2d_snf(-theta234_idx_3, sin(theta1_2) * T06[8] - cos
      (theta1_2) * T06[9]);
    if (fabs(S5_1) > 1.0E-6) {
      theta6_1 = rt_atan2d_snf((-sin(alpha) * T06[4] + cos(alpha) * T06[5]) /
        S5_1, (A_idx_0 * T06[0] - cos(alpha) * T06[1]) / S5_1);
      S234_idx_0 = -T06[10] / S5_1;
      C234_idx_0 = -(beta * T06[8] + A_idx_0 * T06[9]) / S5_1;
      S5_1 = rt_atan2d_snf(S234_idx_0, C234_idx_0);

      /* Constant: '<S37>/DH����' */
      S234_idx_0 = (beta * T06[12] + A_idx_0 * T06[13]) -
        x86linuxcompiletest5_P.DH_Value[16] * S234_idx_0;
      C234_idx_0 = (T06[14] - x86linuxcompiletest5_P.DH_Value[12]) +
        x86linuxcompiletest5_P.DH_Value[16] * C234_idx_0;
      A_idx_0 = -2.0 * C234_idx_0 * x86linuxcompiletest5_P.DH_Value[8];
      B_idx_0 = 2.0 * S234_idx_0 * x86linuxcompiletest5_P.DH_Value[8];
      C_idx_0 = ((S234_idx_0 * S234_idx_0 + C234_idx_0 * C234_idx_0) +
                 x86linuxcompiletest5_P.DH_Value[8] *
                 x86linuxcompiletest5_P.DH_Value[8]) -
        x86linuxcompiletest5_P.DH_Value[9] * x86linuxcompiletest5_P.DH_Value[9];
      beta = (A_idx_0 * A_idx_0 + B_idx_0 * B_idx_0) - C_idx_0 * C_idx_0;
      if (beta >= 0.0) {
        beta = sqrt(beta);
        A_idx_0 = rt_atan2d_snf(B_idx_0, A_idx_0);
        B_idx_0 = A_idx_0 - rt_atan2d_snf(C_idx_0, beta);
        C_idx_0 = A_idx_0 - rt_atan2d_snf(C_idx_0, -beta);

        /* Constant: '<S37>/DH����' */
        theta23_idx_0 = rt_atan2d_snf((C234_idx_0 -
          x86linuxcompiletest5_P.DH_Value[8] * sin(B_idx_0)) /
          x86linuxcompiletest5_P.DH_Value[9], (S234_idx_0 -
          x86linuxcompiletest5_P.DH_Value[8] * cos(B_idx_0)) /
          x86linuxcompiletest5_P.DH_Value[9]);
        S234_idx_0 = rt_atan2d_snf((C234_idx_0 -
          x86linuxcompiletest5_P.DH_Value[8] * sin(C_idx_0)) /
          x86linuxcompiletest5_P.DH_Value[9], (S234_idx_0 -
          x86linuxcompiletest5_P.DH_Value[8] * cos(C_idx_0)) /
          x86linuxcompiletest5_P.DH_Value[9]);
        x86linuxcompiletest5_B.AllSloverTheta[0] = alpha;

        /* Constant: '<S37>/DH����' */
        beta = x86linuxcompiletest5_P.DH_Value[19] * 3.1415926535897931 / 180.0;
        x86linuxcompiletest5_B.AllSloverTheta[8] = B_idx_0 - beta;
        x86linuxcompiletest5_B.AllSloverTheta[16] = theta23_idx_0 - B_idx_0;

        /* Constant: '<S37>/DH����' */
        A_idx_0 = x86linuxcompiletest5_P.DH_Value[21] * 3.1415926535897931 /
          180.0;
        x86linuxcompiletest5_B.AllSloverTheta[24] = (S5_1 - theta23_idx_0) -
          A_idx_0;
        x86linuxcompiletest5_B.AllSloverTheta[32] = gama;
        x86linuxcompiletest5_B.AllSloverTheta[40] = theta6_1;
        x86linuxcompiletest5_B.AllSloverTheta[1] = alpha;
        x86linuxcompiletest5_B.AllSloverTheta[9] = C_idx_0 - beta;
        x86linuxcompiletest5_B.AllSloverTheta[17] = S234_idx_0 - C_idx_0;
        x86linuxcompiletest5_B.AllSloverTheta[25] = (S5_1 - S234_idx_0) -
          A_idx_0;
        x86linuxcompiletest5_B.AllSloverTheta[33] = gama;
        x86linuxcompiletest5_B.AllSloverTheta[41] = theta6_1;
        k = 2;
      }
    }

    if (fabs(-sqrt(B1_idx_1)) > 1.0E-6) {
      gama = rt_atan2d_snf((-sin(alpha) * T06[4] + cos(alpha) * T06[5]) /
                           -theta234_idx_1, (sin(alpha) * T06[0] - cos(alpha) *
        T06[1]) / -theta234_idx_1);
      beta = -T06[10] / -theta234_idx_1;
      A_idx_0 = -(cos(alpha) * T06[8] + sin(alpha) * T06[9]) / -theta234_idx_1;
      theta234_idx_1 = rt_atan2d_snf(beta, A_idx_0);

      /* Constant: '<S37>/DH����' */
      B1_idx_1 = (cos(alpha) * T06[12] + sin(alpha) * T06[13]) -
        x86linuxcompiletest5_P.DH_Value[16] * beta;
      theta6_1 = (T06[14] - x86linuxcompiletest5_P.DH_Value[12]) +
        x86linuxcompiletest5_P.DH_Value[16] * A_idx_0;
      A_idx_0 = -2.0 * theta6_1 * x86linuxcompiletest5_P.DH_Value[8];
      S5_1 = 2.0 * B1_idx_1 * x86linuxcompiletest5_P.DH_Value[8];
      S234_idx_0 = ((B1_idx_1 * B1_idx_1 + theta6_1 * theta6_1) +
                    x86linuxcompiletest5_P.DH_Value[8] *
                    x86linuxcompiletest5_P.DH_Value[8]) -
        x86linuxcompiletest5_P.DH_Value[9] * x86linuxcompiletest5_P.DH_Value[9];
      beta = (A_idx_0 * A_idx_0 + S5_1 * S5_1) - S234_idx_0 * S234_idx_0;
      if (beta >= 0.0) {
        beta = sqrt(beta);
        A_idx_0 = rt_atan2d_snf(S5_1, A_idx_0);
        S5_1 = A_idx_0 - rt_atan2d_snf(S234_idx_0, beta);
        S234_idx_0 = A_idx_0 - rt_atan2d_snf(S234_idx_0, -beta);

        /* Constant: '<S37>/DH����' */
        C234_idx_0 = rt_atan2d_snf((theta6_1 - x86linuxcompiletest5_P.DH_Value[8]
          * sin(S5_1)) / x86linuxcompiletest5_P.DH_Value[9], (B1_idx_1 -
          x86linuxcompiletest5_P.DH_Value[8] * cos(S5_1)) /
          x86linuxcompiletest5_P.DH_Value[9]);
        B1_idx_1 = rt_atan2d_snf((theta6_1 - x86linuxcompiletest5_P.DH_Value[8] *
          sin(S234_idx_0)) / x86linuxcompiletest5_P.DH_Value[9], (B1_idx_1 -
          x86linuxcompiletest5_P.DH_Value[8] * cos(S234_idx_0)) /
          x86linuxcompiletest5_P.DH_Value[9]);
        x86linuxcompiletest5_B.AllSloverTheta[k] = alpha;

        /* Constant: '<S37>/DH����' */
        beta = x86linuxcompiletest5_P.DH_Value[19] * 3.1415926535897931 / 180.0;
        x86linuxcompiletest5_B.AllSloverTheta[k + 8] = S5_1 - beta;
        x86linuxcompiletest5_B.AllSloverTheta[k + 16] = C234_idx_0 - S5_1;

        /* Constant: '<S37>/DH����' */
        A_idx_0 = x86linuxcompiletest5_P.DH_Value[21] * 3.1415926535897931 /
          180.0;
        x86linuxcompiletest5_B.AllSloverTheta[k + 24] = (theta234_idx_1 -
          C234_idx_0) - A_idx_0;
        x86linuxcompiletest5_B.AllSloverTheta[k + 32] = theta5_2;
        x86linuxcompiletest5_B.AllSloverTheta[k + 40] = gama;
        x86linuxcompiletest5_B.AllSloverTheta[k + 1] = alpha;
        x86linuxcompiletest5_B.AllSloverTheta[k + 9] = S234_idx_0 - beta;
        x86linuxcompiletest5_B.AllSloverTheta[k + 17] = B1_idx_1 - S234_idx_0;
        x86linuxcompiletest5_B.AllSloverTheta[k + 25] = (theta234_idx_1 -
          B1_idx_1) - A_idx_0;
        x86linuxcompiletest5_B.AllSloverTheta[k + 33] = theta5_2;
        x86linuxcompiletest5_B.AllSloverTheta[k + 41] = gama;
        k += 2;
      }
    }

    if (fabs(S5_3) > 1.0E-6) {
      alpha = rt_atan2d_snf((-sin(theta1_2) * T06[4] + cos(theta1_2) * T06[5]) /
                            S5_3, (B2_idx_2 * T06[0] - cos(theta1_2) * T06[1]) /
                            S5_3);
      beta = -T06[10] / S5_3;
      gama = -(B1_idx_2 * T06[8] + B2_idx_2 * T06[9]) / S5_3;
      S5_3 = rt_atan2d_snf(beta, gama);

      /* Constant: '<S37>/DH����' */
      B1_idx_2 = (B1_idx_2 * T06[12] + B2_idx_2 * T06[13]) -
        x86linuxcompiletest5_P.DH_Value[16] * beta;
      B2_idx_2 = (T06[14] - x86linuxcompiletest5_P.DH_Value[12]) +
        x86linuxcompiletest5_P.DH_Value[16] * gama;
      gama = -2.0 * B2_idx_2 * x86linuxcompiletest5_P.DH_Value[8];
      A_idx_0 = 2.0 * B1_idx_2 * x86linuxcompiletest5_P.DH_Value[8];
      theta5_2 = ((B1_idx_2 * B1_idx_2 + B2_idx_2 * B2_idx_2) +
                  x86linuxcompiletest5_P.DH_Value[8] *
                  x86linuxcompiletest5_P.DH_Value[8]) -
        x86linuxcompiletest5_P.DH_Value[9] * x86linuxcompiletest5_P.DH_Value[9];
      beta = (gama * gama + A_idx_0 * A_idx_0) - theta5_2 * theta5_2;
      if (beta >= 0.0) {
        beta = sqrt(beta);
        A_idx_0 = rt_atan2d_snf(A_idx_0, gama);
        gama = A_idx_0 - rt_atan2d_snf(theta5_2, beta);
        theta5_2 = A_idx_0 - rt_atan2d_snf(theta5_2, -beta);

        /* Constant: '<S37>/DH����' */
        theta234_idx_1 = rt_atan2d_snf((B2_idx_2 -
          x86linuxcompiletest5_P.DH_Value[8] * sin(gama)) /
          x86linuxcompiletest5_P.DH_Value[9], (B1_idx_2 -
          x86linuxcompiletest5_P.DH_Value[8] * cos(gama)) /
          x86linuxcompiletest5_P.DH_Value[9]);
        B1_idx_2 = rt_atan2d_snf((B2_idx_2 - x86linuxcompiletest5_P.DH_Value[8] *
          sin(theta5_2)) / x86linuxcompiletest5_P.DH_Value[9], (B1_idx_2 -
          x86linuxcompiletest5_P.DH_Value[8] * cos(theta5_2)) /
          x86linuxcompiletest5_P.DH_Value[9]);
        x86linuxcompiletest5_B.AllSloverTheta[k] = theta1_2;

        /* Constant: '<S37>/DH����' */
        beta = x86linuxcompiletest5_P.DH_Value[19] * 3.1415926535897931 / 180.0;
        x86linuxcompiletest5_B.AllSloverTheta[k + 8] = gama - beta;
        x86linuxcompiletest5_B.AllSloverTheta[k + 16] = theta234_idx_1 - gama;

        /* Constant: '<S37>/DH����' */
        A_idx_0 = x86linuxcompiletest5_P.DH_Value[21] * 3.1415926535897931 /
          180.0;
        x86linuxcompiletest5_B.AllSloverTheta[k + 24] = (S5_3 - theta234_idx_1)
          - A_idx_0;
        x86linuxcompiletest5_B.AllSloverTheta[k + 32] = theta5_3;
        x86linuxcompiletest5_B.AllSloverTheta[k + 40] = alpha;
        x86linuxcompiletest5_B.AllSloverTheta[k + 1] = theta1_2;
        x86linuxcompiletest5_B.AllSloverTheta[k + 9] = theta5_2 - beta;
        x86linuxcompiletest5_B.AllSloverTheta[k + 17] = B1_idx_2 - theta5_2;
        x86linuxcompiletest5_B.AllSloverTheta[k + 25] = (S5_3 - B1_idx_2) -
          A_idx_0;
        x86linuxcompiletest5_B.AllSloverTheta[k + 33] = theta5_3;
        x86linuxcompiletest5_B.AllSloverTheta[k + 41] = alpha;
        k += 2;
      }
    }

    if (fabs(-sqrt(C234_idx_3)) > 1.0E-6) {
      alpha = rt_atan2d_snf((-sin(theta1_2) * T06[4] + cos(theta1_2) * T06[5]) /
                            -theta234_idx_3, (sin(theta1_2) * T06[0] - cos
        (theta1_2) * T06[1]) / -theta234_idx_3);
      theta5_3 = -T06[10] / -theta234_idx_3;
      C234_idx_3 = -(cos(theta1_2) * T06[8] + sin(theta1_2) * T06[9]) /
        -theta234_idx_3;
      theta234_idx_3 = rt_atan2d_snf(theta5_3, C234_idx_3);

      /* Constant: '<S37>/DH����' */
      theta5_3 = (cos(theta1_2) * T06[12] + sin(theta1_2) * T06[13]) -
        x86linuxcompiletest5_P.DH_Value[16] * theta5_3;
      C234_idx_3 = (T06[14] - x86linuxcompiletest5_P.DH_Value[12]) +
        x86linuxcompiletest5_P.DH_Value[16] * C234_idx_3;
      B1_idx_2 = -2.0 * C234_idx_3 * x86linuxcompiletest5_P.DH_Value[8];
      S5_3 = 2.0 * theta5_3 * x86linuxcompiletest5_P.DH_Value[8];
      B2_idx_2 = ((theta5_3 * theta5_3 + C234_idx_3 * C234_idx_3) +
                  x86linuxcompiletest5_P.DH_Value[8] *
                  x86linuxcompiletest5_P.DH_Value[8]) -
        x86linuxcompiletest5_P.DH_Value[9] * x86linuxcompiletest5_P.DH_Value[9];
      beta = (B1_idx_2 * B1_idx_2 + S5_3 * S5_3) - B2_idx_2 * B2_idx_2;
      if (beta >= 0.0) {
        beta = sqrt(beta);
        A_idx_0 = rt_atan2d_snf(S5_3, B1_idx_2);
        B1_idx_2 = A_idx_0 - rt_atan2d_snf(B2_idx_2, beta);
        B2_idx_2 = A_idx_0 - rt_atan2d_snf(B2_idx_2, -beta);

        /* Constant: '<S37>/DH����' */
        S5_3 = rt_atan2d_snf((C234_idx_3 - x86linuxcompiletest5_P.DH_Value[8] *
                              sin(B1_idx_2)) / x86linuxcompiletest5_P.DH_Value[9],
                             (theta5_3 - x86linuxcompiletest5_P.DH_Value[8] *
                              cos(B1_idx_2)) / x86linuxcompiletest5_P.DH_Value[9]);
        theta5_3 = rt_atan2d_snf((C234_idx_3 - x86linuxcompiletest5_P.DH_Value[8]
          * sin(B2_idx_2)) / x86linuxcompiletest5_P.DH_Value[9], (theta5_3 -
          x86linuxcompiletest5_P.DH_Value[8] * cos(B2_idx_2)) /
          x86linuxcompiletest5_P.DH_Value[9]);
        x86linuxcompiletest5_B.AllSloverTheta[k] = theta1_2;

        /* Constant: '<S37>/DH����' */
        beta = x86linuxcompiletest5_P.DH_Value[19] * 3.1415926535897931 / 180.0;
        x86linuxcompiletest5_B.AllSloverTheta[k + 8] = B1_idx_2 - beta;
        x86linuxcompiletest5_B.AllSloverTheta[k + 16] = S5_3 - B1_idx_2;

        /* Constant: '<S37>/DH����' */
        A_idx_0 = x86linuxcompiletest5_P.DH_Value[21] * 3.1415926535897931 /
          180.0;
        x86linuxcompiletest5_B.AllSloverTheta[k + 24] = (theta234_idx_3 - S5_3)
          - A_idx_0;
        x86linuxcompiletest5_B.AllSloverTheta[k + 32] = theta5_4;
        x86linuxcompiletest5_B.AllSloverTheta[k + 40] = alpha;
        x86linuxcompiletest5_B.AllSloverTheta[k + 1] = theta1_2;
        x86linuxcompiletest5_B.AllSloverTheta[k + 9] = B2_idx_2 - beta;
        x86linuxcompiletest5_B.AllSloverTheta[k + 17] = theta5_3 - B2_idx_2;
        x86linuxcompiletest5_B.AllSloverTheta[k + 25] = (theta234_idx_3 -
          theta5_3) - A_idx_0;
        x86linuxcompiletest5_B.AllSloverTheta[k + 33] = theta5_4;
        x86linuxcompiletest5_B.AllSloverTheta[k + 41] = alpha;
        k += 2;
      }
    }

    if (k > 0) {
      for (i_0 = 0; i_0 < 48; i_0++) {
        x86linuxcompiletest5_B.AllSloverTheta[i_0] =
          x86linuxcompiletest5_B.AllSloverTheta[i_0] * 180.0 /
          3.1415926535897931;
      }

      for (i = 0; i < k; i++) {
        for (j = 0; j < 6; j++) {
          i_0 = (j << 3) + i;
          beta = x86linuxcompiletest5_B.AllSloverTheta[i_0];
          if (beta <= -180.0) {
            x86linuxcompiletest5_B.AllSloverTheta[i_0] = beta + 360.0;
          } else {
            if (beta > 180.0) {
              x86linuxcompiletest5_B.AllSloverTheta[i_0] -= 360.0;
            }
          }
        }
      }
    }
  }
}

/* Output and update for atomic system: '<S37>/Round' */
void RoundTheta(void)
{
  real_T Theta[48];
  real_T Theta_0;
  int32_T Theta_tmp;
  int32_T i;
  int32_T j;
  memcpy(&Theta[0], &x86linuxcompiletest5_B.AllSloverTheta[0], 48U * sizeof
         (real_T));
  for (j = 0; j < 6; j++) {
    for (i = 0; i < 8; i++) {
      Theta_tmp = (j << 3) + i;
      Theta_0 = Theta[Theta_tmp];
      if (((-1.0E-6 < Theta_0) && (Theta_0 < 0.0)) || ((Theta_0 > 0.0) &&
           (Theta_0 < 1.0E-6))) {
        Theta_0 = 0.0;
      }

      x86linuxcompiletest5_B.THETA[Theta_tmp] = Theta_0;
      Theta[Theta_tmp] = Theta_0;
    }
  }
}

/* Output and update for atomic system: '<S36>/�����ɶ���⣨�����⣩' */
void InverseSolverMDH(void)
{
  int32_T i;

  /* MATLAB Function: '<S37>/MATLAB Function' */
  InverseSolverFunction();

  /* MATLAB Function: '<S37>/Round' */
  RoundTheta();

  /* Selector: '<S37>/Selector1' incorporates:
   *  Constant: '<S37>/Choice'
   */
  for (i = 0; i < 6; i++) {
    x86linuxcompiletest5_B.Selector1[i] = x86linuxcompiletest5_B.THETA[((i << 3)
      + (int32_T)x86linuxcompiletest5_P.Choice_Value) - 1];
  }

  /* End of Selector: '<S37>/Selector1' */
}
