/*
 * x86linuxcompiletest5.c
 *
 * Code generation for model "x86linuxcompiletest5".
 *
 * Model version              : 1.45
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Wed Apr 28 13:25:02 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "x86linuxcompiletest5.h"
#include "x86linuxcompiletest5_private.h"

/* user code (top of source file) */
/* System '<Root>' */
sem_t *sem_1;                          //�����ź���
sem_t *sem_2;
int shmid[2];                          //�����ڴ�id
void *shmaddr[2];                      //�����ڴ�ӳ���ַ��
Shm_Queue_t *shared[2];
Shm shm_send;                          //�����ڴ�ṹ��
Shm shm_recv;                          //�����ڴ�ṹ��

/*���������ڴ�*/
static unsigned int SHMflagcount = 0;
void* init_shm(int *shmid, const char *pathname, int size) //pathname=SHM_PATH_A
{
  void *shmaddr= NULL;
  key_t key = 0;
  SHMflagcount++;
  if (SHMflagcount == 1) {
    key = ftok(pathname,SHM_FLAG_A);
  } else if (SHMflagcount == 2) {
    key = ftok(pathname,SHM_FLAG_B);
  } else
    return NULL;
  if (-1 == key) {
    perror("shm_key ftok fail\n");
    return NULL;
  }

  *shmid = shmget((key_t)key,size,0666 | IPC_CREAT);
  if (0 > *shmid) {
    //printf("%s:%d\n",__func__,__LINE__);
    return NULL;
  }

  *shmid = shmget((key_t)key,size,IPC_CREAT | IPC_EXCL | 0664);
  if (-1 == *shmid) {
    if (errno == EEXIST) {
      *shmid = shmget((key_t)key,size,0664);
    } else {
      perror("shmget fail \n");
      return NULL;
    }
  }

  shmaddr = shmat(*shmid,NULL,0);
  if (NULL == shmaddr) {
    perror("shmat fail \n");
    return NULL;
  }

  return shmaddr;
}

/*ɾ�������ڴ�*/
int del_shm(void *shm)
{
  int rv;

  //ɾ���������빲���ڴ��ӳ��
  rv = shmdt(shm);
  if (rv == -1) {
    return rv;
  }

  return 0;
}

int destory_shm(int shmid)
{
  if (shmctl(shmid,IPC_RMID,NULL) < 0) {
    perror("shmctl fail! \n");
    return -1;
  }

  return 0;
}

int shm_write(Shm shm_send,Shm_Queue_t *shared,sem_t *sem) //shm_index=0 sem=sem_2
{
  if (shared->count < Q_SIZE-1) {
    shared->shmBuf[(shared->index + shared->count + 1) % Q_SIZE] = shm_send;
    shared->count +=1;
  }

  sem_post(sem);
}

int shm_read(Shm *shm_recv,Shm_Queue_t *shared,sem_t *sem) //shm_index=1 sem=sem_1
{
  sem_wait(sem);
  if (shared->count > 0) {
    *shm_recv = shared->shmBuf[shared->index];
    shared->index = (shared->index + 1) % Q_SIZE;
    shared->count -=1;
  }

  return 0;
}

/* System '<Root>' */
extern void rt_OneStep(void);
real_T ConTs;
int udp_socket_fd = 0;
struct sockaddr_in dest_addr = { 0 };

struct sockaddr_in server = { 0 };

struct sockaddr_in client = { 0 };

//char snd_buf[1024] = {0};
char rev_buf[100] = { 0 };

struct itimerval tv, oldtv;
unsigned long cnt = 0;
int addrlen = 0;
int recvBytes = 0;
static void udp_setnonblocking(int sockfd)
{
  int flag = fcntl(sockfd, F_GETFL, 0);
  if (flag < 0) {
    printf("fcntl F_GETFL fail");
    return;
  }

  if (fcntl(sockfd, F_SETFL, flag | O_NONBLOCK) < 0) {
    printf("fcntl F_SETFL fail");
  }
}

int udp_init(void)
{
  addrlen= sizeof(struct sockaddr);
  udp_socket_fd = socket(AF_INET, SOCK_DGRAM, 0);
  if (udp_socket_fd == -1) {
    perror("socket failed!\n");
    return -1;
  }

  udp_setnonblocking(udp_socket_fd);
  dest_addr.sin_family = AF_INET;
  dest_addr.sin_port = htons(25250);
  dest_addr.sin_addr.s_addr = inet_addr("192.168.1.2");

  // add receive
  memset(&server,0,sizeof(server));
  server.sin_family= AF_INET;
  server.sin_addr.s_addr = htonl(INADDR_ANY);
  server.sin_port = htons(26000);
  if ((bind(udp_socket_fd, (struct sockaddr*)&server, sizeof(server))) == -1) {
    printf("bind error!\n");
    return -1;
  } else {
    printf("bind success!\n");
  }

  return 0;
}

void set_timer()
{
  tv.it_interval.tv_sec = 0;           //1s
  tv.it_interval.tv_usec = ConTs;      //100; //100us
  tv.it_value.tv_sec = 0;
  tv.it_value.tv_usec = ConTs;
  if (setitimer(ITIMER_REAL, &tv, &oldtv)) {
    fprintf(stderr, "Failed to start timer: %s\n", strerror(errno));
  }
}

void signal_handler(int signo)
{
  switch (signo)
  {
   case SIGALRM:
    rt_OneStep();                      ////////

    //sprintf(snd_buf,"x86test:%ld",cnt++);
    //snd_buf[0] = Datachange1;    snd_buf[1] = Datachange2;
    if (UDPensndFlag == 1) {
      sendto(udp_socket_fd, UDPsnddata, 40, 0, (struct sockaddr *)&dest_addr,
             sizeof(dest_addr));
      UDPensndFlag = 0;
    }

    //sleep(5);
    //memset(rev_buf,0,sizeof(rev_buf));
    if (UDPenrecvFlag == 1) {
      UDPenrecvFlag = 0;
      recvBytes = recvfrom(udp_socket_fd, rev_buf, sizeof(rev_buf) , 0, (struct
        sockaddr *)&client, (socklen_t*)&addrlen);
      if (recvBytes == 18) {
        //printf("received %d bytes, cmd=%s\n", recvBytes, rev_buf);
        memcpy(UDPrecvdata, rev_buf,18 );
        UDPrecvFlag = 1;
      }
    }

    /* if(strcmp(snd_buf, "quit") == 0)
       {
       break;
       }  */
    //memset(snd_buf,0,sizeof(snd_buf));
    //memset(rev_buf,0,sizeof(rev_buf));
    break;

   default:
    break;
  }
}

/* Exported block states */
uint32_T Ethercomd[49];                /* '<Root>/Data Store Memory20' */
uint32_T Etherfeed[42];                /* '<Root>/Data Store Memory21' */
uint16_T UDPsnddata[20];               /* '<Root>/Data Store Memory10' */
uint8_T Datachange1;                   /* '<Root>/Data Store Memory1' */
uint8_T Datachange2;                   /* '<Root>/Data Store Memory2' */
uint8_T UDPrecvdata[18];               /* '<Root>/Data Store Memory9' */
boolean_T UDPsndFlag;                  /* '<Root>/UDPд��־' */
boolean_T UDPensndFlag;                /* '<Root>/UDPʹ��д��־' */
boolean_T UDPenrecvFlag;               /* '<Root>/UDPʹ�ܶ�ȡ��־' */
boolean_T UDPrecvFlag;                 /* '<Root>/UDP��ȡ��־' */
boolean_T PTX;                         /* '<Root>/��Ϣʹ��' */

/* Block signals (default storage) */
B_x86linuxcompiletest5_T x86linuxcompiletest5_B;

/* Block states (default storage) */
DW_x86linuxcompiletest5_T x86linuxcompiletest5_DW;

/* Real-time model */
static RT_MODEL_x86linuxcompiletest5_T x86linuxcompiletest5_M_;
RT_MODEL_x86linuxcompiletest5_T *const x86linuxcompiletest5_M =
  &x86linuxcompiletest5_M_;
static void rate_scheduler(void);

/*
 *   This function updates active task flag for each subrate.
 * The function is called at model base rate, hence the
 * generated code self-manages all its subrates.
 */
static void rate_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (x86linuxcompiletest5_M->Timing.TaskCounters.TID[1])++;
  if ((x86linuxcompiletest5_M->Timing.TaskCounters.TID[1]) > 1) {/* Sample time: [0.002s, 0.0s] */
    x86linuxcompiletest5_M->Timing.TaskCounters.TID[1] = 0;
  }
}

/* System initialize for atomic system: '<Root>/SendDataToGUI1' */
void x86linuxcom_SendDataToGUI1_Init(void)
{
  /* InitializeConditions for Delay: '<S4>/Delay' */
  x86linuxcompiletest5_DW.Delay_DSTATE[0] =
    x86linuxcompiletest5_P.Delay_InitialCondition;
  x86linuxcompiletest5_DW.Delay_DSTATE[1] =
    x86linuxcompiletest5_P.Delay_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S43>/Output' */
  x86linuxcompiletest5_DW.Output_DSTATE_e =
    x86linuxcompiletest5_P.Output_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S44>/Output' */
  x86linuxcompiletest5_DW.Output_DSTATE_a =
    x86linuxcompiletest5_P.Output_InitialCondition_p;
}

/* Output and update for atomic system: '<Root>/SendDataToGUI1' */
void x86linuxcompilet_SendDataToGUI1(void)
{
  real_T tmp_0;
  int32_T Send_GUIdata_tmp;
  int32_T i;
  uint32_T tmp;
  int16_T rtb_DataTypeConversion1_c[9];
  uint16_T rtb_DataTypeConversion2_k[18];
  uint16_T rtb_DataTypeConversion2_n;
  uint8_T rtb_FixPtSum1;
  uint8_T rtb_FixPtSwitch;
  boolean_T tmp_1;

  /* Outputs for Enabled SubSystem: '<S4>/  ' incorporates:
   *  EnablePort: '<S40>/Enable'
   */
  /* Delay: '<S4>/Delay' */
  if (x86linuxcompiletest5_DW.Delay_DSTATE[0U]) {
    /* Sum: '<S40>/Sum of Elements2' */
    tmp = 0U;

    /* DataStoreWrite: '<S40>/Data Store Write4' incorporates:
     *  Constant: '<S40>/Constant2'
     */
    UDPsnddata[0] = x86linuxcompiletest5_P.Constant2_Value_o;
    for (i = 0; i < 18; i++) {
      /* DataTypeConversion: '<S40>/Data Type Conversion1' incorporates:
       *  DataStoreRead: '<S40>/Data Store Read1'
       */
      tmp_0 = floor(x86linuxcompiletest5_DW.Send_GUIdata[i]);
      if (rtIsNaN(tmp_0) || rtIsInf(tmp_0)) {
        tmp_0 = 0.0;
      } else {
        tmp_0 = fmod(tmp_0, 65536.0);
      }

      /* DataTypeConversion: '<S40>/Data Type Conversion2' incorporates:
       *  DataTypeConversion: '<S40>/Data Type Conversion1'
       */
      rtb_DataTypeConversion2_n = (uint16_T)(tmp_0 < 0.0 ? (int32_T)(int16_T)
        -(int16_T)(uint16_T)-tmp_0 : (int32_T)(int16_T)(uint16_T)tmp_0);

      /* Sum: '<S40>/Sum of Elements2' */
      tmp += rtb_DataTypeConversion2_n;

      /* DataStoreWrite: '<S40>/Data Store Write4' */
      UDPsnddata[i + 1] = rtb_DataTypeConversion2_n;
    }

    /* DataStoreWrite: '<S40>/Data Store Write4' incorporates:
     *  Constant: '<S40>/Constant2'
     *  Sum: '<S40>/Add'
     *  Sum: '<S40>/Sum of Elements2'
     */
    UDPsnddata[19] = (uint16_T)((uint32_T)
      x86linuxcompiletest5_P.Constant2_Value_o + (uint16_T)tmp);

    /* DataStoreWrite: '<S40>/Data Store Write3' incorporates:
     *  Constant: '<S40>/Constant'
     */
    UDPensndFlag = x86linuxcompiletest5_P.Constant_Value_g;
    for (i = 0; i < 6; i++) {
      /* DataStoreRead: '<S40>/Data Store Read7' incorporates:
       *  DataStoreRead: '<S40>/Data Store Read8'
       *  DataStoreRead: '<S40>/Data Store Read9'
       *  Gain: '<S40>/Gain2'
       */
      Send_GUIdata_tmp = (i << 1) + 1;

      /* DataStoreWrite: '<S40>/Data Store Write' incorporates:
       *  DataStoreRead: '<S40>/Data Store Read7'
       *  Gain: '<S40>/Gain2'
       */
      x86linuxcompiletest5_DW.Send_GUIdata[i] =
        x86linuxcompiletest5_DW.PosJoint[Send_GUIdata_tmp] *
        x86linuxcompiletest5_P.Gain2_Gain;

      /* DataStoreWrite: '<S40>/Data Store Write1' incorporates:
       *  DataStoreRead: '<S40>/Data Store Read8'
       *  Gain: '<S40>/Gain1'
       */
      x86linuxcompiletest5_DW.Send_GUIdata[i + 6] =
        x86linuxcompiletest5_DW.VelocJoint[Send_GUIdata_tmp] *
        x86linuxcompiletest5_P.Gain1_Gain_g;

      /* DataStoreWrite: '<S40>/Data Store Write2' incorporates:
       *  DataStoreRead: '<S40>/Data Store Read9'
       *  Gain: '<S40>/Gain3'
       */
      x86linuxcompiletest5_DW.Send_GUIdata[i + 12] =
        x86linuxcompiletest5_DW.TorqueJoint[Send_GUIdata_tmp] *
        x86linuxcompiletest5_P.Gain3_Gain;
    }
  }

  /* End of Delay: '<S4>/Delay' */
  /* End of Outputs for SubSystem: '<S4>/  ' */

  /* Sum: '<S59>/FixPt Sum1' incorporates:
   *  Constant: '<S59>/FixPt Constant'
   *  UnitDelay: '<S43>/Output'
   */
  rtb_FixPtSum1 = (uint8_T)((uint32_T)x86linuxcompiletest5_DW.Output_DSTATE_e +
    x86linuxcompiletest5_P.FixPtConstant_Value);

  /* Switch: '<S60>/FixPt Switch' incorporates:
   *  Constant: '<S60>/Constant'
   */
  if (rtb_FixPtSum1 > x86linuxcompiletest5_P._uplimit) {
    rtb_FixPtSwitch = x86linuxcompiletest5_P.Constant_Value_b;
  } else {
    rtb_FixPtSwitch = rtb_FixPtSum1;
  }

  /* End of Switch: '<S60>/FixPt Switch' */

  /* Switch: '<S4>/Switch1' incorporates:
   *  Constant: '<S4>/Constant2'
   *  Constant: '<S4>/Constant3'
   *  UnitDelay: '<S44>/Output'
   */
  if (x86linuxcompiletest5_DW.Output_DSTATE_a >
      x86linuxcompiletest5_P.Switch1_Threshold) {
    tmp_1 = x86linuxcompiletest5_P.Constant3_Value;
  } else {
    tmp_1 = x86linuxcompiletest5_P.Constant2_Value_c;
  }

  /* End of Switch: '<S4>/Switch1' */

  /* Outputs for Enabled SubSystem: '<S4>/Subsystem1' incorporates:
   *  EnablePort: '<S41>/Enable'
   */
  if (tmp_1) {
    /* DataStoreWrite: '<S41>/Data Store Write4' incorporates:
     *  Constant: '<S41>/Constant'
     */
    UDPenrecvFlag = x86linuxcompiletest5_P.Constant_Value_p;
  }

  /* End of Outputs for SubSystem: '<S4>/Subsystem1' */

  /* Sum: '<S61>/FixPt Sum1' incorporates:
   *  Constant: '<S61>/FixPt Constant'
   *  UnitDelay: '<S44>/Output'
   */
  rtb_FixPtSum1 = (uint8_T)((uint32_T)x86linuxcompiletest5_DW.Output_DSTATE_a +
    x86linuxcompiletest5_P.FixPtConstant_Value_j);

  /* Outputs for Enabled SubSystem: '<S4>/Subsystem2' incorporates:
   *  EnablePort: '<S42>/Enable'
   */
  /* DataStoreRead: '<S4>/Data Store Read1' */
  if (UDPrecvFlag) {
    /* DataStoreWrite: '<S42>/Data Store Write' incorporates:
     *  Constant: '<S42>/Constant'
     */
    UDPrecvFlag = x86linuxcompiletest5_P.Constant_Value_h;

    /* Outputs for Atomic SubSystem: '<S42>/Enabled Subsystem' */
    /* DataTypeConversion: '<S51>/Data Type Conversion2' incorporates:
     *  DataStoreRead: '<S42>/Data Store Read'
     */
    for (i = 0; i < 18; i++) {
      rtb_DataTypeConversion2_k[i] = UDPrecvdata[i];
    }

    /* End of DataTypeConversion: '<S51>/Data Type Conversion2' */

    /* SignalConversion generated from: '<S46>/����У��' incorporates:
     *  ArithShift: '<S51>/Shift Arithmetic'
     *  ArithShift: '<S51>/Shift Arithmetic1'
     *  ArithShift: '<S51>/Shift Arithmetic2'
     *  ArithShift: '<S51>/Shift Arithmetic3'
     *  ArithShift: '<S51>/Shift Arithmetic4'
     *  ArithShift: '<S51>/Shift Arithmetic5'
     *  ArithShift: '<S51>/Shift Arithmetic6'
     *  ArithShift: '<S51>/Shift Arithmetic7'
     *  ArithShift: '<S51>/Shift Arithmetic8'
     *  Sum: '<S51>/Add'
     *  Sum: '<S51>/Add1'
     *  Sum: '<S51>/Add2'
     *  Sum: '<S51>/Add3'
     *  Sum: '<S51>/Add4'
     *  Sum: '<S51>/Add5'
     *  Sum: '<S51>/Add6'
     *  Sum: '<S51>/Add7'
     *  Sum: '<S51>/Add8'
     */
    x86linuxcompiletest5_B.TmpSignalConversionAtInport1[0] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[1] << 8) +
       rtb_DataTypeConversion2_k[0]);
    x86linuxcompiletest5_B.TmpSignalConversionAtInport1[1] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[3] << 8) +
       rtb_DataTypeConversion2_k[2]);
    x86linuxcompiletest5_B.TmpSignalConversionAtInport1[2] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[5] << 8) +
       rtb_DataTypeConversion2_k[4]);
    x86linuxcompiletest5_B.TmpSignalConversionAtInport1[3] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[7] << 8) +
       rtb_DataTypeConversion2_k[6]);
    x86linuxcompiletest5_B.TmpSignalConversionAtInport1[4] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[9] << 8) +
       rtb_DataTypeConversion2_k[8]);
    x86linuxcompiletest5_B.TmpSignalConversionAtInport1[5] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[11] << 8) +
       rtb_DataTypeConversion2_k[10]);
    x86linuxcompiletest5_B.TmpSignalConversionAtInport1[6] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[13] << 8) +
       rtb_DataTypeConversion2_k[12]);
    x86linuxcompiletest5_B.TmpSignalConversionAtInport1[7] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[15] << 8) +
       rtb_DataTypeConversion2_k[14]);
    x86linuxcompiletest5_B.TmpSignalConversionAtInport1[8] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[17] << 8) +
       rtb_DataTypeConversion2_k[16]);

    /* S-Function (sfcn_CS): '<S46>/����У��' incorporates:
     *  Constant: '<S46>/��־λ'
     */
    sfcn_CS_Outputs_wrapper
      (&x86linuxcompiletest5_B.TmpSignalConversionAtInport1[0],
       &x86linuxcompiletest5_P.Value, &x86linuxcompiletest5_B._o1[0],
       &x86linuxcompiletest5_B._o2);

    /* DataStoreWrite: '<S46>/��Ϣ״̬' */
    PTX = x86linuxcompiletest5_B._o2;

    /* End of Outputs for SubSystem: '<S42>/Enabled Subsystem' */

    /* MATLAB Function: '<S42>/GUIcmdProces' */
    i = 0;
    if ((x86linuxcompiletest5_B._o1[0] == 128) && (x86linuxcompiletest5_B._o1[2]
         == 1) && (x86linuxcompiletest5_B._o1[3] == 0)) {
      i = 2;
    } else if ((x86linuxcompiletest5_B._o1[0] == 128) &&
               (x86linuxcompiletest5_B._o1[2] == 1) &&
               (x86linuxcompiletest5_B._o1[3] == 1)) {
      i = 1;
    } else if ((x86linuxcompiletest5_B._o1[0] == 1) &&
               (x86linuxcompiletest5_B._o1[1] == 0)) {
      i = 3;
    } else if ((x86linuxcompiletest5_B._o1[0] == 2) &&
               (x86linuxcompiletest5_B._o1[1] == 0)) {
      i = 4;
    } else if (x86linuxcompiletest5_B._o1[0] == 129) {
      i = 5;
    } else if (x86linuxcompiletest5_B._o1[0] == 130) {
      i = 6;
    } else if (x86linuxcompiletest5_B._o1[0] == 102) {
      i = 7;
    } else if (x86linuxcompiletest5_B._o1[0] == 103) {
      i = 8;
    } else if (x86linuxcompiletest5_B._o1[0] == 104) {
      i = 9;
    } else if (x86linuxcompiletest5_B._o1[0] == 105) {
      i = 10;
    } else {
      if (x86linuxcompiletest5_B._o1[0] == 136) {
        i = 11;
      }
    }

    /* End of MATLAB Function: '<S42>/GUIcmdProces' */

    /* DataStoreWrite: '<S42>/Data Store Write3' */
    x86linuxcompiletest5_DW.GUIcomd = i;

    /* SwitchCase: '<S42>/Switch Case' */
    switch (i) {
     case 3:
      /* Outputs for IfAction SubSystem: '<S42>/Zhengjie' incorporates:
       *  ActionPort: '<S50>/Action Port'
       */
      /* DataTypeConversion: '<S50>/Data Type Conversion1' */
      for (i = 0; i < 9; i++) {
        rtb_DataTypeConversion1_c[i] = (int16_T)x86linuxcompiletest5_B._o1[i];
      }

      /* End of DataTypeConversion: '<S50>/Data Type Conversion1' */

      /* DataStoreWrite: '<S50>/Data Store Write' incorporates:
       *  DataTypeConversion: '<S50>/Data Type Conversion2'
       *  Gain: '<S50>/Gain'
       *  Gain: '<S50>/Gain1'
       */
      x86linuxcompiletest5_DW.PosJoint[0] = x86linuxcompiletest5_P.Gain_Gain_d *
        (real_T)rtb_DataTypeConversion1_c[2];
      x86linuxcompiletest5_DW.PosJoint[2] = x86linuxcompiletest5_P.Gain_Gain_d *
        (real_T)rtb_DataTypeConversion1_c[3];
      x86linuxcompiletest5_DW.PosJoint[4] = (real_T)(int16_T)
        ((x86linuxcompiletest5_P.Gain1_Gain_k * rtb_DataTypeConversion1_c[4]) >>
         15) * x86linuxcompiletest5_P.Gain_Gain_d;
      x86linuxcompiletest5_DW.PosJoint[6] = x86linuxcompiletest5_P.Gain_Gain_d *
        (real_T)rtb_DataTypeConversion1_c[5];
      x86linuxcompiletest5_DW.PosJoint[8] = x86linuxcompiletest5_P.Gain_Gain_d *
        (real_T)rtb_DataTypeConversion1_c[6];
      x86linuxcompiletest5_DW.PosJoint[10] = x86linuxcompiletest5_P.Gain_Gain_d *
        (real_T)rtb_DataTypeConversion1_c[7];

      /* End of Outputs for SubSystem: '<S42>/Zhengjie' */
      break;

     case 4:
      /* Outputs for IfAction SubSystem: '<S42>/Nijie' incorporates:
       *  ActionPort: '<S49>/Action Port'
       */
      /* DataTypeConversion: '<S49>/Data Type Conversion2' incorporates:
       *  DataTypeConversion: '<S49>/Data Type Conversion1'
       */
      for (i = 0; i < 9; i++) {
        rtb_DataTypeConversion1_c[i] = (int16_T)x86linuxcompiletest5_B._o1[i];
      }

      /* End of DataTypeConversion: '<S49>/Data Type Conversion2' */

      /* DataStoreWrite: '<S49>/Data Store Write' incorporates:
       *  Gain: '<S49>/Gain1'
       *  Gain: '<S49>/Gain2'
       *  Gain: '<S49>/Gain3'
       *  Gain: '<S49>/Gain4'
       *  Gain: '<S49>/Gain5'
       *  Gain: '<S49>/Gain6'
       */
      x86linuxcompiletest5_DW.PosXYZ[0] = x86linuxcompiletest5_P.Gain1_Gain_b *
        (real_T)rtb_DataTypeConversion1_c[2];
      x86linuxcompiletest5_DW.PosXYZ[2] = x86linuxcompiletest5_P.Gain2_Gain_o *
        (real_T)rtb_DataTypeConversion1_c[3];
      x86linuxcompiletest5_DW.PosXYZ[4] = x86linuxcompiletest5_P.Gain3_Gain_i *
        (real_T)rtb_DataTypeConversion1_c[4];
      x86linuxcompiletest5_DW.PosXYZ[6] = x86linuxcompiletest5_P.Gain4_Gain *
        (real_T)rtb_DataTypeConversion1_c[5];
      x86linuxcompiletest5_DW.PosXYZ[8] = x86linuxcompiletest5_P.Gain5_Gain *
        (real_T)rtb_DataTypeConversion1_c[6];
      x86linuxcompiletest5_DW.PosXYZ[10] = x86linuxcompiletest5_P.Gain6_Gain_i *
        (real_T)rtb_DataTypeConversion1_c[7];

      /* End of Outputs for SubSystem: '<S42>/Nijie' */
      break;

     case 11:
      /* Outputs for IfAction SubSystem: '<S42>/Jdata' incorporates:
       *  ActionPort: '<S48>/Action Port'
       */
      /* SwitchCase: '<S48>/Switch Case' */
      switch (x86linuxcompiletest5_B._o1[1]) {
       case 1:
        /* Outputs for IfAction SubSystem: '<S48>/Joint1' incorporates:
         *  ActionPort: '<S52>/Action Port'
         */
        /* DataStoreWrite: '<S52>/Data Store Write2' incorporates:
         *  DataTypeConversion: '<S48>/Data Type Conversion'
         *  DataTypeConversion: '<S48>/Data Type Conversion3'
         */
        for (i = 0; i < 6; i++) {
          x86linuxcompiletest5_DW.Jdata[i] = (int16_T)
            x86linuxcompiletest5_B._o1[i + 2];
        }

        /* End of DataStoreWrite: '<S52>/Data Store Write2' */
        /* End of Outputs for SubSystem: '<S48>/Joint1' */
        break;

       case 2:
        /* Outputs for IfAction SubSystem: '<S48>/Joint2' incorporates:
         *  ActionPort: '<S53>/Action Port'
         */
        /* DataStoreWrite: '<S53>/Data Store Write2' incorporates:
         *  DataTypeConversion: '<S48>/Data Type Conversion'
         *  DataTypeConversion: '<S48>/Data Type Conversion3'
         */
        for (i = 0; i < 6; i++) {
          x86linuxcompiletest5_DW.Jdata[i + 6] = (int16_T)
            x86linuxcompiletest5_B._o1[i + 2];
        }

        /* End of DataStoreWrite: '<S53>/Data Store Write2' */
        /* End of Outputs for SubSystem: '<S48>/Joint2' */
        break;

       case 3:
        /* Outputs for IfAction SubSystem: '<S48>/Joint3' incorporates:
         *  ActionPort: '<S54>/Action Port'
         */
        /* DataStoreWrite: '<S54>/Data Store Write2' incorporates:
         *  DataTypeConversion: '<S48>/Data Type Conversion'
         *  DataTypeConversion: '<S48>/Data Type Conversion3'
         */
        for (i = 0; i < 6; i++) {
          x86linuxcompiletest5_DW.Jdata[i + 12] = (int16_T)
            x86linuxcompiletest5_B._o1[i + 2];
        }

        /* End of DataStoreWrite: '<S54>/Data Store Write2' */
        /* End of Outputs for SubSystem: '<S48>/Joint3' */
        break;

       case 4:
        /* Outputs for IfAction SubSystem: '<S48>/Joint4' incorporates:
         *  ActionPort: '<S55>/Action Port'
         */
        /* DataStoreWrite: '<S55>/Data Store Write2' incorporates:
         *  DataTypeConversion: '<S48>/Data Type Conversion'
         *  DataTypeConversion: '<S48>/Data Type Conversion3'
         */
        for (i = 0; i < 6; i++) {
          x86linuxcompiletest5_DW.Jdata[i + 18] = (int16_T)
            x86linuxcompiletest5_B._o1[i + 2];
        }

        /* End of DataStoreWrite: '<S55>/Data Store Write2' */
        /* End of Outputs for SubSystem: '<S48>/Joint4' */
        break;

       case 5:
        /* Outputs for IfAction SubSystem: '<S48>/Joint5' incorporates:
         *  ActionPort: '<S56>/Action Port'
         */
        /* DataStoreWrite: '<S56>/Data Store Write2' incorporates:
         *  DataTypeConversion: '<S48>/Data Type Conversion'
         *  DataTypeConversion: '<S48>/Data Type Conversion3'
         */
        for (i = 0; i < 6; i++) {
          x86linuxcompiletest5_DW.Jdata[i + 24] = (int16_T)
            x86linuxcompiletest5_B._o1[i + 2];
        }

        /* End of DataStoreWrite: '<S56>/Data Store Write2' */
        /* End of Outputs for SubSystem: '<S48>/Joint5' */
        break;

       case 6:
        /* Outputs for IfAction SubSystem: '<S48>/Joint6' incorporates:
         *  ActionPort: '<S57>/Action Port'
         */
        /* DataStoreWrite: '<S57>/Data Store Write2' incorporates:
         *  DataTypeConversion: '<S48>/Data Type Conversion'
         *  DataTypeConversion: '<S48>/Data Type Conversion3'
         */
        for (i = 0; i < 6; i++) {
          x86linuxcompiletest5_DW.Jdata[i + 30] = (int16_T)
            x86linuxcompiletest5_B._o1[i + 2];
        }

        /* End of DataStoreWrite: '<S57>/Data Store Write2' */
        /* End of Outputs for SubSystem: '<S48>/Joint6' */
        break;

       case 7:
        /* Outputs for IfAction SubSystem: '<S48>/Joint7' incorporates:
         *  ActionPort: '<S58>/Action Port'
         */
        /* DataStoreWrite: '<S58>/Data Store Write2' incorporates:
         *  DataTypeConversion: '<S48>/Data Type Conversion'
         *  DataTypeConversion: '<S48>/Data Type Conversion3'
         */
        for (i = 0; i < 6; i++) {
          x86linuxcompiletest5_DW.Jdata[i + 36] = (int16_T)
            x86linuxcompiletest5_B._o1[i + 2];
        }

        /* End of DataStoreWrite: '<S58>/Data Store Write2' */
        /* End of Outputs for SubSystem: '<S48>/Joint7' */
        break;
      }

      /* End of SwitchCase: '<S48>/Switch Case' */
      /* End of Outputs for SubSystem: '<S42>/Jdata' */
      break;
    }

    /* End of SwitchCase: '<S42>/Switch Case' */
  }

  /* End of DataStoreRead: '<S4>/Data Store Read1' */
  /* End of Outputs for SubSystem: '<S4>/Subsystem2' */

  /* Update for Delay: '<S4>/Delay' */
  x86linuxcompiletest5_DW.Delay_DSTATE[0] =
    x86linuxcompiletest5_DW.Delay_DSTATE[1];

  /* Switch: '<S4>/Switch' incorporates:
   *  UnitDelay: '<S43>/Output'
   */
  if (x86linuxcompiletest5_DW.Output_DSTATE_e >
      x86linuxcompiletest5_P.Switch_Threshold) {
    /* Update for Delay: '<S4>/Delay' incorporates:
     *  Constant: '<S4>/Constant1'
     */
    x86linuxcompiletest5_DW.Delay_DSTATE[1] =
      x86linuxcompiletest5_P.Constant1_Value_m;
  } else {
    /* Update for Delay: '<S4>/Delay' incorporates:
     *  Constant: '<S4>/Constant'
     */
    x86linuxcompiletest5_DW.Delay_DSTATE[1] =
      x86linuxcompiletest5_P.Constant_Value_f;
  }

  /* End of Switch: '<S4>/Switch' */

  /* Update for UnitDelay: '<S43>/Output' */
  x86linuxcompiletest5_DW.Output_DSTATE_e = rtb_FixPtSwitch;

  /* Switch: '<S62>/FixPt Switch' */
  if (rtb_FixPtSum1 > x86linuxcompiletest5_P.u_uplimit) {
    /* Update for UnitDelay: '<S44>/Output' incorporates:
     *  Constant: '<S62>/Constant'
     */
    x86linuxcompiletest5_DW.Output_DSTATE_a =
      x86linuxcompiletest5_P.Constant_Value_m;
  } else {
    /* Update for UnitDelay: '<S44>/Output' */
    x86linuxcompiletest5_DW.Output_DSTATE_a = rtb_FixPtSum1;
  }

  /* End of Switch: '<S62>/FixPt Switch' */
}

/* Model step function */
void x86linuxcompiletest5_step(void)
{
  int32_T PosJoint_tmp;
  int32_T i;
  uint8_T rtb_FixPtSum1;

  /* user code (Output function Body) */

  /* System '<Root>' */
  shm_read(&shm_recv,shared[0],sem_2);
  static uint32 msgppcount = 0;
  for (msgppcount = 0 ;msgppcount <6 ;msgppcount++) {
    Etherfeed[msgppcount*6 + 0] = shm_recv.JointInfo[msgppcount].
      pdo_val.status_word;
    Etherfeed[msgppcount*6 + 1] = shm_recv.JointInfo[msgppcount ].
      pdo_val.actual_pos;
    Etherfeed[msgppcount*6 + 2] = shm_recv.JointInfo[msgppcount ].
      pdo_val.actual_vel;
    Etherfeed[msgppcount*6 + 3] = shm_recv.JointInfo[msgppcount ].
      pdo_val.actual_torq;
    Etherfeed[msgppcount*6 + 4] = shm_recv.JointInfo[msgppcount ].
      pdo_val.pos_error;
    Etherfeed[msgppcount*6 + 5] = shm_recv.JointInfo[msgppcount ]. error;
  }

  /* System '<Root>' */
  shm_send.type = 1;
  static uint32 sendppcount = 0;
  for (sendppcount = 0 ;sendppcount <6 ;sendppcount++) {
    shm_send.JointInfo[sendppcount].pdo_val.ctrl_word = Ethercomd[sendppcount*7
      +0];
    shm_send.JointInfo[sendppcount].pdo_val.target_pos = Ethercomd[sendppcount*7
      +1];
    shm_send.JointInfo[sendppcount].pdo_val.target_vel = Ethercomd[sendppcount*7
      +2];
    shm_send.JointInfo[sendppcount].pdo_val.offset_vel = Ethercomd[sendppcount*7
      +3];
    shm_send.JointInfo[sendppcount].pdo_val.target_torq = Ethercomd[sendppcount*
      7 +4];
    shm_send.JointInfo[sendppcount].pdo_val.offset_torq = Ethercomd[sendppcount*
      7 +5];
    shm_send.JointInfo[sendppcount].model_type = Ethercomd[sendppcount*7 +6];
  }

  shm_write(shm_send,shared[1],sem_1);
  for (i = 0; i < 6; i++) {
    /* DataStoreWrite: '<S3>/Data Store Write6' incorporates:
     *  DataStoreRead: '<S3>/Data Store Read'
     *  DataStoreWrite: '<S3>/Data Store Write7'
     *  DataStoreWrite: '<S3>/Data Store Write8'
     *  DataTypeConversion: '<S3>/Data Type Conversion3'
     *  Gain: '<S3>/Gain'
     */
    PosJoint_tmp = (i << 1) + 1;
    x86linuxcompiletest5_DW.PosJoint[PosJoint_tmp] = (real_T)(int32_T)Etherfeed
      [6 * i + 1] * ((real_T)x86linuxcompiletest5_P.Gain_Gain_j *
                     1.8189894035458565E-12);

    /* DataStoreWrite: '<S3>/Data Store Write7' incorporates:
     *  DataStoreRead: '<S3>/Data Store Read2'
     *  DataTypeConversion: '<S3>/Data Type Conversion4'
     *  Gain: '<S3>/Gain1'
     */
    x86linuxcompiletest5_DW.VelocJoint[PosJoint_tmp] = (real_T)(int32_T)
      Etherfeed[6 * i + 2] * ((real_T)x86linuxcompiletest5_P.Gain1_Gain_o *
      1.8189894035458565E-12);

    /* DataStoreWrite: '<S3>/Data Store Write8' incorporates:
     *  DataStoreRead: '<S3>/Data Store Read3'
     *  DataTypeConversion: '<S3>/Data Type Conversion5'
     *  Gain: '<S3>/Gain2'
     */
    x86linuxcompiletest5_DW.TorqueJoint[PosJoint_tmp] = (real_T)(int16_T)
      Etherfeed[6 * i + 3] * ((real_T)x86linuxcompiletest5_P.Gain2_Gain_on *
      6.103515625E-5);
  }

  /* DataStoreWrite: '<S3>/Data Store Write9' incorporates:
   *  DataStoreRead: '<S3>/Data Store Read4'
   *  DataTypeConversion: '<S3>/Data Type Conversion7'
   *  Gain: '<S3>/Gain3'
   */
  x86linuxcompiletest5_DW.PosJoint[5] = (real_T)
    x86linuxcompiletest5_P.Gain3_Gain_d * 1.8189894035458565E-12 * (real_T)
    (int32_T)Etherfeed[13];

  /* DataStoreWrite: '<S3>/Data Store Write10' incorporates:
   *  DataStoreRead: '<S3>/Data Store Read5'
   *  DataTypeConversion: '<S3>/Data Type Conversion8'
   *  Gain: '<S3>/Gain4'
   */
  x86linuxcompiletest5_DW.VelocJoint[5] = (real_T)
    x86linuxcompiletest5_P.Gain4_Gain_c * 1.8189894035458565E-12 * (real_T)
    (int32_T)Etherfeed[14];

  /* DataStoreWrite: '<S3>/Data Store Write11' incorporates:
   *  DataStoreRead: '<S3>/Data Store Read6'
   *  DataTypeConversion: '<S3>/Data Type Conversion9'
   *  Gain: '<S3>/Gain5'
   */
  x86linuxcompiletest5_DW.TorqueJoint[5] = (real_T)
    x86linuxcompiletest5_P.Gain5_Gain_n * 3.0517578125E-5 * (real_T)(int16_T)
    Etherfeed[15];

  /* Outputs for Atomic SubSystem: '<Root>/DynamicCalculation2' */
  DynamicsController();

  /* End of Outputs for SubSystem: '<Root>/DynamicCalculation2' */

  /* Outputs for Atomic SubSystem: '<Root>/SendDataToGUI1' */
  x86linuxcompilet_SendDataToGUI1();

  /* End of Outputs for SubSystem: '<Root>/SendDataToGUI1' */

  /* Outputs for Atomic SubSystem: '<Root>/Subsystem' */
  /* DataStoreWrite: '<S5>/Data Store Write1' incorporates:
   *  UnitDelay: '<S63>/Output'
   */
  Datachange1 = x86linuxcompiletest5_DW.Output_DSTATE_m;

  /* Sum: '<S64>/FixPt Sum1' incorporates:
   *  Constant: '<S64>/FixPt Constant'
   *  UnitDelay: '<S63>/Output'
   */
  rtb_FixPtSum1 = (uint8_T)((uint32_T)x86linuxcompiletest5_DW.Output_DSTATE_m +
    x86linuxcompiletest5_P.FixPtConstant_Value_l);

  /* Switch: '<S65>/FixPt Switch' */
  if (rtb_FixPtSum1 > x86linuxcompiletest5_P.CounterLimited_uplimit) {
    /* Update for UnitDelay: '<S63>/Output' incorporates:
     *  Constant: '<S65>/Constant'
     */
    x86linuxcompiletest5_DW.Output_DSTATE_m =
      x86linuxcompiletest5_P.Constant_Value_g0;
  } else {
    /* Update for UnitDelay: '<S63>/Output' */
    x86linuxcompiletest5_DW.Output_DSTATE_m = rtb_FixPtSum1;
  }

  /* End of Switch: '<S65>/FixPt Switch' */
  /* End of Outputs for SubSystem: '<Root>/Subsystem' */
  if (x86linuxcompiletest5_M->Timing.TaskCounters.TID[1] == 0) {
    /* Outputs for Atomic SubSystem: '<Root>/Subsystem1' */
    /* DataStoreWrite: '<S6>/Data Store Write1' incorporates:
     *  UnitDelay: '<S66>/Output'
     */
    Datachange2 = x86linuxcompiletest5_DW.Output_DSTATE;

    /* Sum: '<S67>/FixPt Sum1' incorporates:
     *  Constant: '<S67>/FixPt Constant'
     *  UnitDelay: '<S66>/Output'
     */
    rtb_FixPtSum1 = (uint8_T)((uint32_T)x86linuxcompiletest5_DW.Output_DSTATE +
      x86linuxcompiletest5_P.FixPtConstant_Value_i);

    /* Switch: '<S68>/FixPt Switch' */
    if (rtb_FixPtSum1 > x86linuxcompiletest5_P.CounterLimited_uplimit_m) {
      /* Update for UnitDelay: '<S66>/Output' incorporates:
       *  Constant: '<S68>/Constant'
       */
      x86linuxcompiletest5_DW.Output_DSTATE =
        x86linuxcompiletest5_P.Constant_Value_gs;
    } else {
      /* Update for UnitDelay: '<S66>/Output' */
      x86linuxcompiletest5_DW.Output_DSTATE = rtb_FixPtSum1;
    }

    /* End of Switch: '<S68>/FixPt Switch' */
    /* End of Outputs for SubSystem: '<Root>/Subsystem1' */
  }

  /* Matfile logging */
  rt_UpdateTXYLogVars(x86linuxcompiletest5_M->rtwLogInfo,
                      (&x86linuxcompiletest5_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.001s, 0.0s] */
    if ((rtmGetTFinal(x86linuxcompiletest5_M)!=-1) &&
        !((rtmGetTFinal(x86linuxcompiletest5_M)-
           x86linuxcompiletest5_M->Timing.taskTime0) >
          x86linuxcompiletest5_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(x86linuxcompiletest5_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++x86linuxcompiletest5_M->Timing.clockTick0)) {
    ++x86linuxcompiletest5_M->Timing.clockTickH0;
  }

  x86linuxcompiletest5_M->Timing.taskTime0 =
    x86linuxcompiletest5_M->Timing.clockTick0 *
    x86linuxcompiletest5_M->Timing.stepSize0 +
    x86linuxcompiletest5_M->Timing.clockTickH0 *
    x86linuxcompiletest5_M->Timing.stepSize0 * 4294967296.0;
  rate_scheduler();
}

/* Model initialize function */
void x86linuxcompiletest5_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)x86linuxcompiletest5_M, 0,
                sizeof(RT_MODEL_x86linuxcompiletest5_T));
  rtmSetTFinal(x86linuxcompiletest5_M, -1);
  x86linuxcompiletest5_M->Timing.stepSize0 = 0.001;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    x86linuxcompiletest5_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(x86linuxcompiletest5_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(x86linuxcompiletest5_M->rtwLogInfo, (NULL));
    rtliSetLogT(x86linuxcompiletest5_M->rtwLogInfo, "tout");
    rtliSetLogX(x86linuxcompiletest5_M->rtwLogInfo, "");
    rtliSetLogXFinal(x86linuxcompiletest5_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(x86linuxcompiletest5_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(x86linuxcompiletest5_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(x86linuxcompiletest5_M->rtwLogInfo, 0);
    rtliSetLogDecimation(x86linuxcompiletest5_M->rtwLogInfo, 1);
    rtliSetLogY(x86linuxcompiletest5_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(x86linuxcompiletest5_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(x86linuxcompiletest5_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &x86linuxcompiletest5_B), 0,
                sizeof(B_x86linuxcompiletest5_T));

  /* states (dwork) */
  (void) memset((void *)&x86linuxcompiletest5_DW, 0,
                sizeof(DW_x86linuxcompiletest5_T));

  /* exported global states */
  (void) memset(&Ethercomd, 0,
                49U*sizeof(uint32_T));
  (void) memset(&Etherfeed, 0,
                42U*sizeof(uint32_T));
  (void) memset(&UDPsnddata, 0,
                20U*sizeof(uint16_T));
  Datachange1 = 0U;
  Datachange2 = 0U;
  (void) memset(&UDPrecvdata, 0,
                18U*sizeof(uint8_T));
  UDPsndFlag = false;
  UDPensndFlag = false;
  UDPenrecvFlag = false;
  UDPrecvFlag = false;
  PTX = false;

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(x86linuxcompiletest5_M->rtwLogInfo, 0.0,
    rtmGetTFinal(x86linuxcompiletest5_M),
    x86linuxcompiletest5_M->Timing.stepSize0, (&rtmGetErrorStatus
    (x86linuxcompiletest5_M)));

  {
    int32_T i;

    /* Start for DataStoreMemory: '<Root>/Data Store Memory' */
    ConTs = x86linuxcompiletest5_P.Ts * 1000.0 * 1000.0;

    /* Start for DataStoreMemory: '<Root>/UDPд��־' */
    UDPsndFlag = x86linuxcompiletest5_P.UDPInitialValue;

    /* Start for DataStoreMemory: '<Root>/Data Store Memory1' */
    Datachange1 = x86linuxcompiletest5_P.DataStoreMemory1_InitialValue;

    /* Start for DataStoreMemory: '<Root>/Data Store Memory10' */
    for (i = 0; i < 20; i++) {
      UDPsnddata[i] = x86linuxcompiletest5_P.DataStoreMemory10_InitialValue[i];
    }

    /* End of Start for DataStoreMemory: '<Root>/Data Store Memory10' */

    /* Start for DataStoreMemory: '<Root>/Data Store Memory19' */
    x86linuxcompiletest5_DW.GUIcomd =
      x86linuxcompiletest5_P.DataStoreMemory19_InitialValue;

    /* Start for DataStoreMemory: '<Root>/Data Store Memory2' */
    Datachange2 = x86linuxcompiletest5_P.DataStoreMemory2_InitialValue;

    /* Start for DataStoreMemory: '<Root>/Data Store Memory20' */
    memcpy(&Ethercomd[0],
           &x86linuxcompiletest5_P.DataStoreMemory20_InitialValue[0], 49U *
           sizeof(uint32_T));

    /* Start for DataStoreMemory: '<Root>/Data Store Memory21' */
    memcpy(&Etherfeed[0],
           &x86linuxcompiletest5_P.DataStoreMemory21_InitialValue[0], 42U *
           sizeof(uint32_T));

    /* Start for DataStoreMemory: '<Root>/Data Store Memory3' */
    memcpy(&x86linuxcompiletest5_DW.Send_GUIdata[0],
           &x86linuxcompiletest5_P.DataStoreMemory3_InitialValue[0], 18U *
           sizeof(real_T));

    /* Start for DataStoreMemory: '<Root>/Data Store Memory4' */
    memcpy(&x86linuxcompiletest5_DW.PosJoint[0],
           &x86linuxcompiletest5_P.DataStoreMemory4_InitialValue[0], 14U *
           sizeof(real_T));

    /* Start for DataStoreMemory: '<Root>/Data Store Memory5' */
    memcpy(&x86linuxcompiletest5_DW.VelocJoint[0],
           &x86linuxcompiletest5_P.DataStoreMemory5_InitialValue[0], 14U *
           sizeof(real_T));

    /* Start for DataStoreMemory: '<Root>/Data Store Memory6' */
    memcpy(&x86linuxcompiletest5_DW.TorqueJoint[0],
           &x86linuxcompiletest5_P.DataStoreMemory6_InitialValue[0], 14U *
           sizeof(real_T));

    /* Start for DataStoreMemory: '<Root>/Data Store Memory7' */
    memcpy(&x86linuxcompiletest5_DW.PosXYZ[0],
           &x86linuxcompiletest5_P.DataStoreMemory7_InitialValue[0], 14U *
           sizeof(real_T));

    /* Start for DataStoreMemory: '<Root>/Data Store Memory8' */
    memcpy(&x86linuxcompiletest5_DW.Jdata[0],
           &x86linuxcompiletest5_P.DataStoreMemory8_InitialValue[0], 42U *
           sizeof(real_T));

    /* Start for DataStoreMemory: '<Root>/Data Store Memory9' */
    for (i = 0; i < 18; i++) {
      UDPrecvdata[i] = x86linuxcompiletest5_P.DataStoreMemory9_InitialValue[i];
    }

    /* End of Start for DataStoreMemory: '<Root>/Data Store Memory9' */

    /* Start for DataStoreMemory: '<Root>/UDPʹ��д��־' */
    UDPensndFlag = x86linuxcompiletest5_P.UDPInitialValue_j;

    /* Start for DataStoreMemory: '<Root>/UDPʹ�ܶ�ȡ��־' */
    UDPenrecvFlag = x86linuxcompiletest5_P.UDP_InitialValue;

    /* Start for DataStoreMemory: '<Root>/UDP��ȡ��־' */
    UDPrecvFlag = x86linuxcompiletest5_P.UDP_InitialValue_e;

    /* Start for DataStoreMemory: '<Root>/��Ϣʹ��' */
    PTX = x86linuxcompiletest5_P._InitialValue;
  }

  {
    {
      /* user code (Initialize function Header) */

      /* System '<Root>' */
      udp_init();
      signal(SIGALRM,signal_handler);

      /* user code (Initialize function Body) */

      /* System '<Root>' */
      shmaddr[0] = init_shm(&shmid[0],SHM_PATH_A,sizeof(Shm_Queue_t));
      shmaddr[1] = init_shm(&shmid[1],SHM_PATH_B,sizeof(Shm_Queue_t));
      shared[0]= (Shm_Queue_t *)shmaddr[0];
      shared[1]= (Shm_Queue_t *)shmaddr[1];
      sem_1= sem_open("sem_1",O_CREAT,0666,0);
      sem_2= sem_open("sem_2",O_CREAT,0666,0);

      /* SystemInitialize for Atomic SubSystem: '<Root>/DynamicCalculation2' */
      DynamicsController_Init();

      /* End of SystemInitialize for SubSystem: '<Root>/DynamicCalculation2' */

      /* SystemInitialize for Atomic SubSystem: '<Root>/SendDataToGUI1' */
      x86linuxcom_SendDataToGUI1_Init();

      /* End of SystemInitialize for SubSystem: '<Root>/SendDataToGUI1' */

      /* SystemInitialize for Atomic SubSystem: '<Root>/Subsystem' */
      /* InitializeConditions for UnitDelay: '<S63>/Output' */
      x86linuxcompiletest5_DW.Output_DSTATE_m =
        x86linuxcompiletest5_P.Output_InitialCondition_j;

      /* End of SystemInitialize for SubSystem: '<Root>/Subsystem' */

      /* SystemInitialize for Atomic SubSystem: '<Root>/Subsystem1' */
      /* InitializeConditions for UnitDelay: '<S66>/Output' */
      x86linuxcompiletest5_DW.Output_DSTATE =
        x86linuxcompiletest5_P.Output_InitialCondition_l;

      /* End of SystemInitialize for SubSystem: '<Root>/Subsystem1' */
      /* user code (Initialize function Trailer) */

      /* System '<Root>' */
      set_timer();
    }
  }
}

/* Model terminate function */
void x86linuxcompiletest5_terminate(void)
{
  {
    /* user code (Terminate function Header) */

    /* System '<Root>' */
    close(udp_socket_fd);

    /* user code (Terminate function Body) */

    /* System '<Root>' */
    if (shmaddr[0] != NULL) {
      if (shmdt(shmaddr[0]) < 0) {
        perror("shmdt ralay fail\n");
      }
    }

    if (shmaddr[1] != NULL) {
      if (shmdt(shmaddr[1]) < 0) {
        perror("shmdt ralay fail\n");
      }
    }

    if (sem_1 != NULL) {
      sem_close(sem_1);
      sem_unlink("sem_1");
    }

    if (sem_2 != NULL) {
      sem_close(sem_2);
      sem_unlink("sem_2");
    }
  }
}
