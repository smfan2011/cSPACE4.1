/*
 * Code generation for system system '<Root>/DynamicCalculation2'
 * For more details, see corresponding source file DynamicsController.c
 *
 */

#ifndef RTW_HEADER_DynamicsController_h_
#define RTW_HEADER_DynamicsController_h_
#include <math.h>
#ifndef x86linuxcompiletest5_COMMON_INCLUDES_
#define x86linuxcompiletest5_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                               /* x86linuxcompiletest5_COMMON_INCLUDES_ */

#include "x86linuxcompiletest5_types.h"

/* Shared type includes */
#include "multiword_types.h"

/* Child system includes */
#include "InverseSolverMDH.h"
#include "rt_nonfinite.h"

/* Block signals for system '<S8>/GotoPlay' */
typedef struct {
  real_T Merge;                        /* '<S10>/Merge' */
  real_T OutportBufferForOut1;         /* '<S23>/Constant1' */
} B_GotoPlay_x86linuxcompiletes_T;

/* Block states (default storage) for system '<S8>/GotoPlay' */
typedef struct {
  uint32_T data_temp;                  /* '<S21>/MATLAB Function' */
  uint8_T enTRAJpoints;                /* '<S10>/Data Store Memory2' */
  uint8_T Reset;                       /* '<S10>/Data Store Memory3' */
} DW_GotoPlay_x86linuxcompilete_T;

/* Parameters for system: '<S11>/PPmode' */
struct P_PPmode_x86linuxcompiletest5_T_ {
  uint32_T PP_Value[7];                /* Computed Parameter: PP_Value
                                        * Referenced by: '<S28>/PP'
                                        */
};

/* Parameters for system: '<S8>/ModeSet' */
struct P_ModeSet_x86linuxcompiletest_T_ {
  P_PPmode_x86linuxcompiletest5_T CSTmode;/* '<S11>/CSTmode' */
  P_PPmode_x86linuxcompiletest5_T CSVmode;/* '<S11>/CSVmode' */
  P_PPmode_x86linuxcompiletest5_T CSPmode;/* '<S11>/CSPmode' */
  P_PPmode_x86linuxcompiletest5_T PTmode;/* '<S11>/PTmode' */
  P_PPmode_x86linuxcompiletest5_T PVmode;/* '<S11>/PVmode' */
  P_PPmode_x86linuxcompiletest5_T PPmode;/* '<S11>/PPmode' */
};

/* Parameters for system: '<S8>/StartProces' */
struct P_StartProces_x86linuxcompile_T_ {
  uint32_T Constant_Value[7];          /* Computed Parameter: Constant_Value
                                        * Referenced by: '<S14>/Constant'
                                        */
};

/* Parameters for system: '<S8>/Cmdclear' */
struct P_Cmdclear_x86linuxcompiletes_T_ {
  uint32_T Constant_Value[7];          /* Computed Parameter: Constant_Value
                                        * Referenced by: '<S9>/Constant'
                                        */
};

/* Parameters for system: '<S12>/Enabled Subsystem13' */
struct P_EnabledSubsystem13_x86linux_T_ {
  uint32_T Constant2_Value[7];         /* Computed Parameter: Constant2_Value
                                        * Referenced by: '<S33>/Constant2'
                                        */
};

/* Parameters for system: '<S8>/StopProces' */
struct P_StopProces_x86linuxcompilet_T_ {
  uint32_T Constant6_Value[7];         /* Computed Parameter: Constant6_Value
                                        * Referenced by: '<S15>/Constant6'
                                        */
};

/* Parameters for system: '<S8>/GotoPlay' */
struct P_GotoPlay_x86linuxcompiletes_T_ {
  boolean_T CompareToConstant_const;  /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S18>/Constant'
                                       */
  uint8_T CompareToConstant_const_c;/* Mask Parameter: CompareToConstant_const_c
                                     * Referenced by: '<S22>/Constant'
                                     */
  real_T Constant2_Value;              /* Expression: 1
                                        * Referenced by: '<S16>/Constant2'
                                        */
  real_T Constant1_Value;              /* Expression: 2
                                        * Referenced by: '<S23>/Constant1'
                                        */
  real_T Gain6_Gain;                   /* Expression: 131072/360/10
                                        * Referenced by: '<S21>/Gain6'
                                        */
  real_T Merge_InitialOutput;         /* Computed Parameter: Merge_InitialOutput
                                       * Referenced by: '<S10>/Merge'
                                       */
  real32_T _Value[6];                  /* Computed Parameter: _Value
                                        * Referenced by: '<S19>/�켣����'
                                        */
  real32_T Gain6_Gain_m;               /* Computed Parameter: Gain6_Gain_m
                                        * Referenced by: '<S19>/Gain6'
                                        */
  uint32_T Constant_Value[7];          /* Computed Parameter: Constant_Value
                                        * Referenced by: '<S19>/Constant'
                                        */
  uint32_T Constant_Value_h[7];        /* Computed Parameter: Constant_Value_h
                                        * Referenced by: '<S21>/Constant'
                                        */
  boolean_T Constant1_Value_j;         /* Computed Parameter: Constant1_Value_j
                                        * Referenced by: '<S19>/Constant1'
                                        */
  uint8_T Constant_Value_m;            /* Computed Parameter: Constant_Value_m
                                        * Referenced by: '<S16>/Constant'
                                        */
  uint8_T Constant1_Value_jl;          /* Computed Parameter: Constant1_Value_jl
                                        * Referenced by: '<S16>/Constant1'
                                        */
  uint8_T Constant_Value_p;            /* Computed Parameter: Constant_Value_p
                                        * Referenced by: '<S23>/Constant'
                                        */
  uint8_T Constant1_Value_h;           /* Computed Parameter: Constant1_Value_h
                                        * Referenced by: '<S21>/Constant1'
                                        */
  uint8_T DataStoreMemory2_InitialValue;
                            /* Computed Parameter: DataStoreMemory2_InitialValue
                             * Referenced by: '<S10>/Data Store Memory2'
                             */
  uint8_T DataStoreMemory3_InitialValue;
                            /* Computed Parameter: DataStoreMemory3_InitialValue
                             * Referenced by: '<S10>/Data Store Memory3'
                             */
  P_EnabledSubsystem13_x86linux_T EnabledSubsystem13;/* '<S16>/Enabled Subsystem13' */
};

extern void x86linuxcompiletest5_PPmode(P_PPmode_x86linuxcompiletest5_T *localP);
extern void x86linuxcompiletest5_ModeSet(real_T rtu_in,
  P_ModeSet_x86linuxcompiletest_T *localP);
extern void x86linuxcompiletest_StartProces(P_StartProces_x86linuxcompile_T
  *localP);
extern void x86linuxcompiletest5_Cmdclear(P_Cmdclear_x86linuxcompiletes_T
  *localP);
extern void x86linuxcomp_EnabledSubsystem13(boolean_T rtu_Enable,
  P_EnabledSubsystem13_x86linux_T *localP);
extern void x86linuxcompiletest5_StopProces(P_StopProces_x86linuxcompilet_T
  *localP);
extern void x86linuxcompilete_GotoPlay_Init(B_GotoPlay_x86linuxcompiletes_T
  *localB, DW_GotoPlay_x86linuxcompilete_T *localDW,
  P_GotoPlay_x86linuxcompiletes_T *localP);
extern void x86linuxcompiletest5_GotoPlay(real_T rtu_in,
  B_GotoPlay_x86linuxcompiletes_T *localB, DW_GotoPlay_x86linuxcompilete_T
  *localDW, P_GotoPlay_x86linuxcompiletes_T *localP);
extern void DynamicsController_Init(void);
extern void DynamicsController(void);

#endif                                 /* RTW_HEADER_DynamicsController_h_ */
