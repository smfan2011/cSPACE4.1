/*
 * x86linuxcompiletest5_types.h
 *
 * Code generation for model "x86linuxcompiletest5".
 *
 * Model version              : 1.45
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Wed Apr 28 13:25:02 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_x86linuxcompiletest5_types_h_
#define RTW_HEADER_x86linuxcompiletest5_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"

/* Model Code Variants */

/* Parameters for system: '<S11>/PPmode' */
typedef struct P_PPmode_x86linuxcompiletest5_T_ P_PPmode_x86linuxcompiletest5_T;

/* Parameters for system: '<S8>/ModeSet' */
typedef struct P_ModeSet_x86linuxcompiletest_T_ P_ModeSet_x86linuxcompiletest_T;

/* Parameters for system: '<S8>/StartProces' */
typedef struct P_StartProces_x86linuxcompile_T_ P_StartProces_x86linuxcompile_T;

/* Parameters for system: '<S8>/Cmdclear' */
typedef struct P_Cmdclear_x86linuxcompiletes_T_ P_Cmdclear_x86linuxcompiletes_T;

/* Parameters for system: '<S12>/Enabled Subsystem13' */
typedef struct P_EnabledSubsystem13_x86linux_T_ P_EnabledSubsystem13_x86linux_T;

/* Parameters for system: '<S8>/StopProces' */
typedef struct P_StopProces_x86linuxcompilet_T_ P_StopProces_x86linuxcompilet_T;

/* Parameters for system: '<S8>/GotoPlay' */
typedef struct P_GotoPlay_x86linuxcompiletes_T_ P_GotoPlay_x86linuxcompiletes_T;

/* Parameters (default storage) */
typedef struct P_x86linuxcompiletest5_T_ P_x86linuxcompiletest5_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_x86linuxcompiletest5_T RT_MODEL_x86linuxcompiletest5_T;

#endif                            /* RTW_HEADER_x86linuxcompiletest5_types_h_ */
