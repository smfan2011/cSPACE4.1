
/*
 * Include Files
 *
 */
#if defined(MATLAB_MEX_FILE)
#include "tmwtypes.h"
#include "simstruc_types.h"
#else
#include "rtwtypes.h"
#endif



/* %%%-SFUNWIZ_wrapper_includes_Changes_BEGIN --- EDIT HERE TO _END */



#include <math.h>
#include "string.h"
/* %%%-SFUNWIZ_wrapper_includes_Changes_END --- EDIT HERE TO _BEGIN */
#define u_width 9
#define y_width 1

/*
 * Create external references here.  
 *
 */
/* %%%-SFUNWIZ_wrapper_externs_Changes_BEGIN --- EDIT HERE TO _END */



/* extern double func(double a); */
/* %%%-SFUNWIZ_wrapper_externs_Changes_END --- EDIT HERE TO _BEGIN */

/*
 * Output function
 *
 */
void sfcn_CS_Outputs_wrapper(const uint16_T *RXD,
			const uint16_T *INs,
			uint16_T *TXD,
			boolean_T *OTs)
{
/* %%%-SFUNWIZ_wrapper_Outputs_Changes_BEGIN --- EDIT HERE TO _END */



unsigned int CS=0;
unsigned char i = 0;

for(i=0; i<8; i++)
{
    CS+=RXD[i];
}

if((unsigned short)CS == RXD[8])
{
//    memcpy(TXD, RXD, 9);
    TXD[0] = RXD[0];    TXD[1] = RXD[1];    TXD[2] = RXD[2];
    TXD[3] = RXD[3];    TXD[4] = RXD[4];    TXD[5] = RXD[5];
    TXD[6] = RXD[6];    TXD[7] = RXD[7];    TXD[8] = RXD[8];
    if(INs[0])
    {
        OTs[0] = false;
    }
    else
    {
        OTs[0] = true;
    }
}
else
{
    memset(TXD, 0, 9);
    OTs[0] = false;
}
/* %%%-SFUNWIZ_wrapper_Outputs_Changes_END --- EDIT HERE TO _BEGIN */
}


