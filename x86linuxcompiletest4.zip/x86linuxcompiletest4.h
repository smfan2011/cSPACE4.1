/*
 * x86linuxcompiletest4.h
 *
 * Code generation for model "x86linuxcompiletest4".
 *
 * Model version              : 1.32
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Wed Apr 21 19:19:18 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_x86linuxcompiletest4_h_
#define RTW_HEADER_x86linuxcompiletest4_h_
#include <math.h>
#include <string.h>
#include <float.h>
#include <stddef.h>
#ifndef x86linuxcompiletest4_COMMON_INCLUDES_
#define x86linuxcompiletest4_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                               /* x86linuxcompiletest4_COMMON_INCLUDES_ */

#include "x86linuxcompiletest4_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetRTWLogInfo
#define rtmGetRTWLogInfo(rtm)          ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   ((rtm)->Timing.taskTime0)
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                (&(rtm)->Timing.taskTime0)
#endif

/* user code (top of header file) */
/* System '<Root>' */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/time.h>
#include <signal.h>
#include <fcntl.h>

/* Block signals (default storage) */
typedef struct {
  uint16_T TmpSignalConversionAtInport1[9];/* '<S10>/Subsystem' */
  uint16_T _o1[9];                     /* '<S10>/����У��' */
  boolean_T _o2;                       /* '<S10>/����У��' */
} B_x86linuxcompiletest4_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T GUIcomd;                      /* '<Root>/Data Store Memory19' */
  real_T Send_GUIdata[18];             /* '<Root>/Data Store Memory3' */
  real_T PosJoint[14];                 /* '<Root>/Data Store Memory4' */
  real_T VelocJoint[14];               /* '<Root>/Data Store Memory5' */
  real_T TorqueJoint[14];              /* '<Root>/Data Store Memory6' */
  real_T PosXYZ[14];                   /* '<Root>/Data Store Memory7' */
  real_T Jdata[42];                    /* '<Root>/Data Store Memory8' */
  uint32_T Ethercomd[49];              /* '<Root>/Data Store Memory20' */
  uint32_T Etherfeed[42];              /* '<Root>/Data Store Memory21' */
  uint8_T Output_DSTATE;               /* '<S30>/Output' */
  uint8_T Output_DSTATE_m;             /* '<S27>/Output' */
  uint8_T Output_DSTATE_e;             /* '<S7>/Output' */
  uint8_T Output_DSTATE_a;             /* '<S8>/Output' */
  boolean_T Delay_DSTATE[2];           /* '<S1>/Delay' */
} DW_x86linuxcompiletest4_T;

/* Parameters (default storage) */
struct P_x86linuxcompiletest4_T_ {
  real_T Ts;                           /* Variable: Ts
                                        * Referenced by: '<Root>/Data Store Memory'
                                        */
  uint8_T _uplimit;                    /* Mask Parameter: _uplimit
                                        * Referenced by: '<S24>/FixPt Switch'
                                        */
  uint8_T u_uplimit;                   /* Mask Parameter: u_uplimit
                                        * Referenced by: '<S26>/FixPt Switch'
                                        */
  uint8_T CounterLimited_uplimit;      /* Mask Parameter: CounterLimited_uplimit
                                        * Referenced by: '<S29>/FixPt Switch'
                                        */
  uint8_T CounterLimited_uplimit_m;  /* Mask Parameter: CounterLimited_uplimit_m
                                      * Referenced by: '<S32>/FixPt Switch'
                                      */
  real_T Gain1_Gain;                   /* Expression: 10
                                        * Referenced by: '<S4>/Gain1'
                                        */
  real_T Gain3_Gain;                   /* Expression: 10
                                        * Referenced by: '<S4>/Gain3'
                                        */
  real_T Gain_Gain;                    /* Expression: 0.1
                                        * Referenced by: '<S14>/Gain'
                                        */
  real_T Gain1_Gain_b;                 /* Expression: 0.1
                                        * Referenced by: '<S13>/Gain1'
                                        */
  real_T Gain2_Gain;                   /* Expression: 0.1
                                        * Referenced by: '<S13>/Gain2'
                                        */
  real_T Gain3_Gain_i;                 /* Expression: 0.1
                                        * Referenced by: '<S13>/Gain3'
                                        */
  real_T Gain4_Gain;                   /* Expression: 0.1
                                        * Referenced by: '<S13>/Gain4'
                                        */
  real_T Gain5_Gain;                   /* Expression: 0.1
                                        * Referenced by: '<S13>/Gain5'
                                        */
  real_T Gain6_Gain;                   /* Expression: 0.1
                                        * Referenced by: '<S13>/Gain6'
                                        */
  real_T DataStoreMemory19_InitialValue;/* Expression: 0
                                         * Referenced by: '<Root>/Data Store Memory19'
                                         */
  real_T DataStoreMemory3_InitialValue[18];/* Expression: zeros(1,18)
                                            * Referenced by: '<Root>/Data Store Memory3'
                                            */
  real_T DataStoreMemory4_InitialValue[14];/* Expression: zeros(2,7)
                                            * Referenced by: '<Root>/Data Store Memory4'
                                            */
  real_T DataStoreMemory5_InitialValue[14];/* Expression: zeros(2,7)
                                            * Referenced by: '<Root>/Data Store Memory5'
                                            */
  real_T DataStoreMemory6_InitialValue[14];/* Expression: zeros(2,7)
                                            * Referenced by: '<Root>/Data Store Memory6'
                                            */
  real_T DataStoreMemory7_InitialValue[14];/* Expression: zeros(2,7)
                                            * Referenced by: '<Root>/Data Store Memory7'
                                            */
  real_T DataStoreMemory8_InitialValue[42];/* Expression: zeros(6,7)
                                            * Referenced by: '<Root>/Data Store Memory8'
                                            */
  uint32_T DataStoreMemory20_InitialValue[49];
                           /* Computed Parameter: DataStoreMemory20_InitialValue
                            * Referenced by: '<Root>/Data Store Memory20'
                            */
  uint32_T DataStoreMemory21_InitialValue[42];
                           /* Computed Parameter: DataStoreMemory21_InitialValue
                            * Referenced by: '<Root>/Data Store Memory21'
                            */
  int16_T Gain1_Gain_k;                /* Computed Parameter: Gain1_Gain_k
                                        * Referenced by: '<S14>/Gain1'
                                        */
  uint16_T Constant2_Value;            /* Computed Parameter: Constant2_Value
                                        * Referenced by: '<S4>/Constant2'
                                        */
  uint16_T Value;                      /* Computed Parameter: Value
                                        * Referenced by: '<S10>/��־λ'
                                        */
  uint16_T DataStoreMemory10_InitialValue[20];
                           /* Computed Parameter: DataStoreMemory10_InitialValue
                            * Referenced by: '<Root>/Data Store Memory10'
                            */
  boolean_T Constant_Value;            /* Computed Parameter: Constant_Value
                                        * Referenced by: '<S4>/Constant'
                                        */
  boolean_T Constant_Value_p;          /* Computed Parameter: Constant_Value_p
                                        * Referenced by: '<S5>/Constant'
                                        */
  boolean_T Constant_Value_h;          /* Computed Parameter: Constant_Value_h
                                        * Referenced by: '<S6>/Constant'
                                        */
  boolean_T Constant3_Value;           /* Expression: false
                                        * Referenced by: '<S1>/Constant3'
                                        */
  boolean_T Constant2_Value_c;         /* Expression: true
                                        * Referenced by: '<S1>/Constant2'
                                        */
  boolean_T Constant1_Value;           /* Expression: false
                                        * Referenced by: '<S1>/Constant1'
                                        */
  boolean_T Constant_Value_f;          /* Expression: true
                                        * Referenced by: '<S1>/Constant'
                                        */
  boolean_T Delay_InitialCondition;/* Computed Parameter: Delay_InitialCondition
                                    * Referenced by: '<S1>/Delay'
                                    */
  boolean_T UDPInitialValue;           /* Computed Parameter: UDPInitialValue
                                        * Referenced by: '<Root>/UDPд��־'
                                        */
  boolean_T UDPInitialValue_j;         /* Computed Parameter: UDPInitialValue_j
                                        * Referenced by: '<Root>/UDPʹ��д��־'
                                        */
  boolean_T UDP_InitialValue;          /* Computed Parameter: UDP_InitialValue
                                        * Referenced by: '<Root>/UDPʹ�ܶ�ȡ��־'
                                        */
  boolean_T UDP_InitialValue_e;        /* Computed Parameter: UDP_InitialValue_e
                                        * Referenced by: '<Root>/UDP��ȡ��־'
                                        */
  boolean_T _InitialValue;             /* Computed Parameter: _InitialValue
                                        * Referenced by: '<Root>/��Ϣʹ��'
                                        */
  uint8_T Constant_Value_b;            /* Computed Parameter: Constant_Value_b
                                        * Referenced by: '<S24>/Constant'
                                        */
  uint8_T Constant_Value_m;            /* Computed Parameter: Constant_Value_m
                                        * Referenced by: '<S26>/Constant'
                                        */
  uint8_T Output_InitialCondition;/* Computed Parameter: Output_InitialCondition
                                   * Referenced by: '<S7>/Output'
                                   */
  uint8_T Switch_Threshold;            /* Computed Parameter: Switch_Threshold
                                        * Referenced by: '<S1>/Switch'
                                        */
  uint8_T FixPtConstant_Value;        /* Computed Parameter: FixPtConstant_Value
                                       * Referenced by: '<S23>/FixPt Constant'
                                       */
  uint8_T Output_InitialCondition_p;
                                /* Computed Parameter: Output_InitialCondition_p
                                 * Referenced by: '<S8>/Output'
                                 */
  uint8_T Switch1_Threshold;           /* Computed Parameter: Switch1_Threshold
                                        * Referenced by: '<S1>/Switch1'
                                        */
  uint8_T FixPtConstant_Value_j;    /* Computed Parameter: FixPtConstant_Value_j
                                     * Referenced by: '<S25>/FixPt Constant'
                                     */
  uint8_T Constant_Value_g;            /* Computed Parameter: Constant_Value_g
                                        * Referenced by: '<S29>/Constant'
                                        */
  uint8_T Output_InitialCondition_j;
                                /* Computed Parameter: Output_InitialCondition_j
                                 * Referenced by: '<S27>/Output'
                                 */
  uint8_T FixPtConstant_Value_l;    /* Computed Parameter: FixPtConstant_Value_l
                                     * Referenced by: '<S28>/FixPt Constant'
                                     */
  uint8_T Constant_Value_gs;           /* Computed Parameter: Constant_Value_gs
                                        * Referenced by: '<S32>/Constant'
                                        */
  uint8_T Output_InitialCondition_l;
                                /* Computed Parameter: Output_InitialCondition_l
                                 * Referenced by: '<S30>/Output'
                                 */
  uint8_T FixPtConstant_Value_i;    /* Computed Parameter: FixPtConstant_Value_i
                                     * Referenced by: '<S31>/FixPt Constant'
                                     */
  uint8_T DataStoreMemory1_InitialValue;
                            /* Computed Parameter: DataStoreMemory1_InitialValue
                             * Referenced by: '<Root>/Data Store Memory1'
                             */
  uint8_T DataStoreMemory2_InitialValue;
                            /* Computed Parameter: DataStoreMemory2_InitialValue
                             * Referenced by: '<Root>/Data Store Memory2'
                             */
  uint8_T DataStoreMemory9_InitialValue[18];
                            /* Computed Parameter: DataStoreMemory9_InitialValue
                             * Referenced by: '<Root>/Data Store Memory9'
                             */
};

/* Real-time Model Data Structure */
struct tag_RTM_x86linuxcompiletest4_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T taskTime0;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    struct {
      uint8_T TID[2];
    } TaskCounters;

    time_T tFinal;
    boolean_T stopRequestedFlag;
  } Timing;
};

/* Block parameters (default storage) */
extern P_x86linuxcompiletest4_T x86linuxcompiletest4_P;

/* Block signals (default storage) */
extern B_x86linuxcompiletest4_T x86linuxcompiletest4_B;

/* Block states (default storage) */
extern DW_x86linuxcompiletest4_T x86linuxcompiletest4_DW;

/*
 * Exported States
 *
 * Note: Exported states are block states with an exported global
 * storage class designation.  Code generation will declare the memory for these
 * states and exports their symbols.
 *
 */
extern uint16_T UDPsnddata[20];        /* '<Root>/Data Store Memory10' */
extern uint8_T Datachange1;            /* '<Root>/Data Store Memory1' */
extern uint8_T Datachange2;            /* '<Root>/Data Store Memory2' */
extern uint8_T UDPrecvdata[18];        /* '<Root>/Data Store Memory9' */
extern boolean_T UDPsndFlag;           /* '<Root>/UDPд��־' */
extern boolean_T UDPensndFlag;         /* '<Root>/UDPʹ��д��־' */
extern boolean_T UDPenrecvFlag;        /* '<Root>/UDPʹ�ܶ�ȡ��־' */
extern boolean_T UDPrecvFlag;          /* '<Root>/UDP��ȡ��־' */
extern boolean_T PTX;                  /* '<Root>/��Ϣʹ��' */

/* Model entry point functions */
extern void x86linuxcompiletest4_initialize(void);
extern void x86linuxcompiletest4_step(void);
extern void x86linuxcompiletest4_terminate(void);

/* Real-time Model object */
extern RT_MODEL_x86linuxcompiletest4_T *const x86linuxcompiletest4_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'x86linuxcompiletest4'
 * '<S1>'   : 'x86linuxcompiletest4/SendDataToGUI1'
 * '<S2>'   : 'x86linuxcompiletest4/Subsystem'
 * '<S3>'   : 'x86linuxcompiletest4/Subsystem1'
 * '<S4>'   : 'x86linuxcompiletest4/SendDataToGUI1/  '
 * '<S5>'   : 'x86linuxcompiletest4/SendDataToGUI1/Subsystem1'
 * '<S6>'   : 'x86linuxcompiletest4/SendDataToGUI1/Subsystem2'
 * '<S7>'   : 'x86linuxcompiletest4/SendDataToGUI1/�㲥����'
 * '<S8>'   : 'x86linuxcompiletest4/SendDataToGUI1/�㲥����1'
 * '<S9>'   : 'x86linuxcompiletest4/SendDataToGUI1/Subsystem2/Compare To Constant'
 * '<S10>'  : 'x86linuxcompiletest4/SendDataToGUI1/Subsystem2/Enabled Subsystem'
 * '<S11>'  : 'x86linuxcompiletest4/SendDataToGUI1/Subsystem2/GUIcmdProces'
 * '<S12>'  : 'x86linuxcompiletest4/SendDataToGUI1/Subsystem2/Jdata'
 * '<S13>'  : 'x86linuxcompiletest4/SendDataToGUI1/Subsystem2/Nijie'
 * '<S14>'  : 'x86linuxcompiletest4/SendDataToGUI1/Subsystem2/Zhengjie'
 * '<S15>'  : 'x86linuxcompiletest4/SendDataToGUI1/Subsystem2/Enabled Subsystem/Subsystem'
 * '<S16>'  : 'x86linuxcompiletest4/SendDataToGUI1/Subsystem2/Jdata/Joint1'
 * '<S17>'  : 'x86linuxcompiletest4/SendDataToGUI1/Subsystem2/Jdata/Joint2'
 * '<S18>'  : 'x86linuxcompiletest4/SendDataToGUI1/Subsystem2/Jdata/Joint3'
 * '<S19>'  : 'x86linuxcompiletest4/SendDataToGUI1/Subsystem2/Jdata/Joint4'
 * '<S20>'  : 'x86linuxcompiletest4/SendDataToGUI1/Subsystem2/Jdata/Joint5'
 * '<S21>'  : 'x86linuxcompiletest4/SendDataToGUI1/Subsystem2/Jdata/Joint6'
 * '<S22>'  : 'x86linuxcompiletest4/SendDataToGUI1/Subsystem2/Jdata/Joint7'
 * '<S23>'  : 'x86linuxcompiletest4/SendDataToGUI1/�㲥����/Increment Real World'
 * '<S24>'  : 'x86linuxcompiletest4/SendDataToGUI1/�㲥����/Wrap To Zero'
 * '<S25>'  : 'x86linuxcompiletest4/SendDataToGUI1/�㲥����1/Increment Real World'
 * '<S26>'  : 'x86linuxcompiletest4/SendDataToGUI1/�㲥����1/Wrap To Zero'
 * '<S27>'  : 'x86linuxcompiletest4/Subsystem/Counter Limited'
 * '<S28>'  : 'x86linuxcompiletest4/Subsystem/Counter Limited/Increment Real World'
 * '<S29>'  : 'x86linuxcompiletest4/Subsystem/Counter Limited/Wrap To Zero'
 * '<S30>'  : 'x86linuxcompiletest4/Subsystem1/Counter Limited'
 * '<S31>'  : 'x86linuxcompiletest4/Subsystem1/Counter Limited/Increment Real World'
 * '<S32>'  : 'x86linuxcompiletest4/Subsystem1/Counter Limited/Wrap To Zero'
 */
#endif                                 /* RTW_HEADER_x86linuxcompiletest4_h_ */
