/*
 * x86linuxcompiletest4.c
 *
 * Code generation for model "x86linuxcompiletest4".
 *
 * Model version              : 1.32
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Wed Apr 21 19:19:18 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "x86linuxcompiletest4.h"
#include "x86linuxcompiletest4_private.h"

/* user code (top of source file) */
/* System '<Root>' */
extern void rt_OneStep(void);
real_T ConTs;
int udp_socket_fd = 0;
struct sockaddr_in dest_addr = { 0 };

struct sockaddr_in server = { 0 };

struct sockaddr_in client = { 0 };

char snd_buf[1024] = { 0 };

char rev_buf[1024] = { 0 };

struct itimerval tv, oldtv;
unsigned long cnt = 0;
int addrlen = 0;
int recvBytes = 0;
static void udp_setnonblocking(int sockfd)
{
  int flag = fcntl(sockfd, F_GETFL, 0);
  if (flag < 0) {
    printf("fcntl F_GETFL fail");
    return;
  }

  if (fcntl(sockfd, F_SETFL, flag | O_NONBLOCK) < 0) {
    printf("fcntl F_SETFL fail");
  }
}

int udp_init(void)
{
  addrlen= sizeof(struct sockaddr);
  udp_socket_fd = socket(AF_INET, SOCK_DGRAM, 0);
  if (udp_socket_fd == -1) {
    perror("socket failed!\n");
    return -1;
  }

  udp_setnonblocking(udp_socket_fd);
  dest_addr.sin_family = AF_INET;
  dest_addr.sin_port = htons(60000);
  dest_addr.sin_addr.s_addr = inet_addr("192.168.1.2");

  // add receive
  memset(&server,0,sizeof(server));
  server.sin_family= AF_INET;
  server.sin_addr.s_addr = htonl(INADDR_ANY);
  server.sin_port = htons(60000);
  if ((bind(udp_socket_fd, (struct sockaddr*)&server, sizeof(server))) == -1) {
    printf("bind error!\n");
    return -1;
  } else {
    printf("bind success!\n");
  }

  return 0;
}

void set_timer()
{
  tv.it_interval.tv_sec = 0;           //1s
  tv.it_interval.tv_usec = ConTs;      //100; //100us
  tv.it_value.tv_sec = 0;
  tv.it_value.tv_usec = ConTs;
  if (setitimer(ITIMER_REAL, &tv, &oldtv)) {
    fprintf(stderr, "Failed to start timer: %s\n", strerror(errno));
  }
}

void signal_handler(int signo)
{
  switch (signo)
  {
   case SIGALRM:
    rt_OneStep();                      ////////

    //sprintf(snd_buf,"x86test:%ld",cnt++);
    snd_buf[0] = Datachange1;
    snd_buf[1] = Datachange2;
    if (UDPensndFlag == 1) {
      sendto(udp_socket_fd, UDPsnddata, 20, 0, (struct sockaddr *)&dest_addr,
             sizeof(dest_addr));
      UDPensndFlag = 0;
    }

    //sleep(5);
    //memset(rev_buf,0,sizeof(rev_buf));
    if (UDPenrecvFlag == 1) {
      UDPenrecvFlag = 0;
      recvBytes = recvfrom(udp_socket_fd, rev_buf, sizeof(rev_buf) , 0, (struct
        sockaddr *)&client, (socklen_t*)&addrlen);
      if (recvBytes == 18) {
        //printf("received %d bytes, cmd=%s\n", recvBytes, rev_buf);
        memcpy(UDPrecvdata, rev_buf,18 );
        UDPrecvFlag = 1;
      }
    }

    if (strcmp(snd_buf, "quit") == 0) {
      break;
    }

    //memset(snd_buf,0,sizeof(snd_buf));
    //memset(rev_buf,0,sizeof(rev_buf));
    break;

   default:
    break;
  }
}

/* Exported block states */
uint16_T UDPsnddata[20];               /* '<Root>/Data Store Memory10' */
uint8_T Datachange1;                   /* '<Root>/Data Store Memory1' */
uint8_T Datachange2;                   /* '<Root>/Data Store Memory2' */
uint8_T UDPrecvdata[18];               /* '<Root>/Data Store Memory9' */
boolean_T UDPsndFlag;                  /* '<Root>/UDPд��־' */
boolean_T UDPensndFlag;                /* '<Root>/UDPʹ��д��־' */
boolean_T UDPenrecvFlag;               /* '<Root>/UDPʹ�ܶ�ȡ��־' */
boolean_T UDPrecvFlag;                 /* '<Root>/UDP��ȡ��־' */
boolean_T PTX;                         /* '<Root>/��Ϣʹ��' */

/* Block signals (default storage) */
B_x86linuxcompiletest4_T x86linuxcompiletest4_B;

/* Block states (default storage) */
DW_x86linuxcompiletest4_T x86linuxcompiletest4_DW;

/* Real-time model */
static RT_MODEL_x86linuxcompiletest4_T x86linuxcompiletest4_M_;
RT_MODEL_x86linuxcompiletest4_T *const x86linuxcompiletest4_M =
  &x86linuxcompiletest4_M_;
static void rate_scheduler(void);

/*
 *   This function updates active task flag for each subrate.
 * The function is called at model base rate, hence the
 * generated code self-manages all its subrates.
 */
static void rate_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (x86linuxcompiletest4_M->Timing.TaskCounters.TID[1])++;
  if ((x86linuxcompiletest4_M->Timing.TaskCounters.TID[1]) > 1) {/* Sample time: [0.002s, 0.0s] */
    x86linuxcompiletest4_M->Timing.TaskCounters.TID[1] = 0;
  }
}

/* System initialize for atomic system: '<Root>/SendDataToGUI1' */
void x86linuxcom_SendDataToGUI1_Init(void)
{
  /* InitializeConditions for Delay: '<S1>/Delay' */
  x86linuxcompiletest4_DW.Delay_DSTATE[0] =
    x86linuxcompiletest4_P.Delay_InitialCondition;
  x86linuxcompiletest4_DW.Delay_DSTATE[1] =
    x86linuxcompiletest4_P.Delay_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S7>/Output' */
  x86linuxcompiletest4_DW.Output_DSTATE_e =
    x86linuxcompiletest4_P.Output_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S8>/Output' */
  x86linuxcompiletest4_DW.Output_DSTATE_a =
    x86linuxcompiletest4_P.Output_InitialCondition_p;
}

/* Output and update for atomic system: '<Root>/SendDataToGUI1' */
void x86linuxcompilet_SendDataToGUI1(void)
{
  real_T tmp_0;
  int32_T Send_GUIdata_tmp;
  int32_T i;
  uint32_T tmp;
  int16_T rtb_DataTypeConversion1_c[9];
  uint16_T rtb_DataTypeConversion2_k[18];
  uint16_T rtb_DataTypeConversion2_n;
  uint8_T rtb_FixPtSum1;
  uint8_T rtb_FixPtSwitch;
  boolean_T tmp_1;

  /* Outputs for Enabled SubSystem: '<S1>/  ' incorporates:
   *  EnablePort: '<S4>/Enable'
   */
  /* Delay: '<S1>/Delay' */
  if (x86linuxcompiletest4_DW.Delay_DSTATE[0U]) {
    /* Sum: '<S4>/Sum of Elements2' */
    tmp = 0U;

    /* DataStoreWrite: '<S4>/Data Store Write4' incorporates:
     *  Constant: '<S4>/Constant2'
     */
    UDPsnddata[0] = x86linuxcompiletest4_P.Constant2_Value;
    for (i = 0; i < 18; i++) {
      /* DataTypeConversion: '<S4>/Data Type Conversion1' incorporates:
       *  DataStoreRead: '<S4>/Data Store Read1'
       */
      tmp_0 = floor(x86linuxcompiletest4_DW.Send_GUIdata[i]);
      if (rtIsNaN(tmp_0) || rtIsInf(tmp_0)) {
        tmp_0 = 0.0;
      } else {
        tmp_0 = fmod(tmp_0, 65536.0);
      }

      /* DataTypeConversion: '<S4>/Data Type Conversion2' incorporates:
       *  DataTypeConversion: '<S4>/Data Type Conversion1'
       */
      rtb_DataTypeConversion2_n = (uint16_T)(tmp_0 < 0.0 ? (int32_T)(int16_T)
        -(int16_T)(uint16_T)-tmp_0 : (int32_T)(int16_T)(uint16_T)tmp_0);

      /* Sum: '<S4>/Sum of Elements2' */
      tmp += rtb_DataTypeConversion2_n;

      /* DataStoreWrite: '<S4>/Data Store Write4' */
      UDPsnddata[i + 1] = rtb_DataTypeConversion2_n;
    }

    /* DataStoreWrite: '<S4>/Data Store Write4' incorporates:
     *  Constant: '<S4>/Constant2'
     *  Sum: '<S4>/Add'
     *  Sum: '<S4>/Sum of Elements2'
     */
    UDPsnddata[19] = (uint16_T)((uint32_T)x86linuxcompiletest4_P.Constant2_Value
      + (uint16_T)tmp);

    /* DataStoreWrite: '<S4>/Data Store Write3' incorporates:
     *  Constant: '<S4>/Constant'
     */
    UDPensndFlag = x86linuxcompiletest4_P.Constant_Value;

    /* DataStoreWrite: '<S4>/Data Store Write5' incorporates:
     *  DataStoreRead: '<S4>/Data Store Read2'
     */
    x86linuxcompiletest4_DW.Send_GUIdata[0] = x86linuxcompiletest4_DW.GUIcomd;
    for (i = 0; i < 6; i++) {
      /* DataStoreRead: '<S4>/Data Store Read8' incorporates:
       *  DataStoreRead: '<S4>/Data Store Read9'
       *  Gain: '<S4>/Gain1'
       */
      Send_GUIdata_tmp = (i << 1) + 1;

      /* DataStoreWrite: '<S4>/Data Store Write1' incorporates:
       *  DataStoreRead: '<S4>/Data Store Read8'
       *  Gain: '<S4>/Gain1'
       */
      x86linuxcompiletest4_DW.Send_GUIdata[i + 6] =
        x86linuxcompiletest4_DW.VelocJoint[Send_GUIdata_tmp] *
        x86linuxcompiletest4_P.Gain1_Gain;

      /* DataStoreWrite: '<S4>/Data Store Write2' incorporates:
       *  DataStoreRead: '<S4>/Data Store Read9'
       *  Gain: '<S4>/Gain3'
       */
      x86linuxcompiletest4_DW.Send_GUIdata[i + 12] =
        x86linuxcompiletest4_DW.TorqueJoint[Send_GUIdata_tmp] *
        x86linuxcompiletest4_P.Gain3_Gain;
    }
  }

  /* End of Delay: '<S1>/Delay' */
  /* End of Outputs for SubSystem: '<S1>/  ' */

  /* Sum: '<S23>/FixPt Sum1' incorporates:
   *  Constant: '<S23>/FixPt Constant'
   *  UnitDelay: '<S7>/Output'
   */
  rtb_FixPtSum1 = (uint8_T)((uint32_T)x86linuxcompiletest4_DW.Output_DSTATE_e +
    x86linuxcompiletest4_P.FixPtConstant_Value);

  /* Switch: '<S24>/FixPt Switch' incorporates:
   *  Constant: '<S24>/Constant'
   */
  if (rtb_FixPtSum1 > x86linuxcompiletest4_P._uplimit) {
    rtb_FixPtSwitch = x86linuxcompiletest4_P.Constant_Value_b;
  } else {
    rtb_FixPtSwitch = rtb_FixPtSum1;
  }

  /* End of Switch: '<S24>/FixPt Switch' */

  /* Switch: '<S1>/Switch1' incorporates:
   *  Constant: '<S1>/Constant2'
   *  Constant: '<S1>/Constant3'
   *  UnitDelay: '<S8>/Output'
   */
  if (x86linuxcompiletest4_DW.Output_DSTATE_a >
      x86linuxcompiletest4_P.Switch1_Threshold) {
    tmp_1 = x86linuxcompiletest4_P.Constant3_Value;
  } else {
    tmp_1 = x86linuxcompiletest4_P.Constant2_Value_c;
  }

  /* End of Switch: '<S1>/Switch1' */

  /* Outputs for Enabled SubSystem: '<S1>/Subsystem1' incorporates:
   *  EnablePort: '<S5>/Enable'
   */
  if (tmp_1) {
    /* DataStoreWrite: '<S5>/Data Store Write4' incorporates:
     *  Constant: '<S5>/Constant'
     */
    UDPenrecvFlag = x86linuxcompiletest4_P.Constant_Value_p;
  }

  /* End of Outputs for SubSystem: '<S1>/Subsystem1' */

  /* Sum: '<S25>/FixPt Sum1' incorporates:
   *  Constant: '<S25>/FixPt Constant'
   *  UnitDelay: '<S8>/Output'
   */
  rtb_FixPtSum1 = (uint8_T)((uint32_T)x86linuxcompiletest4_DW.Output_DSTATE_a +
    x86linuxcompiletest4_P.FixPtConstant_Value_j);

  /* Outputs for Enabled SubSystem: '<S1>/Subsystem2' incorporates:
   *  EnablePort: '<S6>/Enable'
   */
  /* DataStoreRead: '<S1>/Data Store Read1' */
  if (UDPrecvFlag) {
    /* DataStoreWrite: '<S6>/Data Store Write' incorporates:
     *  Constant: '<S6>/Constant'
     */
    UDPrecvFlag = x86linuxcompiletest4_P.Constant_Value_h;

    /* Outputs for Atomic SubSystem: '<S6>/Enabled Subsystem' */
    /* DataTypeConversion: '<S15>/Data Type Conversion2' incorporates:
     *  DataStoreRead: '<S6>/Data Store Read'
     */
    for (i = 0; i < 18; i++) {
      rtb_DataTypeConversion2_k[i] = UDPrecvdata[i];
    }

    /* End of DataTypeConversion: '<S15>/Data Type Conversion2' */

    /* SignalConversion generated from: '<S10>/����У��' incorporates:
     *  ArithShift: '<S15>/Shift Arithmetic'
     *  ArithShift: '<S15>/Shift Arithmetic1'
     *  ArithShift: '<S15>/Shift Arithmetic2'
     *  ArithShift: '<S15>/Shift Arithmetic3'
     *  ArithShift: '<S15>/Shift Arithmetic4'
     *  ArithShift: '<S15>/Shift Arithmetic5'
     *  ArithShift: '<S15>/Shift Arithmetic6'
     *  ArithShift: '<S15>/Shift Arithmetic7'
     *  ArithShift: '<S15>/Shift Arithmetic8'
     *  Sum: '<S15>/Add'
     *  Sum: '<S15>/Add1'
     *  Sum: '<S15>/Add2'
     *  Sum: '<S15>/Add3'
     *  Sum: '<S15>/Add4'
     *  Sum: '<S15>/Add5'
     *  Sum: '<S15>/Add6'
     *  Sum: '<S15>/Add7'
     *  Sum: '<S15>/Add8'
     */
    x86linuxcompiletest4_B.TmpSignalConversionAtInport1[0] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[1] << 8) +
       rtb_DataTypeConversion2_k[0]);
    x86linuxcompiletest4_B.TmpSignalConversionAtInport1[1] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[3] << 8) +
       rtb_DataTypeConversion2_k[2]);
    x86linuxcompiletest4_B.TmpSignalConversionAtInport1[2] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[5] << 8) +
       rtb_DataTypeConversion2_k[4]);
    x86linuxcompiletest4_B.TmpSignalConversionAtInport1[3] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[7] << 8) +
       rtb_DataTypeConversion2_k[6]);
    x86linuxcompiletest4_B.TmpSignalConversionAtInport1[4] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[9] << 8) +
       rtb_DataTypeConversion2_k[8]);
    x86linuxcompiletest4_B.TmpSignalConversionAtInport1[5] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[11] << 8) +
       rtb_DataTypeConversion2_k[10]);
    x86linuxcompiletest4_B.TmpSignalConversionAtInport1[6] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[13] << 8) +
       rtb_DataTypeConversion2_k[12]);
    x86linuxcompiletest4_B.TmpSignalConversionAtInport1[7] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[15] << 8) +
       rtb_DataTypeConversion2_k[14]);
    x86linuxcompiletest4_B.TmpSignalConversionAtInport1[8] = (uint16_T)
      ((uint32_T)(uint16_T)(rtb_DataTypeConversion2_k[17] << 8) +
       rtb_DataTypeConversion2_k[16]);

    /* S-Function (sfcn_CS): '<S10>/����У��' incorporates:
     *  Constant: '<S10>/��־λ'
     */
    sfcn_CS_Outputs_wrapper
      (&x86linuxcompiletest4_B.TmpSignalConversionAtInport1[0],
       &x86linuxcompiletest4_P.Value, &x86linuxcompiletest4_B._o1[0],
       &x86linuxcompiletest4_B._o2);

    /* DataStoreWrite: '<S10>/��Ϣ״̬' */
    PTX = x86linuxcompiletest4_B._o2;

    /* End of Outputs for SubSystem: '<S6>/Enabled Subsystem' */

    /* MATLAB Function: '<S6>/GUIcmdProces' */
    i = 0;
    if ((x86linuxcompiletest4_B._o1[0] == 128) && (x86linuxcompiletest4_B._o1[2]
         == 1) && (x86linuxcompiletest4_B._o1[3] == 0)) {
      i = 2;
    } else if ((x86linuxcompiletest4_B._o1[0] == 128) &&
               (x86linuxcompiletest4_B._o1[2] == 1) &&
               (x86linuxcompiletest4_B._o1[3] == 1)) {
      i = 1;
    } else if ((x86linuxcompiletest4_B._o1[0] == 1) &&
               (x86linuxcompiletest4_B._o1[1] == 0)) {
      i = 3;
    } else if ((x86linuxcompiletest4_B._o1[0] == 2) &&
               (x86linuxcompiletest4_B._o1[1] == 0)) {
      i = 4;
    } else if (x86linuxcompiletest4_B._o1[0] == 129) {
      i = 5;
    } else if (x86linuxcompiletest4_B._o1[0] == 130) {
      i = 6;
    } else if (x86linuxcompiletest4_B._o1[0] == 102) {
      i = 7;
    } else if (x86linuxcompiletest4_B._o1[0] == 103) {
      i = 8;
    } else if (x86linuxcompiletest4_B._o1[0] == 104) {
      i = 9;
    } else if (x86linuxcompiletest4_B._o1[0] == 105) {
      i = 10;
    } else {
      if (x86linuxcompiletest4_B._o1[0] == 136) {
        i = 11;
      }
    }

    /* End of MATLAB Function: '<S6>/GUIcmdProces' */

    /* DataStoreWrite: '<S6>/Data Store Write3' */
    x86linuxcompiletest4_DW.GUIcomd = i;

    /* SwitchCase: '<S6>/Switch Case' */
    switch (i) {
     case 3:
      /* Outputs for IfAction SubSystem: '<S6>/Zhengjie' incorporates:
       *  ActionPort: '<S14>/Action Port'
       */
      /* DataTypeConversion: '<S14>/Data Type Conversion1' */
      for (i = 0; i < 9; i++) {
        rtb_DataTypeConversion1_c[i] = (int16_T)x86linuxcompiletest4_B._o1[i];
      }

      /* End of DataTypeConversion: '<S14>/Data Type Conversion1' */

      /* DataStoreWrite: '<S14>/Data Store Write' incorporates:
       *  DataTypeConversion: '<S14>/Data Type Conversion2'
       *  Gain: '<S14>/Gain'
       *  Gain: '<S14>/Gain1'
       */
      x86linuxcompiletest4_DW.PosJoint[0] = x86linuxcompiletest4_P.Gain_Gain *
        (real_T)rtb_DataTypeConversion1_c[2];
      x86linuxcompiletest4_DW.PosJoint[2] = x86linuxcompiletest4_P.Gain_Gain *
        (real_T)rtb_DataTypeConversion1_c[3];
      x86linuxcompiletest4_DW.PosJoint[4] = (real_T)(int16_T)
        ((x86linuxcompiletest4_P.Gain1_Gain_k * rtb_DataTypeConversion1_c[4]) >>
         15) * x86linuxcompiletest4_P.Gain_Gain;
      x86linuxcompiletest4_DW.PosJoint[6] = x86linuxcompiletest4_P.Gain_Gain *
        (real_T)rtb_DataTypeConversion1_c[5];
      x86linuxcompiletest4_DW.PosJoint[8] = x86linuxcompiletest4_P.Gain_Gain *
        (real_T)rtb_DataTypeConversion1_c[6];
      x86linuxcompiletest4_DW.PosJoint[10] = x86linuxcompiletest4_P.Gain_Gain *
        (real_T)rtb_DataTypeConversion1_c[7];

      /* End of Outputs for SubSystem: '<S6>/Zhengjie' */
      break;

     case 4:
      /* Outputs for IfAction SubSystem: '<S6>/Nijie' incorporates:
       *  ActionPort: '<S13>/Action Port'
       */
      /* DataTypeConversion: '<S13>/Data Type Conversion2' incorporates:
       *  DataTypeConversion: '<S13>/Data Type Conversion1'
       */
      for (i = 0; i < 9; i++) {
        rtb_DataTypeConversion1_c[i] = (int16_T)x86linuxcompiletest4_B._o1[i];
      }

      /* End of DataTypeConversion: '<S13>/Data Type Conversion2' */

      /* DataStoreWrite: '<S13>/Data Store Write' incorporates:
       *  Gain: '<S13>/Gain1'
       *  Gain: '<S13>/Gain2'
       *  Gain: '<S13>/Gain3'
       *  Gain: '<S13>/Gain4'
       *  Gain: '<S13>/Gain5'
       *  Gain: '<S13>/Gain6'
       */
      x86linuxcompiletest4_DW.PosXYZ[0] = x86linuxcompiletest4_P.Gain1_Gain_b *
        (real_T)rtb_DataTypeConversion1_c[2];
      x86linuxcompiletest4_DW.PosXYZ[2] = x86linuxcompiletest4_P.Gain2_Gain *
        (real_T)rtb_DataTypeConversion1_c[3];
      x86linuxcompiletest4_DW.PosXYZ[4] = x86linuxcompiletest4_P.Gain3_Gain_i *
        (real_T)rtb_DataTypeConversion1_c[4];
      x86linuxcompiletest4_DW.PosXYZ[6] = x86linuxcompiletest4_P.Gain4_Gain *
        (real_T)rtb_DataTypeConversion1_c[5];
      x86linuxcompiletest4_DW.PosXYZ[8] = x86linuxcompiletest4_P.Gain5_Gain *
        (real_T)rtb_DataTypeConversion1_c[6];
      x86linuxcompiletest4_DW.PosXYZ[10] = x86linuxcompiletest4_P.Gain6_Gain *
        (real_T)rtb_DataTypeConversion1_c[7];

      /* End of Outputs for SubSystem: '<S6>/Nijie' */
      break;

     case 11:
      /* Outputs for IfAction SubSystem: '<S6>/Jdata' incorporates:
       *  ActionPort: '<S12>/Action Port'
       */
      /* SwitchCase: '<S12>/Switch Case' */
      switch (x86linuxcompiletest4_B._o1[1]) {
       case 1:
        /* Outputs for IfAction SubSystem: '<S12>/Joint1' incorporates:
         *  ActionPort: '<S16>/Action Port'
         */
        /* DataStoreWrite: '<S16>/Data Store Write2' incorporates:
         *  DataTypeConversion: '<S12>/Data Type Conversion'
         *  DataTypeConversion: '<S12>/Data Type Conversion3'
         */
        for (i = 0; i < 6; i++) {
          x86linuxcompiletest4_DW.Jdata[i] = (int16_T)
            x86linuxcompiletest4_B._o1[i + 2];
        }

        /* End of DataStoreWrite: '<S16>/Data Store Write2' */
        /* End of Outputs for SubSystem: '<S12>/Joint1' */
        break;

       case 2:
        /* Outputs for IfAction SubSystem: '<S12>/Joint2' incorporates:
         *  ActionPort: '<S17>/Action Port'
         */
        /* DataStoreWrite: '<S17>/Data Store Write2' incorporates:
         *  DataTypeConversion: '<S12>/Data Type Conversion'
         *  DataTypeConversion: '<S12>/Data Type Conversion3'
         */
        for (i = 0; i < 6; i++) {
          x86linuxcompiletest4_DW.Jdata[i + 6] = (int16_T)
            x86linuxcompiletest4_B._o1[i + 2];
        }

        /* End of DataStoreWrite: '<S17>/Data Store Write2' */
        /* End of Outputs for SubSystem: '<S12>/Joint2' */
        break;

       case 3:
        /* Outputs for IfAction SubSystem: '<S12>/Joint3' incorporates:
         *  ActionPort: '<S18>/Action Port'
         */
        /* DataStoreWrite: '<S18>/Data Store Write2' incorporates:
         *  DataTypeConversion: '<S12>/Data Type Conversion'
         *  DataTypeConversion: '<S12>/Data Type Conversion3'
         */
        for (i = 0; i < 6; i++) {
          x86linuxcompiletest4_DW.Jdata[i + 12] = (int16_T)
            x86linuxcompiletest4_B._o1[i + 2];
        }

        /* End of DataStoreWrite: '<S18>/Data Store Write2' */
        /* End of Outputs for SubSystem: '<S12>/Joint3' */
        break;

       case 4:
        /* Outputs for IfAction SubSystem: '<S12>/Joint4' incorporates:
         *  ActionPort: '<S19>/Action Port'
         */
        /* DataStoreWrite: '<S19>/Data Store Write2' incorporates:
         *  DataTypeConversion: '<S12>/Data Type Conversion'
         *  DataTypeConversion: '<S12>/Data Type Conversion3'
         */
        for (i = 0; i < 6; i++) {
          x86linuxcompiletest4_DW.Jdata[i + 18] = (int16_T)
            x86linuxcompiletest4_B._o1[i + 2];
        }

        /* End of DataStoreWrite: '<S19>/Data Store Write2' */
        /* End of Outputs for SubSystem: '<S12>/Joint4' */
        break;

       case 5:
        /* Outputs for IfAction SubSystem: '<S12>/Joint5' incorporates:
         *  ActionPort: '<S20>/Action Port'
         */
        /* DataStoreWrite: '<S20>/Data Store Write2' incorporates:
         *  DataTypeConversion: '<S12>/Data Type Conversion'
         *  DataTypeConversion: '<S12>/Data Type Conversion3'
         */
        for (i = 0; i < 6; i++) {
          x86linuxcompiletest4_DW.Jdata[i + 24] = (int16_T)
            x86linuxcompiletest4_B._o1[i + 2];
        }

        /* End of DataStoreWrite: '<S20>/Data Store Write2' */
        /* End of Outputs for SubSystem: '<S12>/Joint5' */
        break;

       case 6:
        /* Outputs for IfAction SubSystem: '<S12>/Joint6' incorporates:
         *  ActionPort: '<S21>/Action Port'
         */
        /* DataStoreWrite: '<S21>/Data Store Write2' incorporates:
         *  DataTypeConversion: '<S12>/Data Type Conversion'
         *  DataTypeConversion: '<S12>/Data Type Conversion3'
         */
        for (i = 0; i < 6; i++) {
          x86linuxcompiletest4_DW.Jdata[i + 30] = (int16_T)
            x86linuxcompiletest4_B._o1[i + 2];
        }

        /* End of DataStoreWrite: '<S21>/Data Store Write2' */
        /* End of Outputs for SubSystem: '<S12>/Joint6' */
        break;

       case 7:
        /* Outputs for IfAction SubSystem: '<S12>/Joint7' incorporates:
         *  ActionPort: '<S22>/Action Port'
         */
        /* DataStoreWrite: '<S22>/Data Store Write2' incorporates:
         *  DataTypeConversion: '<S12>/Data Type Conversion'
         *  DataTypeConversion: '<S12>/Data Type Conversion3'
         */
        for (i = 0; i < 6; i++) {
          x86linuxcompiletest4_DW.Jdata[i + 36] = (int16_T)
            x86linuxcompiletest4_B._o1[i + 2];
        }

        /* End of DataStoreWrite: '<S22>/Data Store Write2' */
        /* End of Outputs for SubSystem: '<S12>/Joint7' */
        break;
      }

      /* End of SwitchCase: '<S12>/Switch Case' */
      /* End of Outputs for SubSystem: '<S6>/Jdata' */
      break;
    }

    /* End of SwitchCase: '<S6>/Switch Case' */
  }

  /* End of DataStoreRead: '<S1>/Data Store Read1' */
  /* End of Outputs for SubSystem: '<S1>/Subsystem2' */

  /* Update for Delay: '<S1>/Delay' */
  x86linuxcompiletest4_DW.Delay_DSTATE[0] =
    x86linuxcompiletest4_DW.Delay_DSTATE[1];

  /* Switch: '<S1>/Switch' incorporates:
   *  UnitDelay: '<S7>/Output'
   */
  if (x86linuxcompiletest4_DW.Output_DSTATE_e >
      x86linuxcompiletest4_P.Switch_Threshold) {
    /* Update for Delay: '<S1>/Delay' incorporates:
     *  Constant: '<S1>/Constant1'
     */
    x86linuxcompiletest4_DW.Delay_DSTATE[1] =
      x86linuxcompiletest4_P.Constant1_Value;
  } else {
    /* Update for Delay: '<S1>/Delay' incorporates:
     *  Constant: '<S1>/Constant'
     */
    x86linuxcompiletest4_DW.Delay_DSTATE[1] =
      x86linuxcompiletest4_P.Constant_Value_f;
  }

  /* End of Switch: '<S1>/Switch' */

  /* Update for UnitDelay: '<S7>/Output' */
  x86linuxcompiletest4_DW.Output_DSTATE_e = rtb_FixPtSwitch;

  /* Switch: '<S26>/FixPt Switch' */
  if (rtb_FixPtSum1 > x86linuxcompiletest4_P.u_uplimit) {
    /* Update for UnitDelay: '<S8>/Output' incorporates:
     *  Constant: '<S26>/Constant'
     */
    x86linuxcompiletest4_DW.Output_DSTATE_a =
      x86linuxcompiletest4_P.Constant_Value_m;
  } else {
    /* Update for UnitDelay: '<S8>/Output' */
    x86linuxcompiletest4_DW.Output_DSTATE_a = rtb_FixPtSum1;
  }

  /* End of Switch: '<S26>/FixPt Switch' */
}

/* Model step function */
void x86linuxcompiletest4_step(void)
{
  uint8_T rtb_FixPtSum1;

  /* Outputs for Atomic SubSystem: '<Root>/SendDataToGUI1' */
  x86linuxcompilet_SendDataToGUI1();

  /* End of Outputs for SubSystem: '<Root>/SendDataToGUI1' */

  /* Outputs for Atomic SubSystem: '<Root>/Subsystem' */
  /* DataStoreWrite: '<S2>/Data Store Write1' incorporates:
   *  UnitDelay: '<S27>/Output'
   */
  Datachange1 = x86linuxcompiletest4_DW.Output_DSTATE_m;

  /* Sum: '<S28>/FixPt Sum1' incorporates:
   *  Constant: '<S28>/FixPt Constant'
   *  UnitDelay: '<S27>/Output'
   */
  rtb_FixPtSum1 = (uint8_T)((uint32_T)x86linuxcompiletest4_DW.Output_DSTATE_m +
    x86linuxcompiletest4_P.FixPtConstant_Value_l);

  /* Switch: '<S29>/FixPt Switch' */
  if (rtb_FixPtSum1 > x86linuxcompiletest4_P.CounterLimited_uplimit) {
    /* Update for UnitDelay: '<S27>/Output' incorporates:
     *  Constant: '<S29>/Constant'
     */
    x86linuxcompiletest4_DW.Output_DSTATE_m =
      x86linuxcompiletest4_P.Constant_Value_g;
  } else {
    /* Update for UnitDelay: '<S27>/Output' */
    x86linuxcompiletest4_DW.Output_DSTATE_m = rtb_FixPtSum1;
  }

  /* End of Switch: '<S29>/FixPt Switch' */
  /* End of Outputs for SubSystem: '<Root>/Subsystem' */
  if (x86linuxcompiletest4_M->Timing.TaskCounters.TID[1] == 0) {
    /* Outputs for Atomic SubSystem: '<Root>/Subsystem1' */
    /* DataStoreWrite: '<S3>/Data Store Write1' incorporates:
     *  UnitDelay: '<S30>/Output'
     */
    Datachange2 = x86linuxcompiletest4_DW.Output_DSTATE;

    /* Sum: '<S31>/FixPt Sum1' incorporates:
     *  Constant: '<S31>/FixPt Constant'
     *  UnitDelay: '<S30>/Output'
     */
    rtb_FixPtSum1 = (uint8_T)((uint32_T)x86linuxcompiletest4_DW.Output_DSTATE +
      x86linuxcompiletest4_P.FixPtConstant_Value_i);

    /* Switch: '<S32>/FixPt Switch' */
    if (rtb_FixPtSum1 > x86linuxcompiletest4_P.CounterLimited_uplimit_m) {
      /* Update for UnitDelay: '<S30>/Output' incorporates:
       *  Constant: '<S32>/Constant'
       */
      x86linuxcompiletest4_DW.Output_DSTATE =
        x86linuxcompiletest4_P.Constant_Value_gs;
    } else {
      /* Update for UnitDelay: '<S30>/Output' */
      x86linuxcompiletest4_DW.Output_DSTATE = rtb_FixPtSum1;
    }

    /* End of Switch: '<S32>/FixPt Switch' */
    /* End of Outputs for SubSystem: '<Root>/Subsystem1' */
  }

  /* Matfile logging */
  rt_UpdateTXYLogVars(x86linuxcompiletest4_M->rtwLogInfo,
                      (&x86linuxcompiletest4_M->Timing.taskTime0));

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.001s, 0.0s] */
    if ((rtmGetTFinal(x86linuxcompiletest4_M)!=-1) &&
        !((rtmGetTFinal(x86linuxcompiletest4_M)-
           x86linuxcompiletest4_M->Timing.taskTime0) >
          x86linuxcompiletest4_M->Timing.taskTime0 * (DBL_EPSILON))) {
      rtmSetErrorStatus(x86linuxcompiletest4_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++x86linuxcompiletest4_M->Timing.clockTick0)) {
    ++x86linuxcompiletest4_M->Timing.clockTickH0;
  }

  x86linuxcompiletest4_M->Timing.taskTime0 =
    x86linuxcompiletest4_M->Timing.clockTick0 *
    x86linuxcompiletest4_M->Timing.stepSize0 +
    x86linuxcompiletest4_M->Timing.clockTickH0 *
    x86linuxcompiletest4_M->Timing.stepSize0 * 4294967296.0;
  rate_scheduler();
}

/* Model initialize function */
void x86linuxcompiletest4_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)x86linuxcompiletest4_M, 0,
                sizeof(RT_MODEL_x86linuxcompiletest4_T));
  rtmSetTFinal(x86linuxcompiletest4_M, -1);
  x86linuxcompiletest4_M->Timing.stepSize0 = 0.001;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    x86linuxcompiletest4_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(x86linuxcompiletest4_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(x86linuxcompiletest4_M->rtwLogInfo, (NULL));
    rtliSetLogT(x86linuxcompiletest4_M->rtwLogInfo, "tout");
    rtliSetLogX(x86linuxcompiletest4_M->rtwLogInfo, "");
    rtliSetLogXFinal(x86linuxcompiletest4_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(x86linuxcompiletest4_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(x86linuxcompiletest4_M->rtwLogInfo, 4);
    rtliSetLogMaxRows(x86linuxcompiletest4_M->rtwLogInfo, 0);
    rtliSetLogDecimation(x86linuxcompiletest4_M->rtwLogInfo, 1);
    rtliSetLogY(x86linuxcompiletest4_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(x86linuxcompiletest4_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(x86linuxcompiletest4_M->rtwLogInfo, (NULL));
  }

  /* block I/O */
  (void) memset(((void *) &x86linuxcompiletest4_B), 0,
                sizeof(B_x86linuxcompiletest4_T));

  /* states (dwork) */
  (void) memset((void *)&x86linuxcompiletest4_DW, 0,
                sizeof(DW_x86linuxcompiletest4_T));

  /* exported global states */
  (void) memset(&UDPsnddata, 0,
                20U*sizeof(uint16_T));
  Datachange1 = 0U;
  Datachange2 = 0U;
  (void) memset(&UDPrecvdata, 0,
                18U*sizeof(uint8_T));
  UDPsndFlag = false;
  UDPensndFlag = false;
  UDPenrecvFlag = false;
  UDPrecvFlag = false;
  PTX = false;

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(x86linuxcompiletest4_M->rtwLogInfo, 0.0,
    rtmGetTFinal(x86linuxcompiletest4_M),
    x86linuxcompiletest4_M->Timing.stepSize0, (&rtmGetErrorStatus
    (x86linuxcompiletest4_M)));

  {
    int32_T i;

    /* Start for DataStoreMemory: '<Root>/Data Store Memory' */
    ConTs = x86linuxcompiletest4_P.Ts * 1000.0 * 1000.0;

    /* Start for DataStoreMemory: '<Root>/Data Store Memory20' */
    memcpy(&x86linuxcompiletest4_DW.Ethercomd[0],
           &x86linuxcompiletest4_P.DataStoreMemory20_InitialValue[0], 49U *
           sizeof(uint32_T));

    /* Start for DataStoreMemory: '<Root>/Data Store Memory21' */
    memcpy(&x86linuxcompiletest4_DW.Etherfeed[0],
           &x86linuxcompiletest4_P.DataStoreMemory21_InitialValue[0], 42U *
           sizeof(uint32_T));

    /* Start for DataStoreMemory: '<Root>/UDPд��־' */
    UDPsndFlag = x86linuxcompiletest4_P.UDPInitialValue;

    /* Start for DataStoreMemory: '<Root>/Data Store Memory1' */
    Datachange1 = x86linuxcompiletest4_P.DataStoreMemory1_InitialValue;

    /* Start for DataStoreMemory: '<Root>/Data Store Memory10' */
    for (i = 0; i < 20; i++) {
      UDPsnddata[i] = x86linuxcompiletest4_P.DataStoreMemory10_InitialValue[i];
    }

    /* End of Start for DataStoreMemory: '<Root>/Data Store Memory10' */

    /* Start for DataStoreMemory: '<Root>/Data Store Memory19' */
    x86linuxcompiletest4_DW.GUIcomd =
      x86linuxcompiletest4_P.DataStoreMemory19_InitialValue;

    /* Start for DataStoreMemory: '<Root>/Data Store Memory2' */
    Datachange2 = x86linuxcompiletest4_P.DataStoreMemory2_InitialValue;

    /* Start for DataStoreMemory: '<Root>/Data Store Memory3' */
    memcpy(&x86linuxcompiletest4_DW.Send_GUIdata[0],
           &x86linuxcompiletest4_P.DataStoreMemory3_InitialValue[0], 18U *
           sizeof(real_T));

    /* Start for DataStoreMemory: '<Root>/Data Store Memory4' */
    memcpy(&x86linuxcompiletest4_DW.PosJoint[0],
           &x86linuxcompiletest4_P.DataStoreMemory4_InitialValue[0], 14U *
           sizeof(real_T));

    /* Start for DataStoreMemory: '<Root>/Data Store Memory5' */
    memcpy(&x86linuxcompiletest4_DW.VelocJoint[0],
           &x86linuxcompiletest4_P.DataStoreMemory5_InitialValue[0], 14U *
           sizeof(real_T));

    /* Start for DataStoreMemory: '<Root>/Data Store Memory6' */
    memcpy(&x86linuxcompiletest4_DW.TorqueJoint[0],
           &x86linuxcompiletest4_P.DataStoreMemory6_InitialValue[0], 14U *
           sizeof(real_T));

    /* Start for DataStoreMemory: '<Root>/Data Store Memory7' */
    memcpy(&x86linuxcompiletest4_DW.PosXYZ[0],
           &x86linuxcompiletest4_P.DataStoreMemory7_InitialValue[0], 14U *
           sizeof(real_T));

    /* Start for DataStoreMemory: '<Root>/Data Store Memory8' */
    memcpy(&x86linuxcompiletest4_DW.Jdata[0],
           &x86linuxcompiletest4_P.DataStoreMemory8_InitialValue[0], 42U *
           sizeof(real_T));

    /* Start for DataStoreMemory: '<Root>/Data Store Memory9' */
    for (i = 0; i < 18; i++) {
      UDPrecvdata[i] = x86linuxcompiletest4_P.DataStoreMemory9_InitialValue[i];
    }

    /* End of Start for DataStoreMemory: '<Root>/Data Store Memory9' */

    /* Start for DataStoreMemory: '<Root>/UDPʹ��д��־' */
    UDPensndFlag = x86linuxcompiletest4_P.UDPInitialValue_j;

    /* Start for DataStoreMemory: '<Root>/UDPʹ�ܶ�ȡ��־' */
    UDPenrecvFlag = x86linuxcompiletest4_P.UDP_InitialValue;

    /* Start for DataStoreMemory: '<Root>/UDP��ȡ��־' */
    UDPrecvFlag = x86linuxcompiletest4_P.UDP_InitialValue_e;

    /* Start for DataStoreMemory: '<Root>/��Ϣʹ��' */
    PTX = x86linuxcompiletest4_P._InitialValue;
  }

  {
    {
      /* user code (Initialize function Header) */

      /* System '<Root>' */
      udp_init();
      signal(SIGALRM,signal_handler);
      set_timer();

      /* SystemInitialize for Atomic SubSystem: '<Root>/SendDataToGUI1' */
      x86linuxcom_SendDataToGUI1_Init();

      /* End of SystemInitialize for SubSystem: '<Root>/SendDataToGUI1' */

      /* SystemInitialize for Atomic SubSystem: '<Root>/Subsystem' */
      /* InitializeConditions for UnitDelay: '<S27>/Output' */
      x86linuxcompiletest4_DW.Output_DSTATE_m =
        x86linuxcompiletest4_P.Output_InitialCondition_j;

      /* End of SystemInitialize for SubSystem: '<Root>/Subsystem' */

      /* SystemInitialize for Atomic SubSystem: '<Root>/Subsystem1' */
      /* InitializeConditions for UnitDelay: '<S30>/Output' */
      x86linuxcompiletest4_DW.Output_DSTATE =
        x86linuxcompiletest4_P.Output_InitialCondition_l;

      /* End of SystemInitialize for SubSystem: '<Root>/Subsystem1' */
    }
  }
}

/* Model terminate function */
void x86linuxcompiletest4_terminate(void)
{
  {
    /* user code (Terminate function Header) */

    /* System '<Root>' */
    close(udp_socket_fd);
  }
}
