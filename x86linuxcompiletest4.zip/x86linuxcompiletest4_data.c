/*
 * x86linuxcompiletest4_data.c
 *
 * Code generation for model "x86linuxcompiletest4".
 *
 * Model version              : 1.32
 * Simulink Coder version : 9.4 (R2020b) 29-Jul-2020
 * C source code generated on : Wed Apr 21 19:19:18 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "x86linuxcompiletest4.h"
#include "x86linuxcompiletest4_private.h"

/* Block parameters (default storage) */
P_x86linuxcompiletest4_T x86linuxcompiletest4_P = {
  /* Variable: Ts
   * Referenced by: '<Root>/Data Store Memory'
   */
  0.001,

  /* Mask Parameter: _uplimit
   * Referenced by: '<S24>/FixPt Switch'
   */
  9U,

  /* Mask Parameter: u_uplimit
   * Referenced by: '<S26>/FixPt Switch'
   */
  49U,

  /* Mask Parameter: CounterLimited_uplimit
   * Referenced by: '<S29>/FixPt Switch'
   */
  7U,

  /* Mask Parameter: CounterLimited_uplimit_m
   * Referenced by: '<S32>/FixPt Switch'
   */
  5U,

  /* Expression: 10
   * Referenced by: '<S4>/Gain1'
   */
  10.0,

  /* Expression: 10
   * Referenced by: '<S4>/Gain3'
   */
  10.0,

  /* Expression: 0.1
   * Referenced by: '<S14>/Gain'
   */
  0.1,

  /* Expression: 0.1
   * Referenced by: '<S13>/Gain1'
   */
  0.1,

  /* Expression: 0.1
   * Referenced by: '<S13>/Gain2'
   */
  0.1,

  /* Expression: 0.1
   * Referenced by: '<S13>/Gain3'
   */
  0.1,

  /* Expression: 0.1
   * Referenced by: '<S13>/Gain4'
   */
  0.1,

  /* Expression: 0.1
   * Referenced by: '<S13>/Gain5'
   */
  0.1,

  /* Expression: 0.1
   * Referenced by: '<S13>/Gain6'
   */
  0.1,

  /* Expression: 0
   * Referenced by: '<Root>/Data Store Memory19'
   */
  0.0,

  /* Expression: zeros(1,18)
   * Referenced by: '<Root>/Data Store Memory3'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0 },

  /* Expression: zeros(2,7)
   * Referenced by: '<Root>/Data Store Memory4'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  /* Expression: zeros(2,7)
   * Referenced by: '<Root>/Data Store Memory5'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  /* Expression: zeros(2,7)
   * Referenced by: '<Root>/Data Store Memory6'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  /* Expression: zeros(2,7)
   * Referenced by: '<Root>/Data Store Memory7'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  /* Expression: zeros(6,7)
   * Referenced by: '<Root>/Data Store Memory8'
   */
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 },

  /* Computed Parameter: DataStoreMemory20_InitialValue
   * Referenced by: '<Root>/Data Store Memory20'
   */
  { 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
    0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
    0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U },

  /* Computed Parameter: DataStoreMemory21_InitialValue
   * Referenced by: '<Root>/Data Store Memory21'
   */
  { 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
    0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
    0U, 0U, 0U, 0U },

  /* Computed Parameter: Gain1_Gain_k
   * Referenced by: '<S14>/Gain1'
   */
  -32768,

  /* Computed Parameter: Constant2_Value
   * Referenced by: '<S4>/Constant2'
   */
  90U,

  /* Computed Parameter: Value
   * Referenced by: '<S10>/��־λ'
   */
  0U,

  /* Computed Parameter: DataStoreMemory10_InitialValue
   * Referenced by: '<Root>/Data Store Memory10'
   */
  { 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
    0U },

  /* Computed Parameter: Constant_Value
   * Referenced by: '<S4>/Constant'
   */
  1,

  /* Computed Parameter: Constant_Value_p
   * Referenced by: '<S5>/Constant'
   */
  1,

  /* Computed Parameter: Constant_Value_h
   * Referenced by: '<S6>/Constant'
   */
  0,

  /* Expression: false
   * Referenced by: '<S1>/Constant3'
   */
  0,

  /* Expression: true
   * Referenced by: '<S1>/Constant2'
   */
  1,

  /* Expression: false
   * Referenced by: '<S1>/Constant1'
   */
  0,

  /* Expression: true
   * Referenced by: '<S1>/Constant'
   */
  1,

  /* Computed Parameter: Delay_InitialCondition
   * Referenced by: '<S1>/Delay'
   */
  0,

  /* Computed Parameter: UDPInitialValue
   * Referenced by: '<Root>/UDPд��־'
   */
  0,

  /* Computed Parameter: UDPInitialValue_j
   * Referenced by: '<Root>/UDPʹ��д��־'
   */
  0,

  /* Computed Parameter: UDP_InitialValue
   * Referenced by: '<Root>/UDPʹ�ܶ�ȡ��־'
   */
  0,

  /* Computed Parameter: UDP_InitialValue_e
   * Referenced by: '<Root>/UDP��ȡ��־'
   */
  0,

  /* Computed Parameter: _InitialValue
   * Referenced by: '<Root>/��Ϣʹ��'
   */
  0,

  /* Computed Parameter: Constant_Value_b
   * Referenced by: '<S24>/Constant'
   */
  0U,

  /* Computed Parameter: Constant_Value_m
   * Referenced by: '<S26>/Constant'
   */
  0U,

  /* Computed Parameter: Output_InitialCondition
   * Referenced by: '<S7>/Output'
   */
  0U,

  /* Computed Parameter: Switch_Threshold
   * Referenced by: '<S1>/Switch'
   */
  0U,

  /* Computed Parameter: FixPtConstant_Value
   * Referenced by: '<S23>/FixPt Constant'
   */
  1U,

  /* Computed Parameter: Output_InitialCondition_p
   * Referenced by: '<S8>/Output'
   */
  0U,

  /* Computed Parameter: Switch1_Threshold
   * Referenced by: '<S1>/Switch1'
   */
  0U,

  /* Computed Parameter: FixPtConstant_Value_j
   * Referenced by: '<S25>/FixPt Constant'
   */
  1U,

  /* Computed Parameter: Constant_Value_g
   * Referenced by: '<S29>/Constant'
   */
  0U,

  /* Computed Parameter: Output_InitialCondition_j
   * Referenced by: '<S27>/Output'
   */
  0U,

  /* Computed Parameter: FixPtConstant_Value_l
   * Referenced by: '<S28>/FixPt Constant'
   */
  1U,

  /* Computed Parameter: Constant_Value_gs
   * Referenced by: '<S32>/Constant'
   */
  0U,

  /* Computed Parameter: Output_InitialCondition_l
   * Referenced by: '<S30>/Output'
   */
  0U,

  /* Computed Parameter: FixPtConstant_Value_i
   * Referenced by: '<S31>/FixPt Constant'
   */
  1U,

  /* Computed Parameter: DataStoreMemory1_InitialValue
   * Referenced by: '<Root>/Data Store Memory1'
   */
  0U,

  /* Computed Parameter: DataStoreMemory2_InitialValue
   * Referenced by: '<Root>/Data Store Memory2'
   */
  0U,

  /* Computed Parameter: DataStoreMemory9_InitialValue
   * Referenced by: '<Root>/Data Store Memory9'
   */
  { 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
};
